/*
 * This file is part of Baritone.
 *
 * Baritone is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Baritone is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with Baritone.  If not, see <https://www.gnu.org/licenses/>.
 */

package baritone.api.pathing.goals;

import baritone.api.utils.SettingsUtil;
import net.minecraft.core.BlockPos;

import java.util.Arrays;
import java.util.Objects;

/**
 * Useful for automated combat (retreating specifically)
 *
 * @author leijurv
 */
public class GoalRunAway implements Goal {

    private final BlockPos[] from;

    private final double distanceSq;

    private final Integer maintainY;

    public GoalRunAway(double distance, BlockPos... from) {
        this(distance, null, from);
    }

    public GoalRunAway(double distance, Integer maintainY, BlockPos... from) {
        if (from.length == 0) {
            throw new IllegalArgumentException("Positions to run away from must not be empty");
        }
        if (!Double.isFinite(distance) || distance < 0 || !Double.isFinite(distance * distance))
            throw new IllegalArgumentException("Distance must be finite and nonnegative");
        this.from = Arrays.stream(from).map(p -> Objects.requireNonNull(p).immutable()).toArray(BlockPos[]::new);
        this.distanceSq = distance * distance;
        this.maintainY = maintainY;
    }

    @Override
    public boolean isInGoal(int x, int y, int z) {
        if (maintainY != null && maintainY != y) {
            return false;
        }
        for (BlockPos p : from) {
            double diffX = (double) x - p.getX();
            double diffZ = (double) z - p.getZ();
            double distSq = diffX * diffX + diffZ * diffZ;
            if (distSq < distanceSq) {
                return false;
            }
        }
        return true;
    }

    @Override
    public double heuristic(int x, int y, int z) {
        double remaining = 0;
        double distance = Math.sqrt(distanceSq);
        for (BlockPos p : from) {
            remaining = Math.max(remaining, distance - Math.hypot((double) x - p.getX(), (double) z - p.getZ()));
        }
        double estimate = remaining * baritone.api.BaritoneAPI.getSettings().costHeuristic.value;
        if (maintainY != null) {
            long dy = (long) y - maintainY;
            estimate += GoalBlock.calculate(0, (int) Math.max(Integer.MIN_VALUE + 1L, Math.min(Integer.MAX_VALUE, dy)), 0);
        }
        return estimate;
    }

    @Override
    public double heuristic() {
        // The remaining-distance estimate is zero at every satisfying position.
        return 0;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        GoalRunAway goal = (GoalRunAway) o;
        return distanceSq == goal.distanceSq
                && Arrays.equals(from, goal.from)
                && Objects.equals(maintainY, goal.maintainY);
    }

    @Override
    public int hashCode() {
        int hash = Arrays.hashCode(from);
        hash = hash * 1196803141 + Double.hashCode(distanceSq);
        hash = hash * -2053788840 + Objects.hashCode(maintainY);
        return hash;
    }

    @Override
    public String toString() {
        if (maintainY != null) {
            return String.format(
                    "GoalRunAwayFromMaintainY y=%s, %s",
                    SettingsUtil.maybeCensor(maintainY),
                    Arrays.asList(from)
            );
        } else {
            return "GoalRunAwayFrom" + Arrays.asList(from);
        }
    }
}
