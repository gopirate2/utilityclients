/*
 * This file is part of Baritone.
 *
 * Baritone is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Baritone is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with Baritone.  If not, see <https://www.gnu.org/licenses/>.
 */

package baritone.api.pathing.goals;

import baritone.api.utils.BetterBlockPos;
import baritone.api.utils.SettingsUtil;
import baritone.api.utils.interfaces.IGoalRenderPos;
import net.minecraft.core.BlockPos;

public class GoalNear implements Goal, IGoalRenderPos {

    private final int x;
    private final int y;
    private final int z;
    private final long rangeSq;

    public GoalNear(BlockPos pos, int range) {
        if (range < 0) throw new IllegalArgumentException("Range must be nonnegative");
        this.x = pos.getX();
        this.y = pos.getY();
        this.z = pos.getZ();
        this.rangeSq = (long) range * range;
    }

    @Override
    public boolean isInGoal(int x, int y, int z) {
        double xDiff = (double) x - this.x;
        double yDiff = (double) y - this.y;
        double zDiff = (double) z - this.z;
        return xDiff * xDiff + yDiff * yDiff + zDiff * zDiff <= rangeSq;
    }

    @Override
    public double heuristic(int x, int y, int z) {
        double xDiff = (double) x - this.x;
        double yDiff = (double) y - this.y;
        double zDiff = (double) z - this.z;
        double distance = Math.sqrt(xDiff * xDiff + yDiff * yDiff + zDiff * zDiff);
        double radius = Math.sqrt(rangeSq);
        if (distance <= radius) return 0;
        int vertical = (int) Math.max(Integer.MIN_VALUE + 1.0, Math.min(Integer.MAX_VALUE, yDiff));
        return GoalBlock.calculate(xDiff, vertical, zDiff) * (1 - radius / distance);
    }

    @Override
    public double heuristic() {
        return 0;
    }

    @Override
    public BlockPos getGoalPos() {
        return new BlockPos(x, y, z);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        GoalNear goal = (GoalNear) o;
        return x == goal.x
                && y == goal.y
                && z == goal.z
                && rangeSq == goal.rangeSq;
    }

    @Override
    public int hashCode() {
        return (int) BetterBlockPos.longHash(x, y, z) + Long.hashCode(rangeSq);
    }

    @Override
    public String toString() {
        return String.format(
                "GoalNear{x=%s, y=%s, z=%s, rangeSq=%d}",
                SettingsUtil.maybeCensor(x),
                SettingsUtil.maybeCensor(y),
                SettingsUtil.maybeCensor(z),
                rangeSq
        );
    }
}
