/*
 * This file is part of Baritone.
 *
 * Baritone is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Baritone is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with Baritone.  If not, see <https://www.gnu.org/licenses/>.
 */

package baritone.command.argument;

import baritone.api.command.argument.ICommandArgument;
import baritone.api.command.exception.CommandInvalidArgumentException;

import java.util.ArrayList;
import java.util.List;

/**
 * @author LoganDark
 */
public final class CommandArguments {

    private CommandArguments() {}

    /**
     * Turn a string into a list of {@link ICommandArgument}s. This is needed because of {@link ICommandArgument#getRawRest()}
     *
     * @param string            The string to convert
     * @param preserveEmptyLast If the string ends with whitespace, add an empty {@link ICommandArgument} to the end This
     *                          is useful for tab completion
     * @return A list of {@link ICommandArgument}s
     */
    public static List<ICommandArgument> from(String string, boolean preserveEmptyLast) {
        List<ICommandArgument> args = new ArrayList<>();
        int lastEnd = -1;
        int cursor = 0;
        while (cursor < string.length()) {
            while (cursor < string.length() && Character.isWhitespace(string.charAt(cursor))) cursor++;
            if (cursor == string.length()) break;
            int start = cursor;
            char quote = 0;
            StringBuilder value = new StringBuilder();
            while (cursor < string.length()) {
                char current = string.charAt(cursor);
                if (quote == 0 && Character.isWhitespace(current)) break;
                if (current == '\\' && cursor + 1 < string.length()) {
                    char next = string.charAt(cursor + 1);
                    boolean escaped = quote != 0 ? next == quote || next == '\\'
                            : Character.isWhitespace(next) || next == '\"' || next == '\'';
                    if (escaped) { value.append(next); cursor += 2; continue; }
                }
                if (current == '\"' || current == '\'') {
                    if (quote == 0) { quote = current; cursor++; continue; }
                    if (quote == current) { quote = 0; cursor++; continue; }
                }
                value.append(current);
                cursor++;
            }
            if (quote != 0 && !preserveEmptyLast) throw new IllegalArgumentException("Unclosed quoted argument");
            args.add(new CommandArgument(args.size(), value.toString(), string.substring(start)));
            lastEnd = cursor;
        }
        if (preserveEmptyLast && lastEnd < string.length()) {
            args.add(new CommandArgument(args.size(), "", ""));
        }
        return args;
    }

    /** Completion emits one complete token, including paths with spaces or quotes. */
    public static String quote(String value) {
        if (value.chars().noneMatch(c -> Character.isWhitespace(c) || c == '\"' || c == '\'')) return value;
        return "\"" + value.replace("\\", "\\\\").replace("\"", "\\\"") + "\"";
    }

    /**
     * @see #from(String, boolean)
     */
    public static List<ICommandArgument> from(String string) {
        return from(string, false);
    }

    /**
     * Returns an "unknown" {@link CommandArgument}. This shouldn't be used unless you absolutely have no information -
     * ESPECIALLY not with {@link CommandInvalidArgumentException}s
     *
     * @return The unknown {@link CommandArgument}
     */
    public static CommandArgument unknown() {
        return new CommandArgument(-1, "<unknown>", "");
    }
}
