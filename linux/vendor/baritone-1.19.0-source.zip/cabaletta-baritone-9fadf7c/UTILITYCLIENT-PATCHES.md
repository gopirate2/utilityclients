UtilityClient local repairs, 2026-11-20.
Based on official Baritone v1.19.0 (Minecraft 26.2); LGPL-3.0 retained.
Modified areas: cache/executor shutdown and final flush; negative-Y special blocks, top height, flow policy and scan bounds;
waypoint/position equality and hashes; goal distance overflow and bounded arrival heuristics;
exact fill states, cylinder dimensions and nested schematic reset; empty collection settings and independent defaults;
block-removal invalidation, deferred inventory success, calculation ownership; quoted/escaped arguments,
class-based datatype peeks, file completion and explore-filter base paths.
Caches now use a new _uc2 directory suffix; existing caches are preserved.
Matching modified sources accompany every distributed binary in baritone-1.19.0-source.zip.
