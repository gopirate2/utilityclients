// language: Java, file: HudRenderer.java, target: Fabric 26.2
package com.baggute.cheatclient.render;

import com.baggute.cheatclient.UtilityClient;
import com.baggute.cheatclient.module.Module;
import com.baggute.cheatclient.module.misc.Hud;
import com.baggute.cheatclient.module.misc.Notifications;
import com.baggute.cheatclient.module.render.ArrayListModule;
import com.baggute.cheatclient.module.render.Nametags;
import com.baggute.cheatclient.module.render.TargetHud;
import com.baggute.cheatclient.util.ModuleUtils;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.item.ItemStack;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public final class HudRenderer {

    private HudRenderer() {}

    public static void render(GuiGraphicsExtractor g) {
        if (UtilityClient.moduleManager == null) return;

        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null) return;

        drawWidgets(g, mc);
        drawArrayList(g, mc);
        drawDebugBoard(g, mc);
        Notifications.render(g, mc);
    }

    /** Stage board: one line per automation module currently mid-action. */
    private static void drawDebugBoard(GuiGraphicsExtractor g, Minecraft mc) {
        Module module = UtilityClient.moduleManager.getByName("Debug");
        if (!(module instanceof com.baggute.cheatclient.module.misc.Debug debug)) return;
        if (!debug.isOverlayOn()) return;

        java.util.List<String> lines = com.baggute.cheatclient.module.misc.Debug.snapshot();
        if (lines.isEmpty()) return;

        int lineH = 10;
        int pad = 4;
        int width = 0;
        for (String line : lines) width = Math.max(width, mc.font.width(line));

        int bx = 6;
        int by = mc.getWindow().getGuiScaledHeight() - (lines.size() * lineH) - pad * 2 - 6;
        g.fill(bx - 2, by - 2, bx + width + pad * 2, by + lines.size() * lineH + pad, 0xC0101216);
        g.fill(bx - 2, by - 2, bx, by + lines.size() * lineH + pad, 0xFF7C9CFF);

        for (int i = 0; i < lines.size(); i++) {
            g.text(mc.font, lines.get(i), bx + 2, by + i * lineH, 0xFFE7E9EE, false);
        }
    }

    // ---- widgets ----

    private static void drawWidgets(GuiGraphicsExtractor g, Minecraft mc) {
        Module module = UtilityClient.moduleManager.getByName("Hud");
        if (!(module instanceof Hud hud) || !hud.isEnabled()) return;

        double scale = hud.getScale();
        g.pose().pushMatrix();
        g.pose().scale((float) scale, (float) scale);

        for (Hud.Widget widget : Hud.Widget.values()) {
            if (!hud.isWidgetEnabled(widget)) continue;

            List<String> lines = linesFor(widget, mc, hud);
            int originX = hud.getX(widget);
            int originY = hud.getY(widget);
            double widgetScale = hud.getWidgetScale(widget);

            if (lines.isEmpty()) {
                hud.setBounds(widget, originX, originY, 0, 10);
                continue;
            }

            int maxWidth = 0;
            for (String line : lines) maxWidth = Math.max(maxWidth, mc.font.width(line));

            g.pose().pushMatrix();
            g.pose().translate((float) originX, (float) originY);
            g.pose().scale((float) widgetScale, (float) widgetScale);

            if (hud.hasWidgetBackground(widget)) {
                g.fill(-2, -2, maxWidth + 4, lines.size() * 10 + 2, 0x80000000);
            }

            int color = hud.getWidgetColor(widget);
            int y = 0;
            for (String line : lines) {
                // Armour rows render as a piece icon plus durability, not the item
                // id text: reading "diamond_chestplate 87%" mid-fight is nonsense.
                if (widget == Hud.Widget.ARMOR && line.startsWith(ICON_MARK)) {
                    drawArmorRow(g, mc, line.substring(ICON_MARK.length()), color, y);
                } else {
                    g.text(mc.font, line, 0, y, color, true);
                }
                y += 10;
            }

            g.pose().popMatrix();
            hud.setBounds(widget, originX, originY,
                    (int) (maxWidth * widgetScale), (int) (lines.size() * 10 * widgetScale));
        }

        g.pose().popMatrix();
    }

    private static List<String> linesFor(Hud.Widget widget, Minecraft mc, Hud hud) {
        List<String> lines = new ArrayList<>();

        switch (widget) {
            case MODULES -> {
                Set<String> hidden = parseCsv(hud.getHiddenSetting().get());
                List<String> enabled = new ArrayList<>();
                for (Module m : UtilityClient.moduleManager.getModules()) {
                    if (m.isEnabled() && !hidden.contains(m.getName())) enabled.add(m.getName());
                }
                enabled.sort(String.CASE_INSENSITIVE_ORDER);
                lines.addAll(enabled);
            }
            case COORDS -> lines.add("X: " + (int) Math.floor(mc.player.getX())
                    + "  Y: " + (int) Math.floor(mc.player.getY())
                    + "  Z: " + (int) Math.floor(mc.player.getZ()));
            case ARMOR -> {
                try {
                    for (int slot = 36; slot <= 39; slot++) {
                        ItemStack stack = mc.player.getInventory().getItem(slot);
                        if (stack.isEmpty()) continue;
                        // The marker carries the item name; drawArmorRow draws the glyph
                        // from it and prints the percentage beside it.
                        lines.add(ICON_MARK + BuiltInRegistries.ITEM
                                .getKey(stack.getItem()).getPath() + "|" + durability(stack));
                    }
                } catch (RuntimeException ignored) {
                    // Armour slot indexing has moved between versions; report it
                    // instead of throwing out of the HUD render.
                }
                if (lines.isEmpty()) lines.add("armor: n/a");
            }
            case POTIONS -> {
                java.util.Collection<MobEffectInstance> effects = mc.player.getActiveEffects();
                lines.add(effects.isEmpty() ? "effects: none" : "effects: " + effects.size());
            }
            case COUNTERS -> {
                String counters = hud.getItemCounters();
                if (counters == null || counters.isBlank()) lines.add("counters: none");
                else {
                    for (String raw : counters.split(",")) {
                        String id = raw.trim();
                        if (id.isEmpty()) continue;
                        lines.add(id + ": " + countItem(mc, id));
                    }
                }
            }
            case NAMETAGS -> {
                Nametags tags = module("Nametags") instanceof Nametags n && n.isEnabled() ? n : null;
                if (tags == null) break;
                double range = tags.getRange();
                java.util.List<String> rows = new java.util.ArrayList<>();
                for (var entity : mc.level.entitiesForRendering()) {
                    if (!(entity instanceof net.minecraft.world.entity.player.Player p) || p == mc.player) continue;
                    double dist = p.distanceTo(mc.player);
                    if (dist > range) continue;
                    StringBuilder row = new StringBuilder(p.getName().getString());
                    if (tags.showHealth()) row.append(" ").append((int) Math.ceil(p.getHealth())).append("h");
                    if (tags.showDistance()) row.append(" ").append(String.format("%.1fm", dist));
                    rows.add(row.toString());
                }
                java.util.Collections.sort(rows);
                int limit = Math.min(rows.size(), tags.maxEntries());
                for (int i = 0; i < limit; i++) lines.add(rows.get(i));
                if (rows.isEmpty()) lines.add("nobody nearby");
            }
            case TARGET_HUD -> {
                TargetHud hudModule = module("TargetHud") instanceof TargetHud t && t.isEnabled() ? t : null;
                if (hudModule == null) break;
                var target = nearestPlayer(mc, hudModule.getRange());
                if (target == null) { lines.add("target: none"); break; }
                lines.add(target.getName().getString());
                lines.add("hp " + (int) Math.ceil(target.getHealth()) + "/" + (int) target.getMaxHealth());
                if (hudModule.showArmor()) lines.add("armor " + target.getArmorValue());
                if (hudModule.showDistance()) lines.add(String.format("%.1fm", target.distanceTo(mc.player)));
            }
            case TRAJECTORY -> {
                com.baggute.cheatclient.module.render.Trajectory trajectory =
                        module("Trajectory") instanceof com.baggute.cheatclient.module.render.Trajectory t
                                && t.isEnabled() ? t : null;
                if (trajectory == null) break;
                float pitch = mc.player.getXRot();
                double[] path = com.baggute.cheatclient.module.render.Trajectory.predict(
                        pitch, 3.0, trajectory.ticks());
                lines.add(String.format("range %.1fm", path[0]));
                lines.add(String.format("drop %.1f", path[1]));
                if (trajectory.showPitch()) lines.add(String.format("pitch %.0f", -pitch));
            }
            case POTIONS_COUNTER -> {
                java.util.Map<String, Integer> counts = new java.util.LinkedHashMap<>();
                // getContainerSize() includes the offhand slot (index 40 in 26.2);
                // a hardcoded 40 dropped an offhand potion from the count.
                int slots = mc.player.getInventory().getContainerSize();
                for (int slot = 0; slot < slots; slot++) {
                    ItemStack stack = mc.player.getInventory().getItem(slot);
                    if (stack.isEmpty() || !ModuleUtils.matches(stack, "potion")) continue;
                    String id = potionId(stack);
                    if (id.isEmpty()) continue;
                    counts.merge(id, stack.getCount(), Integer::sum);
                }

                Set<String> filter = parseCsv(hud.getPotionFilter());
                for (var entry : counts.entrySet()) {
                    if (!filter.isEmpty() && !filter.contains(entry.getKey())) continue;
                    lines.add(trimPrefix(entry.getKey()) + ": " + entry.getValue());
                }
                if (lines.isEmpty()) lines.add("potions: none");
            }
            case KEYSTROKES -> {
                lines.add(key(mc.options.keyUp.isDown()) + " " + key(mc.options.keyDown.isDown())
                        + " " + key(mc.options.keyLeft.isDown()) + " " + key(mc.options.keyRight.isDown()));
                lines.add("LMB " + key(mc.options.keyAttack.isDown())
                        + "  RMB " + key(mc.options.keyUse.isDown()));
            }
            case FPS -> lines.add(mc.getFps() + " fps");
            case PING -> {
                int ping = -1;
                if (mc.getConnection() != null && mc.player != null) {
                    var info = mc.getConnection().getPlayerInfo(mc.player.getUUID());
                    if (info != null) ping = info.getLatency();
                }
                lines.add(ping < 0 ? "ping --" : "ping " + ping + "ms");
            }
            case CLOCK -> lines.add(java.time.LocalTime.now()
                    .format(java.time.format.DateTimeFormatter.ofPattern("HH:mm:ss")));
            case SPEED -> {
                net.minecraft.world.phys.Vec3 velocity = mc.player.getDeltaMovement();
                double blocksPerSecond = Math.sqrt(velocity.x * velocity.x + velocity.z * velocity.z) * 20.0;
                lines.add(String.format("%.1f b/s", blocksPerSecond));
            }
            default -> { }
        }
        return lines;
    }

    private static Module module(String name) {
        for (var m : com.baggute.cheatclient.UtilityClient.moduleManager.getModules()) {
            if (m.getName().equals(name)) return m;
        }
        return null;
    }

    private static net.minecraft.world.entity.player.Player nearestPlayer(Minecraft mc, double range) {
        if (mc.player == null || mc.level == null) return null;
        net.minecraft.world.entity.player.Player best = null;
        double bestDist = range * range;
        for (var entity : mc.level.entitiesForRendering()) {
            if (!(entity instanceof net.minecraft.world.entity.player.Player p) || p == mc.player) continue;
            if (p.getHealth() <= 0) continue;
            double d = p.distanceToSqr(mc.player);
            if (d < bestDist) { bestDist = d; best = p; }
        }
        return best;
    }

    private static String potionId(ItemStack stack) {
        try {
            var contents = stack.get(net.minecraft.core.component.DataComponents.POTION_CONTENTS);
            if (contents == null) return "";
            var potion = contents.potion();
            if (potion.isEmpty()) return "";
            var key = BuiltInRegistries.POTION.getKey(potion.get().value());
            return key == null ? "" : key.toString();
        } catch (Throwable ignored) {
            return "";
        }
    }

    private static String trimPrefix(String id) {
        int colon = id.indexOf(':');
        return colon >= 0 ? id.substring(colon + 1) : id;
    }

    private static String key(boolean down) {
        return down ? "[#]" : "[ ]";
    }

    /** Marks a HUD line that must be drawn as an icon instead of text. */
    private static final String ICON_MARK = "\u0001";

    /**
     * One armour piece: an 8x8 glyph in the material's own colour, then the
     * durability percentage.
     *
     * <p>Drawn with {@code fill} rather than an item renderer on purpose. Item
     * rendering inside the HUD extractor needs a live item render state that does
     * not exist this early in the frame, and a missing icon is a far worse failure
     * than a plain one.
     */
    private static void drawArmorRow(GuiGraphicsExtractor g, Minecraft mc, String payload, int color, int y) {
        int bar = payload.indexOf('|');
        String id = bar < 0 ? payload : payload.substring(0, bar);
        String label = bar < 0 ? "" : payload.substring(bar + 1);

        int tint = materialColor(id);
        byte[] mask = slotMask(id);

        for (int row = 0; row < 8; row++) {
            for (int col = 0; col < 8; col++) {
                if ((mask[row] & (0x80 >>> col)) == 0) continue;
                g.fill(col, y + row, col + 1, y + row + 1, tint);
            }
        }

        if (!label.isEmpty()) {
            g.text(mc.font, label, 10, y, color, true);
        }
    }

    /** Bitmap of the armour slot, one byte per row, MSB = leftmost pixel. */
    private static byte[] slotMask(String id) {
        if (id.contains("helmet") || id.contains("cap") || id.contains("skull")) {
            return new byte[]{(byte) 0x3C, (byte) 0x7E, (byte) 0xFF, (byte) 0xFF,
                    (byte) 0xFF, (byte) 0xE7, (byte) 0xE7, (byte) 0x00};
        }
        if (id.contains("leggings") || id.contains("pants")) {
            return new byte[]{(byte) 0xFF, (byte) 0xFF, (byte) 0xC3, (byte) 0xC3,
                    (byte) 0xC3, (byte) 0xC3, (byte) 0xC3, (byte) 0x00};
        }
        if (id.contains("boots")) {
            return new byte[]{(byte) 0x00, (byte) 0x00, (byte) 0xC3, (byte) 0xC3,
                    (byte) 0xC3, (byte) 0xFF, (byte) 0xFF, (byte) 0x00};
        }
        // Chestplate (and anything unrecognised): a torso silhouette.
        return new byte[]{(byte) 0xE7, (byte) 0xFF, (byte) 0xFF, (byte) 0xFF,
                (byte) 0xFF, (byte) 0xFF, (byte) 0xE7, (byte) 0x00};
    }

    /** Material colour, so netherite and iron are distinguishable at a glance. */
    private static int materialColor(String id) {
        if (id.contains("netherite")) return 0xFF4A3F3A;
        if (id.contains("diamond"))   return 0xFF4AEDD9;
        if (id.contains("gold"))      return 0xFFF0C24A;
        if (id.contains("iron"))      return 0xFFD8D8D8;
        if (id.contains("chain"))     return 0xFF8A8A8A;
        if (id.contains("leather"))   return 0xFF9C6B3F;
        if (id.contains("turtle"))    return 0xFF3FA34D;
        return 0xFFB0B0B0;
    }

    private static String durability(ItemStack stack) {
        if (!stack.isDamageableItem()) return "";
        int max = stack.getMaxDamage();
        int left = max - stack.getDamageValue();
        int pct = max <= 0 ? 0 : (int) (100L * left / max);
        return pct + "%";
    }

    // ---- array list ----

    private static void drawArrayList(GuiGraphicsExtractor g, Minecraft mc) {
        Module module = UtilityClient.moduleManager.getByName("ArrayList");
        if (module instanceof ArrayListModule list) list.renderList(g, mc);
    }

    private static Set<String> parseCsv(String csv) {
        Set<String> out = new HashSet<>();
        if (csv == null) return out;
        for (String p : csv.split(",")) {
            String t = p.trim();
            if (!t.isEmpty()) out.add(t);
        }
        return out;
    }

    private static int countItem(Minecraft mc, String id) {
        int total = 0;
        for (int i = 0; i < 36; i++) {
            ItemStack stack = mc.player.getInventory().getItem(i);
            if (BuiltInRegistries.ITEM.getKey(stack.getItem()).toString().equals(id)) total += stack.getCount();
        }
        ItemStack offhand = mc.player.getOffhandItem();
        if (BuiltInRegistries.ITEM.getKey(offhand.getItem()).toString().equals(id)) total += offhand.getCount();
        return total;
    }
}
