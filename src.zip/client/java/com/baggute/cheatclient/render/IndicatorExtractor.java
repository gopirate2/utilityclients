package com.baggute.cheatclient.render;

import com.baggute.cheatclient.UtilityClient;
import com.baggute.cheatclient.module.render.ArmorIndicators;
import com.baggute.cheatclient.module.render.HealthIndicators;
import net.minecraft.client.renderer.state.level.LevelRenderState;
import net.minecraft.gizmos.Gizmos;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;

public final class IndicatorExtractor {

    private static final EquipmentSlot[] ARMOR_SLOTS = {
            EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET
    };

    private IndicatorExtractor() {}

    public static void emit(LevelRenderState state) {
        if (UtilityClient.moduleManager == null) return;
        var mc = net.minecraft.client.Minecraft.getInstance();
        if (mc.level == null || mc.player == null) return;

        HealthIndicators h = (HealthIndicators) UtilityClient.moduleManager.getByName("HealthIndicators");
        ArmorIndicators a = (ArmorIndicators) UtilityClient.moduleManager.getByName("ArmorIndicators");
        Vec3 cam = state.cameraRenderState.pos;

        // distanceToSqr() is squared, so the limit has to be squared as well.
        double maxRangeSq = maxRangeSq(h, a);

        for (var e : mc.level.entitiesForRendering()) {
            if (!(e instanceof LivingEntity le) || e == mc.player) continue;
            double distSq = e.distanceToSqr(cam);
            if (distSq > maxRangeSq) continue;

            double y = le.getY() + le.getBbHeight() + 0.15;
            double width = le.getBbWidth() * 0.6 * (h != null && h.isEnabled() ? h.getScale() : 1.0);

            if (h != null && h.isEnabled() && distSq <= h.getRange() * h.getRange()) {
                double health = Math.max(0, Math.min(1, le.getHealth() / Math.max(1, le.getMaxHealth())));
                bar(le.getX(), y, le.getZ(), width, health, h.getColor());
            }

            if (a != null && a.isEnabled() && le instanceof Player p && distSq <= a.getRange() * a.getRange()) {
                int total = 0, max = 0;
                for (EquipmentSlot slot : ARMOR_SLOTS) {
                    ItemStack s = p.getItemBySlot(slot);
                    if (s.isEmpty()) continue;
                    total += s.getMaxDamage() - s.getDamageValue();
                    max += s.getMaxDamage();
                }
                bar(le.getX(), y + 0.08 * a.getScale(), le.getZ(), width * a.getScale(),
                        max == 0 ? 0 : (double) total / max, a.getColor());
            }
        }
    }

    private static double maxRangeSq(HealthIndicators h, ArmorIndicators a) {
        double range = 0;
        if (h != null && h.isEnabled()) range = h.getRange();
        if (a != null && a.isEnabled()) range = Math.max(range, a.getRange());
        return range * range;
    }

    private static void bar(double x, double y, double z, double w, double value, int color) {
        double half = w / 2;
        Gizmos.line(new Vec3(x - half, y, z), new Vec3(x + half, y, z), 0x40202020, 3F).setAlwaysOnTop();
        Gizmos.line(new Vec3(x - half, y, z), new Vec3(x - half + w * value, y, z), color, 3F).setAlwaysOnTop();
    }
}
