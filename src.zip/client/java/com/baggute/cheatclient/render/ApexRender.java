// language: Java, file: ApexRender.java, target: Fabric 26.2
package com.baggute.cheatclient.render;

import com.baggute.cheatclient.UtilityClient;
import com.baggute.cheatclient.module.Module;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.state.level.LevelRenderState;
import net.minecraft.core.BlockPos;
import net.minecraft.gizmos.Gizmos;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayDeque;
import java.util.Deque;

/**
 * 3D layer for the apex visual entries. Everything here rides the same Gizmos
 * collector the ESP modules already use, so nothing new has to be submitted to the
 * render pipeline.
 */
public final class ApexRender {

    private static final Deque<Vec3> TRAIL = new ArrayDeque<>();
    private static final int TRAIL_MAX = 28;

    private ApexRender() {}

    public static void emit(LevelRenderState state) {
        if (UtilityClient.moduleManager == null) return;

        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null) return;

        if (on("DashTrails")) dashTrails(mc);
        else TRAIL.clear();

        if (on("ObsidianGlow")) obsidianGlow(mc);
        if (on("MaceImpact")) maceImpact(mc);
    }

    private static boolean on(String name) {
        Module module = UtilityClient.moduleManager.getByName(name);
        return module != null && module.isEnabled();
    }

    /** A fading ribbon behind the player while they move. */
    private static void dashTrails(Minecraft mc) {
        Vec3 now = mc.player.position();
        // A respawn, portal or teleport jumps the player across the world; joining
        // the new position to the stale points drew one ribbon across the map.
        if (!TRAIL.isEmpty() && TRAIL.peekLast().distanceToSqr(now) > 64.0) {
            TRAIL.clear();
        }
        if (TRAIL.isEmpty() || TRAIL.peekLast().distanceToSqr(now) > 0.04) {
            TRAIL.addLast(now);
            while (TRAIL.size() > TRAIL_MAX) TRAIL.removeFirst();
        }
        if (TRAIL.size() < 2) return;

        Vec3 previous = null;
        int index = 0;
        for (Vec3 point : TRAIL) {
            if (previous != null) {
                float fade = (float) index / TRAIL.size();
                int alpha = (int) (0x30 + fade * 0xB0);
                int color = (alpha << 24) | 0x7C9CFF;
                Gizmos.line(previous.add(0, 0.1, 0), point.add(0, 0.1, 0), color, 2.0F);
            }
            previous = point;
            index++;
        }
    }

    /** Outlines obsidian around you so anchor spots read at a glance. */
    private static void obsidianGlow(Minecraft mc) {
        BlockPos origin = mc.player.blockPosition();
        int drawn = 0;

        for (BlockPos pos : BlockPos.betweenClosed(origin.offset(-8, -4, -8), origin.offset(8, 4, 8))) {
            if (drawn >= 24) break;
            if (!mc.level.getBlockState(pos).is(Blocks.OBSIDIAN)) continue;

            box(new Vec3(pos.getX(), pos.getY(), pos.getZ()),
                    new Vec3(pos.getX() + 1, pos.getY() + 1, pos.getZ() + 1), 0xC0A78BFA);
            drawn++;
        }
    }

    /** Expanding rings on the ground when a mace hit lands nearby. */
    private static void maceImpact(Minecraft mc) {
        String hand = mc.player.getMainHandItem().getItem().toString().toLowerCase();
        if (!hand.contains("mace")) return;

        for (Entity entity : mc.level.entitiesForRendering()) {
            if (!(entity instanceof Player target) || target == mc.player) continue;
            if (target.hurtTime <= 0) continue;
            if (target.distanceToSqr(mc.player) > 36) continue;

            double x = target.getX();
            double y = target.getY() + 0.05;
            double z = target.getZ();
            double radius = 0.6 + (1.0 - target.hurtTime / 10.0) * 1.4;
            int segments = 20;

            for (int i = 0; i < segments; i++) {
                double a1 = (double) i / segments * Math.PI * 2;
                double a2 = (double) (i + 1) / segments * Math.PI * 2;
                Gizmos.line(
                        new Vec3(x + Math.cos(a1) * radius, y, z + Math.sin(a1) * radius),
                        new Vec3(x + Math.cos(a2) * radius, y, z + Math.sin(a2) * radius),
                        0xD0F87171, 2.5F).setAlwaysOnTop();
            }
            return;
        }
    }

    private static void box(Vec3 min, Vec3 max, int color) {
        Vec3[] corners = {
                new Vec3(min.x, min.y, min.z), new Vec3(max.x, min.y, min.z),
                new Vec3(max.x, min.y, max.z), new Vec3(min.x, min.y, max.z),
                new Vec3(min.x, max.y, min.z), new Vec3(max.x, max.y, min.z),
                new Vec3(max.x, max.y, max.z), new Vec3(min.x, max.y, max.z)
        };
        int[][] edges = {
                {0, 1}, {1, 2}, {2, 3}, {3, 0},
                {4, 5}, {5, 6}, {6, 7}, {7, 4},
                {0, 4}, {1, 5}, {2, 6}, {3, 7}
        };
        for (int[] edge : edges) {
            Gizmos.line(corners[edge[0]], corners[edge[1]], color, 1.5F).setAlwaysOnTop();
        }
    }
}
