package com.baggute.cheatclient.event.events;

public final class WorldUnloadEvent {
}