// language: Java, file: UtilityClient.java, target: Fabric 26.2
package com.baggute.cheatclient;

import com.baggute.cheatclient.event.EventBus;
import com.baggute.cheatclient.event.events.KeyEvent;
import com.baggute.cheatclient.event.events.WorldLoadEvent;
import com.baggute.cheatclient.event.events.WorldUnloadEvent;
import com.baggute.cheatclient.gui.ClickGuiScreen;
import com.baggute.cheatclient.config.ConfigManager;
import com.baggute.cheatclient.module.ModuleManager;
import kaptainwutax.seedcrackerX.SeedCracker;
import kaptainwutax.seedcrackerX.config.Config;
import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.fabricmc.fabric.api.client.message.v1.ClientSendMessageEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import com.baggute.cheatclient.util.LookupCommand;
import com.baggute.cheatclient.util.PlayerSnapshots;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.resources.Identifier;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class UtilityClient implements ClientModInitializer {

    public static final String MOD_ID = "utilityclient";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    public static UtilityClient INSTANCE;
    public static ModuleManager moduleManager;
    public static EventBus eventBus;

    /**
     * True when an agent loaded this class into a game that is already running.
     *
     * <p>Fabric's key-mapping registry is a load-time structure: registering into
     * it after {@code GameOptions} exists throws
     * {@code IllegalStateException: GameOptions has already been initialised}.
     * Late init therefore skips the registry entirely and reads GLFW directly.
     */
    public static final boolean LATE_INIT = Boolean.getBoolean("utilityclient.lateInit");

    public static final KeyMapping.Category CATEGORY = LATE_INIT ? null : KeyMapping.Category.register(
            Identifier.fromNamespaceAndPath(MOD_ID, "gui")
    );

    private KeyMapping guiKeyBinding;
    private KeyMapping altGuiKeyBinding;
    private KeyMapping terminalKeyBinding;
    private static ConfigManager configManager;

    /** Persists module state and settings. Called when the click GUI closes. */
    public static void saveConfig() {
        if (configManager != null) configManager.save();
    }

    public static ConfigManager configManager() {
        return configManager;
    }

    @Override
    public void onInitializeClient() {
        INSTANCE = this;
        eventBus = new EventBus();
        moduleManager = new ModuleManager();
        moduleManager.init();
        // SeedCrackerX must load its own config before the module config is applied:
        // enabling the SeedCrackerX module calls Config.save(), which would otherwise
        // overwrite seedcracker.json with defaults that were never loaded.
        // SeedCrackerX is a vendored copy of someone else's mod and its version
        // tables stop at 1.21. On 26.2 every structure type throws in Features.init.
        // It must never take the client down with it: if it fails, the client still
        // boots and the SeedCrackerX module simply has nothing to find with.
        try {
            new SeedCracker().onInitialize();
        } catch (Throwable failure) {
            LOGGER.error("[UtilityClient] SeedCrackerX init failed; continuing without it", failure);
        }
        configManager = new ConfigManager(moduleManager);
        configManager.load();
        if (moduleManager.getSeedCrackerX() != null) {
            moduleManager.getSeedCrackerX().setEnabled(Config.get().active);
        }

        if (!LATE_INIT) {
            // Right Shift is the loader-style default; Right Ctrl stays as an alias.
            guiKeyBinding = KeyMappingHelper.registerKeyMapping(new KeyMapping(
                    "key.utilityclient.gui",
                    InputConstants.Type.KEYSYM,
                    GLFW.GLFW_KEY_RIGHT_SHIFT,
                    CATEGORY
            ));
            altGuiKeyBinding = KeyMappingHelper.registerKeyMapping(new KeyMapping(
                    "key.utilityclient.gui.alt",
                    InputConstants.Type.KEYSYM,
                    GLFW.GLFW_KEY_RIGHT_CONTROL,
                    CATEGORY
            ));
            terminalKeyBinding = KeyMappingHelper.registerKeyMapping(new KeyMapping(
                    "key.utilityclient.terminal",
                    InputConstants.Type.KEYSYM,
                    GLFW.GLFW_KEY_GRAVE_ACCENT,
                    CATEGORY
            ));
        }

        // An agent may have marked this JVM before the client initialized.
        if (Boolean.getBoolean(com.baggute.cheatclient.injector.InjectorBridge.INJECTED_PROPERTY)) {
            com.baggute.cheatclient.injector.InjectorBridge.mark(
                    System.getProperty(com.baggute.cheatclient.injector.InjectorBridge.MODE_PROPERTY));
        }

        eventBus.subscribe(KeyEvent.class, this::onKey);

        ClientPlayConnectionEvents.JOIN.register((handler, sender, client) ->
                eventBus.post(new WorldLoadEvent()));
        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> {
            PlayerSnapshots.clear();
            eventBus.post(new WorldUnloadEvent());
        });

        // Client-side chat commands. Returning false consumes the message, so a
        // leading dot behaves like a slash without ever reaching the server.
        ClientSendMessageEvents.ALLOW_CHAT.register(message -> !LookupCommand.handle(message));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (!client.isPaused()) moduleManager.onTick();
            PlayerSnapshots.tick(client);
            if (LATE_INIT) {
                pollKeysDirectly(client);
            } else {
                while (guiKeyBinding.consumeClick() || altGuiKeyBinding.consumeClick()) toggleGui();
                while (terminalKeyBinding.consumeClick()) openTerminal();
            }
        });
        ClientLifecycleEvents.CLIENT_STOPPING.register(client -> {
            if (configManager != null) configManager.save();
        });

        // An injected, stealth session leaves no init line in latest.log.
        if (!Boolean.getBoolean("utilityclient.stealth")) {
            LOGGER.info("[UtilityClient] initialized");
        }
    }

    // ---- late init: no registry, so read the keyboard itself ----

    private boolean guiKeyDown;
    private boolean terminalKeyDown;

    /**
     * Edge-detects the same defaults without a KeyMapping. Nothing here touches
     * the input registry, so it is safe to run in a game that is already up.
     */
    private void pollKeysDirectly(Minecraft mc) {
        if (mc.getWindow() == null) return;

        boolean guiDown = InputConstants.isKeyDown(mc.getWindow(), GLFW.GLFW_KEY_RIGHT_SHIFT)
                || InputConstants.isKeyDown(mc.getWindow(), GLFW.GLFW_KEY_RIGHT_CONTROL);
        if (guiDown && !guiKeyDown && mc.gui.screen() == null) toggleGui();
        guiKeyDown = guiDown;

        boolean terminalDown = InputConstants.isKeyDown(mc.getWindow(), GLFW.GLFW_KEY_GRAVE_ACCENT);
        if (terminalDown && !terminalKeyDown) openTerminal();
        terminalKeyDown = terminalDown;
    }

    private static void toggleGui() {
        Minecraft mc = Minecraft.getInstance();
        // Pressing the GUI key again while it is open closes it.
        if (mc.gui.screen() instanceof ClickGuiScreen) mc.gui.setScreen(null);
        else mc.gui.setScreen(new ClickGuiScreen());
    }

    private static void openTerminal() {
        Minecraft mc = Minecraft.getInstance();
        if (!(mc.gui.screen() instanceof com.baggute.cheatclient.gui.TerminalScreen)) {
            mc.gui.setScreen(new com.baggute.cheatclient.gui.TerminalScreen());
        }
    }

    private void onKey(KeyEvent event) {
        // Suppress module toggles while any screen is open — pressing a key to set
        // a keybind in the GUI would otherwise toggle every module bound to it.
        Minecraft mc = Minecraft.getInstance();
        if (mc.gui.screen() != null || mc.isPaused()) return;
        moduleManager.onKey(event.getKey(), event.getAction());
    }
}
