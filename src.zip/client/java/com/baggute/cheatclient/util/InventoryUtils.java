package com.baggute.cheatclient.util;

import net.minecraft.client.Minecraft;
import net.minecraft.world.inventory.ContainerInput;

public final class InventoryUtils {
    private InventoryUtils() {}

    public static boolean swapPlayerSlots(Minecraft mc, int inventorySlot, int menuSlot) {
        if (mc.player == null || mc.gameMode == null) return false;
        // Never start a triple-click while something is already on the cursor.
        if (!mc.player.containerMenu.getCarried().isEmpty()) return false;
        int container = mc.player.containerMenu.containerId;
        mc.gameMode.handleContainerInput(container, inventorySlot, 0, ContainerInput.PICKUP, mc.player);
        mc.gameMode.handleContainerInput(container, menuSlot, 0, ContainerInput.PICKUP, mc.player);
        mc.gameMode.handleContainerInput(container, inventorySlot, 0, ContainerInput.PICKUP, mc.player);
        return true;
    }

    public static int hotbarMenuSlot(int hotbarIndex) { return 36 + hotbarIndex; }
    public static int offhandMenuSlot() { return 45; }
}
