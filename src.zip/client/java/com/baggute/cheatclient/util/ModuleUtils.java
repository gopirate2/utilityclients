package com.baggute.cheatclient.util;

import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;

public final class ModuleUtils {
    private ModuleUtils() {}
    public static int findHotbarItem(Minecraft mc, String... names) {
        for (int i = 0; i < 9; i++) if (matches(mc.player.getInventory().getItem(i), names)) return i;
        return -1;
    }
    public static boolean matches(ItemStack stack, String... names) {
        if (stack == null || stack.isEmpty()) return false;
        String n = stack.getItem().toString().toLowerCase();
        for (String name : names) if (n.contains(name.toLowerCase())) return true;
        return false;
    }
    public static Player nearestPlayer(Minecraft mc, double range) {
        if (mc.level == null || mc.player == null) return null;
        Player best = null; double bestDist = range * range;
        for (Entity e : mc.level.entitiesForRendering()) {
            if (e instanceof Player p && p != mc.player && p.isAlive()) {
                double d = p.distanceToSqr(mc.player);
                if (d <= bestDist) { bestDist = d; best = p; }
            }
        }
        return best;
    }
    public static void select(Minecraft mc, int slot) {
        if (slot >= 0 && slot < 9) mc.player.getInventory().setSelectedSlot(slot);
    }
}
