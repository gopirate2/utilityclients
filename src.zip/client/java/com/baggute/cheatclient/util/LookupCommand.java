// language: Java, file: LookupCommand.java, target: Fabric 26.2
package com.baggute.cheatclient.util;

import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;

import java.util.List;
import java.util.Locale;

/**
 * Client-side chat command. A message starting with "." is consumed before it is
 * ever sent — the chat screen behaves as if it had started with "/", except the
 * command runs entirely on this client.
 *
 *   .lookup <name>   gear, durability, enchants and health
 *   .lookup          the last player you looked at
 *   .lookup list     everyone currently cached
 */
public final class LookupCommand {

    private static final String PREFIX = ".";
    private static final String ROOT = "lookup";

    private static String lastQuery = "";

    private LookupCommand() {}

    /**
     * @return true when the message was consumed and must not reach the server.
     */
    public static boolean handle(String message) {
        if (message == null || !message.startsWith(PREFIX)) return false;

        String trimmed = message.trim();
        String[] parts = trimmed.split("\\s+");
        String command = parts[0].substring(1).toLowerCase(Locale.ROOT);

        if (!command.equals(ROOT)) {
            // Any dot-prefixed message is a client command: report it instead of
            // letting it fall through to server chat.
            say("unknown command: ." + command + "  (try .lookup)", ChatFormatting.GRAY);
            return true;
        }

        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return true;

        String argument = parts.length > 1 ? parts[1] : "";
        if (argument.equalsIgnoreCase("list")) {
            printList();
            return true;
        }

        String query = argument.isEmpty() ? lastQuery : argument;
        if (query.isEmpty()) {
            say("usage: .lookup <player>", ChatFormatting.GRAY);
            return true;
        }
        lastQuery = query;

        PlayerSnapshots.Snapshot snapshot = PlayerSnapshots.find(query);
        if (snapshot == null) {
            say("no data for '" + query + "' — not seen yet", ChatFormatting.RED);
            return true;
        }

        print(snapshot, PlayerSnapshots.isOnline(mc, snapshot.name()));
        return true;
    }

    private static void print(PlayerSnapshots.Snapshot s, boolean online) {
        String age = online ? "live" : age(s.stamp());

        say("── " + s.name() + "  (" + age + ") ──", ChatFormatting.AQUA);
        say(String.format("hp %.1f / %.0f", s.health(), s.maxHealth()),
                s.health() / Math.max(1f, s.maxHealth()) < 0.35f
                        ? ChatFormatting.RED : ChatFormatting.GREEN);

        boolean anyArmor = false;
        for (PlayerSnapshots.Piece piece : s.armor()) {
            if (piece.isEmpty()) continue;
            anyArmor = true;
            say(piece.line(), durabilityColor(piece));
        }
        if (!anyArmor) say("armour      none", ChatFormatting.DARK_GRAY);

        for (PlayerSnapshots.Piece piece : s.tools()) {
            if (piece.isEmpty()) continue;
            say(piece.line(), durabilityColor(piece));
        }
    }

    private static ChatFormatting durabilityColor(PlayerSnapshots.Piece piece) {
        if (piece.max() <= 0) return ChatFormatting.WHITE;
        double frac = (double) piece.remaining() / piece.max();
        if (frac < 0.2) return ChatFormatting.RED;
        if (frac < 0.5) return ChatFormatting.YELLOW;
        return ChatFormatting.WHITE;
    }

    private static void printList() {
        List<String> names = PlayerSnapshots.names();
        if (names.isEmpty()) {
            say("cache is empty — nobody seen yet", ChatFormatting.GRAY);
            return;
        }
        say("cached: " + String.join(", ", names), ChatFormatting.GRAY);
    }

    private static String age(long stamp) {
        long seconds = Math.max(0, (System.currentTimeMillis() - stamp) / 1000);
        if (seconds < 60) return "seen " + seconds + "s ago";
        if (seconds < 3600) return "seen " + (seconds / 60) + "m ago";
        return "seen " + (seconds / 3600) + "h ago";
    }

    private static void say(String text, ChatFormatting color) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.gui == null) return;
        mc.gui.chatListener().handleSystemMessage(
                Component.literal(text).withStyle(color), false);
    }
}
