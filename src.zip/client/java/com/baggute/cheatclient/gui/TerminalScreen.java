// language: Java, file: TerminalScreen.java, target: Fabric 26.2
package com.baggute.cheatclient.gui;

import com.baggute.cheatclient.UtilityClient;
import com.baggute.cheatclient.config.ConfigManager;
import com.baggute.cheatclient.injector.InjectorBridge;
import com.baggute.cheatclient.module.Module;
import com.baggute.cheatclient.module.misc.Hud;
import com.baggute.cheatclient.settings.KeybindSetting;
import com.baggute.cheatclient.settings.Setting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

/**
 * Loader-style terminal (tilde key): a compact command line over the game.
 *
 * <p>Everything the GUI can do to modules and the HUD is reachable here, which is
 * also the quickest way to verify a build without opening menus.
 */
public class TerminalScreen extends Screen {

    private static final int MAX_LINES = 200;

    private final List<String> log = new ArrayList<>();
    private final List<String> history = new ArrayList<>();
    private String input = "";
    private int historyIndex = -1;

    public TerminalScreen() {
        super(Component.literal("UtilityClient Terminal"));
        say("UtilityClient terminal - type 'help' for commands");
        say("session: " + InjectorBridge.describe());
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float delta) {
        g.fill(0, 0, this.width, this.height, 0x99000000);

        int w = Math.min(this.width - 40, 620);
        int h = Math.min(this.height - 40, 300);
        int x = (this.width - w) / 2;
        int y = (this.height - h) / 2;

        Ui.shadow(g, x, y, w, h);
        Ui.frame(g, x, y, w, h, 0xF30A0C10);

        g.text(this.font, "TERMINAL", x + 10, y + 7, Ui.TEXT, true);
        int statusColor = InjectorBridge.isInjected() ? Ui.GREEN : Ui.MUTED;
        String status = InjectorBridge.label();
        g.text(this.font, status, x + w - 10 - this.font.width(status), y + 7, statusColor, false);
        g.fill(x + 8, y + 18, x + w - 8, y + 19, Ui.SOFT);
        Ui.hGradient(g, x + 8, x + 100, y + 18, y + 19, Ui.accentFaded(0.8f), 0x0029E0FF);

        int inputY = y + h - 20;
        g.fill(x + 6, inputY - 2, x + w - 6, inputY - 1, Ui.SOFT);

        int lineHeight = 10;
        int visible = Math.max(1, (inputY - (y + 24) - 4) / lineHeight);
        int start = Math.max(0, log.size() - visible);
        int ty = y + 24;
        for (int i = start; i < log.size(); i++) {
            g.text(this.font, log.get(i), x + 10, ty, Ui.DIM, false);
            ty += lineHeight;
        }

        g.text(this.font, ">", x + 10, inputY + 1, Ui.accentFaded(0.95f), false);
        String caret = input + "_";
        g.text(this.font, caret, x + 20, inputY + 1, Ui.TEXT, false);
    }

    @Override
    public boolean keyPressed(KeyEvent event) {
        int key = event.key();

        if (key == GLFW.GLFW_KEY_ESCAPE) {
            this.onClose();
            return true;
        }
        if (key == GLFW.GLFW_KEY_ENTER || key == GLFW.GLFW_KEY_KP_ENTER) {
            run(input);
            input = "";
            historyIndex = -1;
            return true;
        }
        if (key == GLFW.GLFW_KEY_BACKSPACE) {
            if (!input.isEmpty()) input = input.substring(0, input.length() - 1);
            return true;
        }
        if (key == GLFW.GLFW_KEY_UP) {
            if (!history.isEmpty()) {
                if (historyIndex < 0) historyIndex = history.size() - 1;
                else if (historyIndex > 0) historyIndex--;
                input = history.get(historyIndex);
            }
            return true;
        }
        if (key == GLFW.GLFW_KEY_DOWN) {
            if (historyIndex >= 0 && historyIndex < history.size() - 1) {
                historyIndex++;
                input = history.get(historyIndex);
            } else {
                historyIndex = -1;
                input = "";
            }
            return true;
        }

        String typed = typedChar(key, event.modifiers());
        if (typed != null) input += typed;
        return true;
    }

    private String typedChar(int keyCode, int modifiers) {
        boolean shift = (modifiers & GLFW.GLFW_MOD_SHIFT) != 0;
        if (keyCode >= GLFW.GLFW_KEY_A && keyCode <= GLFW.GLFW_KEY_Z) {
            char c = (char) ('a' + (keyCode - GLFW.GLFW_KEY_A));
            return String.valueOf(shift ? Character.toUpperCase(c) : c);
        }
        if (keyCode >= GLFW.GLFW_KEY_0 && keyCode <= GLFW.GLFW_KEY_9) {
            return String.valueOf((char) ('0' + (keyCode - GLFW.GLFW_KEY_0)));
        }
        if (keyCode >= GLFW.GLFW_KEY_KP_0 && keyCode <= GLFW.GLFW_KEY_KP_9) {
            return String.valueOf((char) ('0' + (keyCode - GLFW.GLFW_KEY_KP_0)));
        }
        if (keyCode == GLFW.GLFW_KEY_MINUS) return shift ? "_" : "-";
        if (keyCode == GLFW.GLFW_KEY_PERIOD) return ".";
        if (keyCode == GLFW.GLFW_KEY_SLASH) return "/";
        if (keyCode == GLFW.GLFW_KEY_SPACE) return " ";
        return null;
    }

    // ---- commands ----

    private void run(String raw) {
        String line = raw.trim();
        if (line.isEmpty()) return;
        say("> " + line);
        history.add(line);

        String[] parts = line.split("\\s+");
        String command = parts[0].toLowerCase();

        switch (command) {
            case "help" -> {
                say("modules [cat]      list modules");
                say("on|off|toggle <m>  change a module");
                say("bind <m> <keycode>  set the toggle key (-1 clears)");
                say("hud list|add <w>|remove <w>|reset");
                say("config save|load   write or read the config");
                say("panic              disable everything");
                say("status             loader + module summary");
                say("clear              empty the log");
            }
            case "modules" -> listModules(parts.length > 1 ? parts[1] : null);
            case "on", "off", "toggle" -> setModule(command, parts);
            case "bind" -> bind(parts);
            case "hud" -> hud(parts);
            case "config" -> config(parts);
            case "panic" -> panic();
            case "status" -> status();
            case "clear" -> log.clear();
            default -> say("unknown command: " + command + " (try 'help')");
        }
    }

    private void listModules(String category) {
        if (UtilityClient.moduleManager == null) return;
        int shown = 0;
        for (Module module : UtilityClient.moduleManager.getModules()) {
            if (category != null
                    && !module.getCategory().name().equalsIgnoreCase(category)) continue;
            say((module.isEnabled() ? "[on]  " : "[off] ") + module.getName()
                    + "  (" + module.getCategory().getDisplayName() + ")");
            shown++;
        }
        say(shown + " module(s)");
    }

    private void setModule(String command, String[] parts) {
        if (parts.length < 2) { say("usage: " + command + " <module>"); return; }
        Module module = UtilityClient.moduleManager.getByName(parts[1]);
        if (module == null) { say("no module named '" + parts[1] + "'"); return; }
        switch (command) {
            case "on" -> module.setEnabled(true);
            case "off" -> module.setEnabled(false);
            default -> module.toggle();
        }
        say(module.getName() + " is now " + (module.isEnabled() ? "on" : "off"));
    }

    private void bind(String[] parts) {
        if (parts.length < 3) { say("usage: bind <module> <keycode>  (-1 clears)"); return; }
        Module module = UtilityClient.moduleManager.getByName(parts[1]);
        if (module == null) { say("no module named '" + parts[1] + "'"); return; }
        int code;
        try {
            code = Integer.parseInt(parts[2]);
        } catch (NumberFormatException failure) {
            say("keycode must be a number, e.g. 82 for R");
            return;
        }
        for (Setting setting : module.getSettings()) {
            if (setting instanceof KeybindSetting keybind && "keybind".equals(keybind.getName())) {
                keybind.setKey(code);
                say(module.getName() + " bind = " + code);
                return;
            }
        }
        say("module has no toggle bind");
    }

    private void hud(String[] parts) {
        Hud hud = UtilityClient.moduleManager.getHud();
        if (hud == null) { say("hud unavailable"); return; }
        if (parts.length < 2) { say("usage: hud list|add <widget>|remove <widget>|reset"); return; }

        switch (parts[1].toLowerCase()) {
            case "list" -> {
                for (Hud.Widget widget : Hud.Widget.values()) {
                    say((hud.isWidgetEnabled(widget) ? "[on]  " : "[off] ") + widget.key()
                            + "  " + widget.title());
                }
            }
            case "add" -> {
                if (parts.length < 3) { say("usage: hud add <widget>"); return; }
                Hud.Widget widget = Hud.Widget.byKey(parts[2]);
                if (widget == null) { say("unknown widget '" + parts[2] + "'"); return; }
                hud.addWidget(widget);
                say("added " + widget.title());
            }
            case "remove" -> {
                if (parts.length < 3) { say("usage: hud remove <widget>"); return; }
                Hud.Widget widget = Hud.Widget.byKey(parts[2]);
                if (widget == null) { say("unknown widget '" + parts[2] + "'"); return; }
                hud.removeWidget(widget);
                say("removed " + widget.title());
            }
            case "reset" -> {
                hud.resetLayout();
                for (Hud.Widget widget : Hud.Widget.values()) hud.removeWidget(widget);
                say("hud reset (all widgets hidden)");
            }
            default -> say("usage: hud list|add <widget>|remove <widget>|reset");
        }
    }

    private void config(String[] parts) {
        if (parts.length < 2) { say("usage: config save|load"); return; }
        ConfigManager manager = UtilityClient.configManager();
        if (manager == null) { say("config unavailable"); return; }
        switch (parts[1].toLowerCase()) {
            case "save" -> {
                manager.save();
                say("config saved");
            }
            case "load" -> {
                manager.load();
                say("config loaded");
            }
            default -> say("usage: config save|load");
        }
    }

    private void panic() {
        int disabled = 0;
        for (Module module : UtilityClient.moduleManager.getModules()) {
            if (module.isEnabled()) {
                module.setEnabled(false);
                disabled++;
            }
        }
        UtilityClient.saveConfig();
        say("panic: " + disabled + " module(s) off");
    }

    private void status() {
        say("loader: " + InjectorBridge.describe());
        say("modules: " + UtilityClient.moduleManager.getModules().size());
        say("binds: " + UtilityClient.moduleManager.getBoundModules().size());
        Hud hud = UtilityClient.moduleManager.getHud();
        if (hud != null) say("hud widgets: " + hud.visibleWidgetCount() + "/" + Hud.Widget.values().length);
        say("fps: " + Minecraft.getInstance().getFps());
    }

    private void say(String text) {
        log.add(text);
        while (log.size() > MAX_LINES) log.remove(0);
    }

    @Override
    public boolean isPauseScreen() { return false; }
}
