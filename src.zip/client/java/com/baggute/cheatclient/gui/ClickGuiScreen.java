// language: Java, file: ClickGuiScreen.java, target: Fabric 26.2
package com.baggute.cheatclient.gui;

import com.baggute.cheatclient.UtilityClient;
import com.baggute.cheatclient.module.Category;
import com.baggute.cheatclient.module.Module;
import com.baggute.cheatclient.module.misc.Hud;
import com.baggute.cheatclient.module.misc.Notifications;
import com.baggute.cheatclient.settings.BoolSetting;
import com.baggute.cheatclient.settings.ColorSetting;
import com.baggute.cheatclient.settings.DoubleSetting;
import com.baggute.cheatclient.settings.IntSetting;
import com.baggute.cheatclient.settings.KeybindSetting;
import com.baggute.cheatclient.settings.Setting;
import com.baggute.cheatclient.settings.StringSetting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.block.Block;
import org.lwjgl.glfw.GLFW;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class ClickGuiScreen extends Screen {

    private static final int W = 372;
    private static final int H = 232;
    private static final int TITLE_H = 20;
    private static final int SEARCH_H = 18;
    private static final int SIDEBAR_W = 104;
    private static final int ROW_H = 15;
    private static final int PAD = 6;
    private static final int FOOTER_H = 20;

    private static final int C_BG        = Ui.BG;
    private static final int C_HEADER    = Ui.HEADER;
    private static final int C_SIDEBAR   = Ui.SIDEBAR;
    private static final int C_BORDER    = Ui.BORDER;
    private static final int C_SOFT      = Ui.SOFT;
    private static final int C_ROW_SEL   = Ui.ROW_SEL;

    private static final int C_TEXT      = Ui.TEXT;
    private static final int C_DIM       = Ui.DIM;
    private static final int C_MUTED     = Ui.MUTED;

    private static final int C_ACCENT    = Ui.ACCENT;
    private static final int C_ACCENT2   = Ui.ACCENT2;
    private static final int C_GREEN     = Ui.GREEN;
    private static final int C_RED       = Ui.RED;

    private static final int C_HOVER     = Ui.HOVER;
    private static final int C_INPUT     = Ui.INPUT;
    private static final int C_TRACK     = Ui.TRACK;
    private static final int C_SWATCH_BD = Ui.SWATCH;

    private int x, y;
    private boolean centered = false;
    private boolean dragging = false;
    private int dragOffX, dragOffY;

    private String searchQuery = "";
    private boolean searchFocused = false;
    private boolean presetMode = false;
    private int presetScroll = 0;

    private Category selectedCategory = Category.COMBAT;
    private Module expandedModule = null;
    private Setting listeningKeybind = null;
    private Setting numericInputTarget = null;
    private String numericInputValue = "";
    private Setting colorPickerTarget = null;

    private int settingsScroll = 0;
    private int moduleScroll = 0;

    private Setting mouseDownSetting = null;
    private int mouseDownX = 0;
    private double mouseDownValue = 0.0;
    private int sliderRowW = 0;
    private boolean sliderDidDrag = false;

    private float pickerHue = 0f;
    private float pickerSat = 1f;
    private float pickerVal = 1f;
    private int pickerAlpha = 255;
    private int pickerDragMode = 0;

    private boolean listMode = false;
    private String listSettingName = null;
    private List<String> listIds = null;
    private String listCacheTag = null;
    private int listScroll = 0;
    private int enabledListScroll = 0;
    private String listSearchQuery = "";
    private boolean listSearchFocused = false;

    private String hoverHint = "";

    /** Filter for the settings panel only — the search bar never touches configs. */
    private String settingsFilter = "";
    private boolean returnToEditor = false;

    public ClickGuiScreen() {
        this(null, null);
    }

    /** Opens straight into a module, optionally filtering its settings by name. */
    public ClickGuiScreen(Module focus, String query) {
        super(Component.literal("UtilityClient"));
        if (focus != null) {
            this.expandedModule = focus;
            this.selectedCategory = focus.getCategory();
        }
        if (query != null) this.settingsFilter = query;
        this.returnToEditor = focus instanceof Hud;
    }

    private void ensurePosition() {
        if (!centered) {
            x = (this.width - W) / 2;
            y = (this.height - H) / 2;
            centered = true;
        }
    }

    private boolean isFiltering() {
        return !searchQuery.trim().isEmpty();
    }

    private void setSearchQuery(String value) {
        searchQuery = value;
        moduleScroll = 0;
        settingsScroll = 0;
    }

    private List<Module> getVisibleModules() {
        if (!isFiltering() && selectedCategory == Category.ENABLED) return enabledModules();
        if (!isFiltering() && selectedCategory == Category.BINDS) return boundModules();
        if (!isFiltering()) return UtilityClient.moduleManager.getByCategory(selectedCategory);

        String q = searchQuery.trim().toLowerCase();
        List<Module> out = new ArrayList<>();
        for (Module m : UtilityClient.moduleManager.getModules()) {
            if (m.getName().toLowerCase().contains(q)) out.add(m);
        }
        out.sort((a, b) -> a.getName().compareToIgnoreCase(b.getName()));
        return out;
    }

    /** Virtual tab: everything currently running. */
    private List<Module> enabledModules() {
        List<Module> out = new ArrayList<>();
        for (Module m : UtilityClient.moduleManager.getModules()) {
            if (m.isEnabled()) out.add(m);
        }
        out.sort((a, b) -> a.getName().compareToIgnoreCase(b.getName()));
        return out;
    }

    /** Every bound key on a module: primary toggle bind plus any secondary actions. */
    private List<String> allKeyLabels(Module m) {
        List<String> out = new ArrayList<>();
        for (KeybindSetting k : UtilityClient.moduleManager.getBoundKeys(m)) out.add(keyLabel(k));
        return out;
    }

    /** Virtual tab: every module with a hotkey, primary or secondary. */
    private List<Module> boundModules() {
        return UtilityClient.moduleManager.getBoundModules();
    }

    private String primaryKeyLabel(Module m) {
        for (Setting s : m.getSettings()) {
            if (s instanceof KeybindSetting k && "keybind".equals(k.getName())) return keyLabel(k);
        }
        return "none";
    }

    private int countFor(Category cat) {
        if (cat == Category.ENABLED) return enabledModules().size();
        if (cat == Category.BINDS) return boundModules().size();
        return UtilityClient.moduleManager.getByCategory(cat).size();
    }

    private List<Setting> getVisibleSettings() {
        if (expandedModule == null) return new ArrayList<>();
        List<Setting> all = expandedModule.getSettings();
        String scope = settingsFilter.trim().toLowerCase();
        // The search bar doubles as a settings filter while a module is expanded;
        // the Hud alone now owns dozens of per-widget rows.
        String typed = searchQuery.trim().toLowerCase();
        if (scope.isEmpty() && typed.isEmpty()) return all;

        List<Setting> out = new ArrayList<>();
        for (Setting s : all) {
            String name = s.getName().toLowerCase();
            if (!scope.isEmpty() && !name.contains(scope)) continue;
            if (!typed.isEmpty() && !name.contains(typed)) continue;
            out.add(s);
        }
        return out;
    }

    private int searchBarY() {
        return y + TITLE_H;
    }

    // ---- hit boxes shared by drawing and clicking ----

    private int searchFieldX() { return x + PAD; }

    private int searchFieldW() { return W - PAD * 2 - 42; }

    private int cfgButtonX() { return x + W - 38; }

    private int cfgButtonW() { return 32; }

    private int closeButtonX() { return x + W - 20; }

    private String typedChar(int keyCode, int modifiers, boolean allowUpper) {
        boolean shift = (modifiers & GLFW.GLFW_MOD_SHIFT) != 0;
        if (keyCode >= GLFW.GLFW_KEY_A && keyCode <= GLFW.GLFW_KEY_Z) {
            char c = (char) ('a' + (keyCode - GLFW.GLFW_KEY_A));
            return allowUpper && shift ? String.valueOf(Character.toUpperCase(c)) : String.valueOf(c);
        }
        if (keyCode >= GLFW.GLFW_KEY_0 && keyCode <= GLFW.GLFW_KEY_9) {
            return String.valueOf((char) ('0' + (keyCode - GLFW.GLFW_KEY_0)));
        }
        if (keyCode >= GLFW.GLFW_KEY_KP_0 && keyCode <= GLFW.GLFW_KEY_KP_9) {
            return String.valueOf((char) ('0' + (keyCode - GLFW.GLFW_KEY_KP_0)));
        }
        if (keyCode == GLFW.GLFW_KEY_SPACE) return " ";
        if (keyCode == GLFW.GLFW_KEY_MINUS) return shift ? "_" : "-";
        if (keyCode == GLFW.GLFW_KEY_PERIOD) return ".";
        if (keyCode == GLFW.GLFW_KEY_SLASH) return "/";
        if (keyCode == GLFW.GLFW_KEY_APOSTROPHE) return "'";
        return null;
    }

    private StringSetting findStringSetting(Module m, String name) {
        if (m == null) return null;
        for (Setting s : m.getSettings()) {
            if (s instanceof StringSetting ss && ss.getName().equals(name)) return ss;
        }
        return null;
    }

    private Set<String> parseCsv(String csv) {
        Set<String> out = new HashSet<>();
        for (String p : csv.split(",")) {
            String t = p.trim();
            if (!t.isEmpty()) out.add(t);
        }
        return out;
    }

    private Set<String> getEnabledSet() {
        StringSetting ss = findStringSetting(expandedModule, listSettingName);
        if (ss == null) return Collections.emptySet();
        return parseCsv(ss.get());
    }

    private List<String> getListIds() {
        if (listIds != null && listCacheTag != null && listCacheTag.equals(listSettingName)) {
            return listIds;
        }
        List<String> out = new ArrayList<>();
        if ("hiddenModules".equals(listSettingName)) {
            for (Module m : UtilityClient.moduleManager.getModules()) out.add(m.getName());
        } else if ("potionFilter".equals(listSettingName)) {
            for (net.minecraft.world.item.alchemy.Potion potion : BuiltInRegistries.POTION) {
                Identifier id = BuiltInRegistries.POTION.getKey(potion);
                if (id != null) out.add(id.toString());
            }
        } else if ("blockFilter".equals(listSettingName)) {
            for (Block block : BuiltInRegistries.BLOCK) {
                Identifier id = BuiltInRegistries.BLOCK.getKey(block);
                if (id != null) out.add(id.toString());
            }
        } else {
            for (EntityType<?> t : BuiltInRegistries.ENTITY_TYPE) {
                Identifier id = BuiltInRegistries.ENTITY_TYPE.getKey(t);
                if (id != null) out.add(id.toString());
            }
        }
        Collections.sort(out);
        listIds = out;
        listCacheTag = listSettingName;
        return out;
    }

    private List<String> getFilteredListIds() {
        String q = listSearchQuery.toLowerCase().trim();
        List<String> all = getListIds();
        if (q.isEmpty()) return all;
        List<String> out = new ArrayList<>();
        for (String id : all) if (id.toLowerCase().contains(q)) out.add(id);
        return out;
    }

    private List<String> getEnabledListIds() {
        List<String> out = new ArrayList<>(getEnabledSet());
        Collections.sort(out);
        return out;
    }

    private void openList(String settingName) {
        listMode = true;
        listSettingName = settingName;
        listIds = null;
        listCacheTag = null;
        listScroll = 0;
        enabledListScroll = 0;
        listSearchQuery = "";
        listSearchFocused = true;
    }

    private void closeList() {
        listMode = false;
        listSettingName = null;
        listIds = null;
        listCacheTag = null;
        listSearchFocused = false;
    }

    private void toggleListItem(String id) {
        StringSetting ss = findStringSetting(expandedModule, listSettingName);
        if (ss == null) return;
        Set<String> current = new HashSet<>(parseCsv(ss.get()));
        if (current.contains(id)) current.remove(id);
        else current.add(id);
        List<String> sorted = new ArrayList<>(current);
        Collections.sort(sorted);
        ss.set(String.join(",", sorted));
    }

    private int panelTop()    { return y + TITLE_H + SEARCH_H + 1; }
    private int panelLeft()   { return x + SIDEBAR_W + 1; }
    private int panelW()      { return W - SIDEBAR_W - 1; }
    private int panelBottom() { return y + H - FOOTER_H; }

    private int getPickerCx(int px, int pw) { return px + pw / 2; }
    private int getPickerCy(int py)         { return py + 78; }
    private int getPickerRadius()           { return 42; }
    private int getSliderX(int px)          { return px + 12; }
    private int getSliderY(int py)          { return py + 132; }
    private int getSliderW(int pw)          { return pw - 24; }
    private int getSliderH()                { return 10; }

    private void updatePickerColor() {
        if (!(colorPickerTarget instanceof ColorSetting cs)) return;
        int rgb = Color.HSBtoRGB(pickerHue, pickerSat, pickerVal) & 0xFFFFFF;
        cs.set((pickerAlpha << 24) | rgb);
    }

    private void gradient(GuiGraphicsExtractor g, int x1, int y1, int x2, int y2, int from, int to) {
        int steps = Math.max(1, x2 - x1);
        for (int i = 0; i < steps; i++) {
            float t = (float) i / steps;
            int a = lerpChannel(from >> 24 & 0xFF, to >> 24 & 0xFF, t);
            int r = lerpChannel(from >> 16 & 0xFF, to >> 16 & 0xFF, t);
            int gr = lerpChannel(from >> 8 & 0xFF, to >> 8 & 0xFF, t);
            int b = lerpChannel(from & 0xFF, to & 0xFF, t);
            g.fill(x1 + i, y1, x1 + i + 1, y2, (a << 24) | (r << 16) | (gr << 8) | b);
        }
    }

    private static int lerpChannel(int a, int b, float t) {
        return (int) (a + (b - a) * t);
    }

    private void pill(GuiGraphicsExtractor g, int px, int py, boolean on, boolean hover) {
        int w = 20, h = 9;
        int track = on ? Ui.accent() : (hover ? 0xFF3A4048 : 0xFF262B33);
        if (on) {
            // Soft halo so an enabled module reads before the text does.
            g.fill(px - 1, py - 1, px + w + 1, py + h + 1, Ui.accentFaded(0.18f));
        }
        g.fill(px + 1, py, px + w - 1, py + h, track);
        g.fill(px, py + 1, px + 1, py + h - 1, track);
        g.fill(px + w - 1, py + 1, px + w, py + h - 1, track);

        int knobX = on ? px + w - 9 : px + 1;
        g.fill(knobX, py + 1, knobX + 8, py + h - 1, 0xFFF4F6FA);
    }

    private void scrollbar(GuiGraphicsExtractor g, int px, int top, int bottom,
                           int scroll, int max, int visible, int total) {
        int height = bottom - top;
        g.fill(px, top, px + 3, bottom, C_SOFT);
        if (max <= 0 || total <= 0 || height <= 0) return;
        int thumb = Math.max(14, height * visible / total);
        int ty = top + (height - thumb) * scroll / max;
        g.fill(px, ty, px + 3, ty + thumb, C_ACCENT);
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float delta) {
        ensurePosition();
        hoverHint = "";

        // Deep dim with depth at the top and bottom edges.
        g.fill(0, 0, this.width, this.height, 0xA8060709);
        Ui.vGradient(g, 0, 0, this.width, 86, 0x30000000, 0x00000000);
        Ui.vGradient(g, 0, this.height - 110, this.width, this.height, 0x00000000, 0x50000000);

        Ui.shadow(g, x, y, W, H);
        g.fill(x - 1, y - 1, x + W + 1, y + H + 1, C_BORDER);
        g.fill(x, y, x + W, y + H, C_BG);
        g.fill(x + 1, y + 1, x + W - 1, y + 2, 0x14FFFFFF);
        Ui.corners(g, x - 1, y - 1, W + 2, H + 2, 12, Ui.accentFaded(0.5f));

        drawHeader(g, mouseX, mouseY);
        drawSearchBar(g, mouseX, mouseY);

        g.fill(x, y + TITLE_H + SEARCH_H, x + W, y + TITLE_H + SEARCH_H + 1, C_SOFT);
        g.fill(x, y + TITLE_H + SEARCH_H + 1, x + SIDEBAR_W, panelBottom(), C_SIDEBAR);

        drawSidebar(g, mouseX, mouseY);
        g.fill(x + SIDEBAR_W, panelTop(), x + SIDEBAR_W + 1, panelBottom(), C_SOFT);

        int px = panelLeft();
        int py = panelTop();
        int pw = panelW();

        if (presetMode) {
            drawPresetPanel(g, px, py, pw, mouseX, mouseY);
        } else if (colorPickerTarget != null) {
            drawColorPicker(g, px, py, pw, mouseX, mouseY);
        } else if (listMode && expandedModule != null) {
            drawListPanel(g, px, py, pw, mouseX, mouseY);
        } else if (expandedModule != null) {
            drawSettingsPanel(g, px, py, pw, mouseX, mouseY);
        } else {
            drawModuleList(g, px, py, pw, mouseX, mouseY);
        }

        drawFooter(g, px, pw);
    }

    private void drawHeader(GuiGraphicsExtractor g, int mouseX, int mouseY) {
        g.fill(x, y, x + W, y + TITLE_H, C_HEADER);

        // Logo tile: a two-tone accent block with the initial punched out.
        int lx = x + PAD;
        int ly = y + 5;
        Ui.vGradient(g, lx, ly, lx + 12, ly + 12, Ui.accent(), Ui.ACCENT2);
        g.fill(lx + 1, ly + 1, lx + 11, ly + 2, 0x55FFFFFF);
        g.text(this.font, "U", lx + 4, ly + 2, 0xFF07090C, true);

        int tx = lx + 18;
        g.text(this.font, "UtilityClient", tx, y + 5, C_TEXT, true);
        int versionX = tx + this.font.width("UtilityClient") + 6;
        Ui.chip(g, this.font, "v1.0", versionX, y + 5, C_MUTED, 0xFF141821, C_BORDER);
        // Loader status: "injected" when an agent attached to this JVM, else "fabric".
        boolean injected = com.baggute.cheatclient.injector.InjectorBridge.isInjected();
        Ui.chip(g, this.font, com.baggute.cheatclient.injector.InjectorBridge.label(),
                versionX + Ui.chipWidth(this.font, "v1.0") + 4, y + 5,
                injected ? Ui.GREEN : C_MUTED, 0xFF141821, C_BORDER);

        int closeX = x + W - 15;
        String fps = Minecraft.getInstance().getFps() + " fps";
        int fpsW = Ui.chipWidth(this.font, fps);
        Ui.chip(g, this.font, fps, closeButtonX() - 8 - fpsW, y + 5, C_DIM, 0xFF141821, C_BORDER);

        boolean closeHover = mouseX >= closeButtonX() && mouseX < x + W - 4
                && mouseY >= y + 3 && mouseY < y + TITLE_H - 4;
        if (closeHover) g.fill(closeButtonX() - 4, y + 4, x + W - 4, y + TITLE_H - 4, 0x30FF6B81);
        g.text(this.font, "x", closeX, y + 7, closeHover ? C_RED : C_DIM, false);

        Ui.hGradient(g, x, x + W, y + TITLE_H - 2, y + TITLE_H, Ui.accent(), Ui.ACCENT2);
    }

    private void drawSearchBar(GuiGraphicsExtractor g, int mouseX, int mouseY) {
        int barY = searchBarY();
        g.fill(x, barY, x + W, barY + SEARCH_H, C_BG);

        int fx = searchFieldX();
        int fy = barY + 2;
        int fw = searchFieldW();
        int fh = SEARCH_H - 5;
        g.fill(fx - 1, fy - 1, fx + fw + 1, fy + fh + 1,
                searchFocused ? Ui.accentFaded(0.8f) : C_BORDER);
        g.fill(fx, fy, fx + fw, fy + fh, C_INPUT);
        if (searchFocused) g.fill(fx, fy + fh - 1, fx + fw, fy + fh, Ui.accent());

        g.text(this.font, "/", fx + 5, fy + 3, searchFocused ? C_ACCENT : C_MUTED, false);

        String hint = expandedModule != null ? "search settings..." : "search modules...";
        String text = searchQuery.isEmpty()
                ? (searchFocused ? "_" : hint)
                : searchQuery + (searchFocused ? "_" : "");
        int color = searchQuery.isEmpty() && !searchFocused ? C_MUTED : C_TEXT;
        g.text(this.font, text, fx + 14, fy + 3, color, false);

        if (isFiltering() && !presetMode) {
            int matches = expandedModule != null
                    ? getVisibleSettings().size() : getVisibleModules().size();
            String label = String.valueOf(matches);
            int lw = this.font.width(label);
            g.text(this.font, label, fx + fw - lw - 5, fy + 3, C_ACCENT, false);
        }

        int cfgX = cfgButtonX();
        int cfgW = cfgButtonW();
        boolean cfgHover = mouseX >= cfgX && mouseX < cfgX + cfgW
                && mouseY >= barY + 2 && mouseY < barY + SEARCH_H - 3;
        g.fill(cfgX, fy, cfgX + cfgW, fy + fh, presetMode || cfgHover ? Ui.accentFaded(0.75f) : C_BORDER);
        g.fill(cfgX + 1, fy + 1, cfgX + cfgW - 1, fy + fh - 1,
                presetMode ? Ui.accent() : (cfgHover ? 0x2A29E0FF : C_INPUT));
        g.text(this.font, "cfg", cfgX + 6, fy + 3, presetMode ? 0xFF07090C : C_DIM, false);
    }

    /** Empty categories are hidden; the sidebar only lists tabs that lead somewhere. */
    private boolean showsCategory(Category category) {
        return countFor(category) > 0 || category == Category.ENABLED || category == Category.BINDS;
    }

    private void drawSidebar(GuiGraphicsExtractor g, int mouseX, int mouseY) {
        int catY = panelTop() + PAD - 2;
        for (Category cat : Category.values()) {
            if (!showsCategory(cat)) continue;

            // Searching modules clears the tab highlight; searching the settings of
            // an open module should not.
            boolean sel = cat == selectedCategory && (expandedModule != null || !isFiltering());
            boolean hov = mouseX >= x && mouseX < x + SIDEBAR_W
                    && mouseY >= catY && mouseY < catY + ROW_H - 1;

            if (sel) {
                Ui.hGradient(g, x + 4, x + SIDEBAR_W - 4, catY, catY + ROW_H - 1,
                        0x1F29E0FF, 0x0629E0FF);
                g.fill(x + 4, catY, x + 6, catY + ROW_H - 1, Ui.accent());
                hoverHint = cat.getDisplayName();
            } else if (hov) {
                g.fill(x + 4, catY, x + SIDEBAR_W - 4, catY + ROW_H - 1, C_HOVER);
            }

            int gx = x + 10;
            int gy = catY + 4;
            g.fill(gx, gy, gx + 9, gy + 9, sel ? Ui.accent() : 0x16FFFFFF);
            g.text(this.font, cat.getDisplayName().substring(0, 1).toUpperCase(),
                    gx + 2, gy + 1, sel ? 0xFF07090C : C_DIM, false);

            int count = countFor(cat);
            String n = String.valueOf(count);
            // "skidded off apex" does not fit a 108 px rail; the footer still says
            // what the tab is when it is selected.
            String label = cat == Category.APEX ? "Apex" : cat.getDisplayName();
            int room = SIDEBAR_W - 24 - this.font.width(n) - 10;
            g.text(this.font, fit(label, room), x + 24, catY + 4, sel ? C_TEXT : C_DIM, false);
            g.text(this.font, n, x + SIDEBAR_W - 10 - this.font.width(n), catY + 4,
                    sel ? C_ACCENT : C_MUTED, false);

            catY += ROW_H;
        }

        // Sidebar footer: a quiet summary instead of dead space.
        int fy = panelBottom() - 12;
        String summary = enabledModules().size() + " on";
        g.text(this.font, summary, x + 10, fy, Ui.accentFaded(0.85f), false);
        String mods = UtilityClient.moduleManager.getModules().size() + " mods";
        g.text(this.font, mods, x + SIDEBAR_W - 10 - this.font.width(mods), fy, C_MUTED, false);
    }

    private void drawFooter(GuiGraphicsExtractor g, int px, int pw) {
        int fy = y + H - FOOTER_H;
        g.fill(x, fy, x + W, y + H, C_HEADER);
        g.fill(x, fy, x + W, fy + 1, C_SOFT);

        String stat = enabledModules().size() + " on";
        int statW = this.font.width(stat);
        g.text(this.font, stat, x + W - PAD - statW, fy + 7, Ui.accentFaded(0.9f), false);
        g.fill(x + W - PAD - statW - 7, fy + 8, x + W - PAD - statW - 6, fy + 14, Ui.accentFaded(0.6f));

        String text;
        if (!hoverHint.isEmpty()) text = hoverHint;
        else if (presetMode) text = "left-click loads a preset, x deletes it";
        else if (colorPickerTarget != null) text = "drag the wheel and the brightness bar";
        else if (listMode) text = "left-click to add or remove, right-click to go back";
        else if (expandedModule != null) text = "click to edit, drag to slide, scroll for more";
        else if (selectedCategory == Category.APEX) text = "apex tab is a catalogue: labels only, nothing in it runs";
        else if (selectedCategory == Category.BINDS) text = "every module with a hotkey";
        else if (selectedCategory == Category.ENABLED) text = "everything currently running";
        else text = "type to search, left-click toggles, right-click opens settings";

        int maxW = W - PAD * 2 - statW - 18;
        while (text.length() > 4 && this.font.width(text) > maxW) text = text.substring(0, text.length() - 4) + "...";
        g.text(this.font, text, px + 10, fy + 7, hoverHint.isEmpty() ? C_MUTED : C_DIM, false);
    }

    /** Truncates with an ellipsis so a label never bleeds into the panel. */
    private String fit(String text, int width) {
        if (this.font.width(text) <= width) return text;
        String trimmed = text;
        while (trimmed.length() > 2 && this.font.width(trimmed + "..") > width) {
            trimmed = trimmed.substring(0, trimmed.length() - 1);
        }
        return trimmed + "..";
    }

    private void drawModuleList(GuiGraphicsExtractor g, int px, int py, int pw, int mouseX, int mouseY) {
        List<Module> mods = getVisibleModules();
        int listTop = py + PAD - 2;
        int listBottom = panelBottom() - 2;
        int visible = Math.max(1, (listBottom - listTop) / ROW_H);
        int maxScroll = Math.max(0, mods.size() - visible);
        if (moduleScroll > maxScroll) moduleScroll = maxScroll;
        if (moduleScroll < 0) moduleScroll = 0;

        if (mods.isEmpty()) {
            g.text(this.font, "nothing matches", px + 10, listTop + 6, C_MUTED, false);
        }

        for (int i = 0; i < mods.size(); i++) {
            int rowY = listTop + (i - moduleScroll) * ROW_H;
            if (rowY + ROW_H <= listTop || rowY >= listBottom) continue;

            Module m = mods.get(i);
            boolean hover = mouseX >= px && mouseX < px + pw
                    && mouseY >= rowY && mouseY < rowY + ROW_H;
            boolean on = m.isEnabled();

            if ((i & 1) == 1) g.fill(px + 2, rowY, px + pw - 6, rowY + ROW_H - 1, 0x05FFFFFF);
            if (on) g.fill(px + 2, rowY, px + pw - 6, rowY + ROW_H - 1, 0x0F29E0FF);
            if (hover) {
                Ui.hGradient(g, px + 2, px + pw - 6, rowY, rowY + ROW_H - 1, 0x18FFFFFF, 0x06FFFFFF);
                hoverHint = m.getDescription();
            }
            if (on) g.fill(px + 2, rowY, px + 4, rowY + ROW_H - 1, Ui.accent());

            g.text(this.font, m.getName(), px + 12, rowY + 4, on ? C_TEXT : C_DIM, false);

            if (isFiltering()) {
                String tag = m.getCategory().getDisplayName();
                g.text(this.font, tag, px + pw - 34 - this.font.width(tag), rowY + 4, C_MUTED, false);
            } else if (selectedCategory != Category.BINDS
                    && !(m instanceof com.baggute.cheatclient.module.apex.ApexModule)) {
                String key = primaryKeyLabel(m);
                if (!key.equals("none")) {
                    int cw = Ui.chipWidth(this.font, key);
                    Ui.chip(g, this.font, key, px + pw - 38 - cw, rowY + 3,
                            on ? C_ACCENT : C_MUTED, 0xFF12161D, C_BORDER);
                }
            }

            if (selectedCategory == Category.BINDS) {
                // List every active bind, not just the toggle key: secondary action
                // keys (panic, preset cycling, pearl catch, ...) were invisible here.
                String key = String.join(" + ", allKeyLabels(m));
                int room = pw - 12 - 10 - this.font.width(m.getName()) - 12;
                g.text(this.font, fit(key, Math.max(40, room)), px + pw - 10, rowY + 4,
                        C_ACCENT, false);
            } else if (m instanceof com.baggute.cheatclient.module.apex.ApexModule) {
                String tag = "label";
                g.text(this.font, tag, px + pw - 10 - this.font.width(tag), rowY + 4, C_MUTED, false);
            } else {
                pill(g, px + pw - 34, rowY + 4, on, hover);
            }
        }

        scrollbar(g, px + pw - 5, listTop, listBottom, moduleScroll, maxScroll, visible, mods.size());
    }

    private void drawSettingsPanel(GuiGraphicsExtractor g, int px, int py, int pw, int mouseX, int mouseY) {
        boolean headerHover = mouseX >= px && mouseX < px + pw
                && mouseY >= py && mouseY < py + 18;
        boolean on = expandedModule.isEnabled();

        g.fill(px + PAD, py + 2, px + PAD + 11, py + 13, headerHover ? Ui.accentFaded(0.8f) : 0x18FFFFFF);
        g.text(this.font, "<", px + PAD + 3, py + 4, headerHover ? C_ACCENT : C_DIM, false);
        g.text(this.font, expandedModule.getName(), px + PAD + 16, py + 4, C_TEXT, true);
        if (headerHover) hoverHint = expandedModule.getDescription();

        String state = on ? "on" : "off";
        int stateW = this.font.width(state);
        int dotX = px + pw - PAD - stateW - 9;
        g.fill(dotX, py + 8, dotX + 4, py + 12, on ? Ui.accent() : C_MUTED);
        g.text(this.font, state, px + pw - PAD - stateW, py + 4, on ? C_GREEN : C_MUTED, false);

        g.fill(px + PAD, py + 17, px + pw - PAD, py + 18, C_SOFT);
        Ui.hGradient(g, px + PAD, px + pw / 2, py + 17, py + 18, Ui.accentFaded(0.6f), 0x0029E0FF);

        List<Setting> settings = getVisibleSettings();
        int listTop = py + 22;
        int listBottom = panelBottom() - 2;
        int visible = Math.max(1, (listBottom - listTop) / ROW_H);
        int maxScroll = Math.max(0, settings.size() - visible);
        if (settingsScroll > maxScroll) settingsScroll = maxScroll;
        if (settingsScroll < 0) settingsScroll = 0;

        if (settings.isEmpty()) {
            g.text(this.font, "no settings match", px + 10, listTop + 6, C_MUTED, false);
        }

        for (int i = 0; i < settings.size(); i++) {
            int rowY = listTop + (i - settingsScroll) * ROW_H;
            if (rowY + ROW_H <= listTop || rowY >= listBottom) continue;

            Setting s = settings.get(i);
            boolean hover = mouseX >= px && mouseX < px + pw
                    && mouseY >= rowY && mouseY < rowY + ROW_H;
            boolean isInput = numericInputTarget == s;

            if (isInput) g.fill(px + 2, rowY, px + pw - 6, rowY + ROW_H - 1, C_INPUT);
            else if (hover) {
                g.fill(px + 2, rowY, px + pw - 6, rowY + ROW_H - 1, C_HOVER);
                hoverHint = s.getDescription();
            }

            g.text(this.font, s.getName(), px + 10, rowY + 4, C_DIM, false);

            if (s instanceof BoolSetting b) {
                pill(g, px + pw - 30, rowY + 4, b.get(), hover);
            } else if (s instanceof ColorSetting c) {
                int swX = px + pw - 56;
                g.fill(swX - 1, rowY + 3, swX + 17, rowY + 14, C_SWATCH_BD);
                g.fill(swX, rowY + 4, swX + 16, rowY + 13, c.get());
                g.text(this.font, "edit", swX + 22, rowY + 4, C_ACCENT, false);
            } else if (s.getName().equals("editPositions")) {
                String open = "open";
                g.text(this.font, open, px + pw - 30 - this.font.width(open), rowY + 4, C_ACCENT, false);
            } else if (s instanceof KeybindSetting k) {
                String label = keyLabel(s);
                int lw = this.font.width(label);
                boolean conflict = expandedModule != null
                        && !UtilityClient.moduleManager.getKeyConflicts(k.getKey(), expandedModule).isEmpty();
                int color = listeningKeybind == s ? C_ACCENT : (conflict ? C_RED : C_TEXT);
                g.fill(px + pw - lw - 18, rowY + 3, px + pw - 8, rowY + ROW_H - 4, C_INPUT);
                g.text(this.font, label, px + pw - lw - 13, rowY + 4, color, false);
            } else {
                String value = isInput ? numericInputValue + "_" : getSettingDisplay(s);
                int vw = this.font.width(value);
                g.text(this.font, value, px + pw - vw - 10, rowY + 4,
                        isInput ? C_ACCENT : C_TEXT, false);

                if (s instanceof IntSetting is) {
                    slider(g, px, rowY, pw, is.get(), is.getMin(), is.getMax());
                } else if (s instanceof DoubleSetting ds) {
                    slider(g, px, rowY, pw, ds.get(), ds.getMin(), ds.getMax());
                }
            }
        }

        scrollbar(g, px + pw - 5, listTop, listBottom, settingsScroll, maxScroll, visible, settings.size());
    }

    private String keyLabel(Setting s) {
        if (listeningKeybind == s) return "...";
        int key = s.getValue() instanceof Number n ? n.intValue() : -1;
        if (key == -1 || key == GLFW.GLFW_KEY_UNKNOWN) return "none";
        try {
            return com.mojang.blaze3d.platform.InputConstants.Type.KEYSYM
                    .getOrCreate(key).getDisplayName().getString().toUpperCase();
        } catch (Exception ignored) {
            return "KEY" + key;
        }
    }

    private void slider(GuiGraphicsExtractor g, int px, int rowY, int pw,
                        double value, double min, double max) {
        int barY = rowY + ROW_H - 4;
        int barX = px + 10;
        int barW = pw - 20;
        double range = max - min;
        double fraction = range > 0 ? (value - min) / range : 0;
        fraction = Math.max(0, Math.min(1, fraction));

        g.fill(barX, barY, barX + barW, barY + 2, C_TRACK);
        gradient(g, barX, barY, barX + (int) (barW * fraction), barY + 2, Ui.accent(), Ui.ACCENT2);

        int knobX = barX + (int) (barW * fraction);
        g.fill(knobX - 2, barY - 3, knobX + 3, barY + 5, Ui.accentFaded(0.35f));
        g.fill(knobX - 1, barY - 2, knobX + 2, barY + 4, 0xFFF4F6FA);
    }

    private void drawColorPicker(GuiGraphicsExtractor g, int px, int py, int pw, int mouseX, int mouseY) {
        boolean headerHover = mouseX >= px && mouseX < px + pw && mouseY >= py && mouseY < py + 18;
        g.text(this.font, "< color", px + PAD, py + 4, headerHover ? C_ACCENT : C_DIM, false);
        g.text(this.font, colorPickerTarget.getName(), px + PAD + 34, py + 4, C_TEXT, false);
        g.fill(px + PAD, py + 17, px + pw - PAD, py + 18, C_SOFT);

        int current = ((ColorSetting) colorPickerTarget).get();
        int previewY = py + 24;
        g.fill(px + 10, previewY, px + pw - 10, previewY + 16, C_SWATCH_BD);
        g.fill(px + 11, previewY + 1, px + pw - 11, previewY + 15, current);

        int cx = getPickerCx(px, pw);
        int cy = getPickerCy(py);
        int R = getPickerRadius();

        int rings = 6;
        int sectors = 32;
        for (int ring = 1; ring <= rings; ring++) {
            float rho = (float) ring / rings;
            int ringR = (int) (rho * R);
            for (int s = 0; s < sectors; s++) {
                float theta = (float) s / sectors * (float) (Math.PI * 2);
                int cxi = cx + (int) Math.round(Math.cos(theta) * ringR);
                int cyi = cy + (int) Math.round(Math.sin(theta) * ringR);
                int rgb = Color.HSBtoRGB((float) s / sectors, rho, pickerVal) & 0xFFFFFF;
                g.fill(cxi - 5, cyi - 5, cxi + 5, cyi + 5, 0xFF000000 | rgb);
            }
        }
        g.fill(cx - 6, cy - 6, cx + 6, cy + 6, Color.HSBtoRGB(0f, 0f, pickerVal) | 0xFF000000);

        int sx = getSliderX(px);
        int sy = getSliderY(py);
        int sw = getSliderW(pw);
        int sh = getSliderH();
        int steps = 48;
        for (int i = 0; i < steps; i++) {
            float t = (float) i / (steps - 1);
            int rgb = Color.HSBtoRGB(pickerHue, pickerSat, t) & 0xFFFFFF;
            g.fill(sx + i * sw / steps, sy, sx + (i + 1) * sw / steps, sy + sh, 0xFF000000 | rgb);
        }
        g.fill(sx - 1, sy - 1, sx + sw + 1, sy, C_SWATCH_BD);
        g.fill(sx - 1, sy + sh, sx + sw + 1, sy + sh + 1, C_SWATCH_BD);

        int handleX = sx + (int) (pickerVal * sw);
        g.fill(handleX - 1, sy - 3, handleX + 2, sy + sh + 3, 0xFFFFFFFF);

        int rgb = Color.HSBtoRGB(pickerHue, pickerSat, pickerVal) & 0xFFFFFF;
        g.text(this.font, String.format("#%06X", rgb), px + 12, sy + sh + 8, C_DIM, false);
        String alpha = "a " + pickerAlpha;
        g.text(this.font, alpha, px + pw - 12 - this.font.width(alpha), sy + sh + 8, C_MUTED, false);
    }

    private void drawListPanel(GuiGraphicsExtractor g, int px, int py, int pw, int mouseX, int mouseY) {
        boolean headerHover = mouseX >= px && mouseX < px + pw && mouseY >= py && mouseY < py + 18;
        g.text(this.font, "<", px + PAD, py + 4, headerHover ? C_ACCENT : C_DIM, false);
        g.text(this.font, listSettingName, px + PAD + 12, py + 4, C_TEXT, false);
        g.fill(px + PAD, py + 17, px + pw - PAD, py + 18, C_SOFT);

        int searchY = py + 22;
        int searchH = 14;
        g.fill(px + 8, searchY, px + pw - 8, searchY + searchH, C_INPUT);
        g.fill(px + 8, searchY, px + pw - 8, searchY + 1, listSearchFocused ? C_ACCENT : C_SOFT);
        String text = listSearchQuery.isEmpty() && !listSearchFocused
                ? "filter..." : listSearchQuery + (listSearchFocused ? "_" : "");
        g.text(this.font, text, px + 12, searchY + 4,
                listSearchQuery.isEmpty() && !listSearchFocused ? C_MUTED : C_TEXT, false);

        int listTop = searchY + searchH + 10;
        int listBottom = panelBottom() - 2;
        int rowH = 13;
        int gap = 6;
        int leftW = (pw - 12 - gap) * 56 / 100;
        int rightW = pw - 12 - leftW - gap;
        int leftX = px + 6;
        int rightX = leftX + leftW + gap;

        g.fill(leftX, listTop, leftX + leftW, listBottom, 0xFF0E0F13);
        g.fill(rightX, listTop, rightX + rightW, listBottom, 0xFF0E0F13);

        List<String> filtered = getFilteredListIds();
        Set<String> enabled = getEnabledSet();
        int visibleRows = Math.max(1, (listBottom - listTop) / rowH);
        int leftMax = Math.max(0, filtered.size() - visibleRows);
        if (listScroll > leftMax) listScroll = leftMax;
        if (listScroll < 0) listScroll = 0;

        for (int i = listScroll; i < filtered.size() && i < listScroll + visibleRows; i++) {
            int rowY = listTop + (i - listScroll) * rowH;
            String id = filtered.get(i);
            boolean on = enabled.contains(id);
            boolean hover = mouseX >= leftX && mouseX < leftX + leftW
                    && mouseY >= rowY && mouseY < rowY + rowH;

            if (hover) g.fill(leftX, rowY, leftX + leftW, rowY + rowH, C_HOVER);
            if (on) g.fill(leftX, rowY, leftX + 2, rowY + rowH, C_GREEN);

            g.fill(leftX + 8, rowY + 4, leftX + 15, rowY + 11, C_SWATCH_BD);
            if (on) g.fill(leftX + 9, rowY + 5, leftX + 14, rowY + 10, C_GREEN);

            g.text(this.font, trimNamespace(id), leftX + 21, rowY + 3, on ? C_TEXT : C_DIM, false);
        }

        scrollbar(g, leftX + leftW - 4, listTop, listBottom, listScroll, leftMax, visibleRows, filtered.size());

        List<String> enabledList = getEnabledListIds();
        int rightMax = Math.max(0, enabledList.size() - visibleRows);
        if (enabledListScroll > rightMax) enabledListScroll = rightMax;
        if (enabledListScroll < 0) enabledListScroll = 0;

        if (enabledList.isEmpty()) {
            g.text(this.font, "none", rightX + 8, listTop + 4, C_MUTED, false);
        } else {
            for (int i = enabledListScroll; i < enabledList.size() && i < enabledListScroll + visibleRows; i++) {
                int rowY = listTop + (i - enabledListScroll) * rowH;
                String id = enabledList.get(i);
                boolean hover = mouseX >= rightX && mouseX < rightX + rightW
                        && mouseY >= rowY && mouseY < rowY + rowH;
                if (hover) g.fill(rightX, rowY, rightX + rightW, rowY + rowH, C_HOVER);
                g.text(this.font, trimNamespace(id), rightX + 8, rowY + 3, C_GREEN, false);
            }
            scrollbar(g, rightX + rightW - 4, listTop, listBottom, enabledListScroll, rightMax,
                    visibleRows, enabledList.size());
        }
    }

    private static String trimNamespace(String id) {
        int c = id.indexOf(':');
        return c >= 0 ? id.substring(c + 1) : id;
    }

    private void drawPresetPanel(GuiGraphicsExtractor g, int px, int py, int pw, int mouseX, int mouseY) {
        boolean headerHover = mouseX >= px && mouseX < px + pw && mouseY >= py && mouseY < py + 18;
        g.text(this.font, "<", px + PAD, py + 4, headerHover ? C_ACCENT : C_DIM, false);
        g.text(this.font, "presets", px + PAD + 12, py + 4, C_TEXT, false);
        g.fill(px + PAD, py + 17, px + pw - PAD, py + 18, C_SOFT);

        List<String> presets = com.baggute.cheatclient.config.ConfigManager.listPresets();
        int listTop = py + 24;
        int listBottom = panelBottom() - 2;
        int rows = Math.max(1, (listBottom - listTop) / ROW_H);
        int total = presets.size() + 1;
        int maxScroll = Math.max(0, total - rows);
        if (presetScroll > maxScroll) presetScroll = maxScroll;
        if (presetScroll < 0) presetScroll = 0;

        for (int i = presetScroll; i < total && i < presetScroll + rows; i++) {
            int rowY = listTop + (i - presetScroll) * ROW_H;
            boolean hover = mouseX >= px && mouseX < px + pw
                    && mouseY >= rowY && mouseY < rowY + ROW_H - 1;
            if (hover) g.fill(px + 2, rowY, px + pw - 6, rowY + ROW_H - 1, C_HOVER);

            if (i == 0) {
                g.fill(px + 2, rowY, px + 4, rowY + ROW_H - 1, C_GREEN);
                String label = "save as '" + (searchQuery.isBlank() ? "quick" : searchQuery.trim()) + "'";
                g.text(this.font, label, px + 12, rowY + 4, C_GREEN, false);
                continue;
            }

            String name = presets.get(i - 1);
            String meta = com.baggute.cheatclient.config.ConfigManager.describePreset(name);
            g.fill(px + 2, rowY, px + 4, rowY + ROW_H - 1, C_ACCENT);
            g.text(this.font, name, px + 12, rowY + 4, C_TEXT, false);
            if (!meta.isEmpty()) {
                g.text(this.font, meta, px + pw - 44 - this.font.width(meta), rowY + 4, C_MUTED, false);
            }

            boolean delHover = mouseX >= px + pw - 26 && mouseX < px + pw - 10
                    && mouseY >= rowY && mouseY < rowY + ROW_H - 1;
            g.text(this.font, "x", px + pw - 20, rowY + 4, delHover ? C_RED : C_MUTED, false);
        }

        scrollbar(g, px + pw - 5, listTop, listBottom, presetScroll, maxScroll, rows, total);
    }

    private String getSettingDisplay(Setting s) {
        if (s instanceof DoubleSetting d) return String.format("%.2f", d.get());
        if (s instanceof IntSetting i) return String.valueOf(i.get());
        if (s instanceof StringSetting str) {
            String n = str.getName();
            if (n.equals("entityFilter") || n.equals("blockFilter")
                    || n.equals("hiddenModules") || n.equals("potionFilter")) {
                int count = 0;
                for (String p : str.get().split(",")) if (!p.trim().isEmpty()) count++;
                return count + " set";
            }
            String v = str.get();
            return v.length() > 16 ? v.substring(0, 13) + "..." : v;
        }
        if (s instanceof BoolSetting b) return b.get() ? "on" : "off";
        return "";
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubled) {
        ensurePosition();
        double mx = event.x();
        double my = event.y();
        int button = event.button();

        if (numericInputTarget != null) { commitNumericInput(); return true; }
        listeningKeybind = null;

        int closeX = closeButtonX();
        if (mx >= closeX && mx < x + W - 4 && my >= y + 3 && my < y + TITLE_H - 4) {
            this.onClose();
            return true;
        }
        if (my >= y && my < y + TITLE_H && mx >= x && mx < closeX - 1) {
            dragging = true;
            dragOffX = (int) mx - x;
            dragOffY = (int) my - y;
            return true;
        }

        int barY = searchBarY();
        if (my >= barY + 2 && my < barY + SEARCH_H - 3
                && mx >= cfgButtonX() && mx < cfgButtonX() + cfgButtonW()) {
            presetMode = !presetMode;
            presetScroll = 0;
            if (presetMode) { expandedModule = null; colorPickerTarget = null; closeList(); }
            return true;
        }
        if (my >= barY + 2 && my < barY + SEARCH_H - 3
                && mx >= searchFieldX() && mx < searchFieldX() + searchFieldW()) {
            searchFocused = true;
            return true;
        }
        searchFocused = false;

        int catY = panelTop() + PAD - 2;
        for (Category cat : Category.values()) {
            // Must mirror drawSidebar: hidden (empty) categories take no space.
            if (!showsCategory(cat)) continue;
            if (mx >= x && mx < x + SIDEBAR_W && my >= catY && my < catY + ROW_H - 1) {
                selectedCategory = cat;
                expandedModule = null;
                closeList();
                colorPickerTarget = null;
                setSearchQuery("");
                moduleScroll = 0;
                settingsScroll = 0;
                return true;
            }
            catY += ROW_H;
        }

        if (presetMode) {
            return handlePresetClick(mx, my, panelLeft(), panelTop(), panelW(), button);
        }

        int panelX = panelLeft();
        int panelY = panelTop();
        int panelW = panelW();

        if (colorPickerTarget != null) {
            if (button == 1) { colorPickerTarget = null; pickerDragMode = 0; return true; }
            if (my >= panelY && my < panelY + 18 && mx >= panelX && mx < panelX + panelW) {
                colorPickerTarget = null;
                pickerDragMode = 0;
                return true;
            }

            int cx = getPickerCx(panelX, panelW);
            int cy = getPickerCy(panelY);
            double dx = mx - cx;
            double dy = my - cy;
            if (Math.sqrt(dx * dx + dy * dy) <= getPickerRadius() + 8) {
                pickerDragMode = 1;
                applyPickerFromMouse(mx, my, panelX, panelY, panelW);
                return true;
            }

            int sx = getSliderX(panelX);
            int sy = getSliderY(panelY);
            int sw = getSliderW(panelW);
            int sh = getSliderH();
            if (mx >= sx && mx <= sx + sw && my >= sy - 4 && my <= sy + sh + 4) {
                pickerDragMode = 2;
                applyPickerFromMouse(mx, my, panelX, panelY, panelW);
                return true;
            }
            return true;
        }

        if (listMode && expandedModule != null) {
            if (my >= panelY && my < panelY + 18 && mx >= panelX && mx < panelX + panelW) {
                closeList();
                return true;
            }
            if (button == 1) { closeList(); return true; }

            int searchY = panelY + 22;
            if (mx >= panelX + 8 && mx < panelX + panelW - 8
                    && my >= searchY && my < searchY + 14) {
                listSearchFocused = true;
                return true;
            }
            listSearchFocused = false;

            int listTop = searchY + 24;
            int listBottom = panelBottom() - 2;
            int rowH = 13;
            int gap = 6;
            int leftW = (panelW - 12 - gap) * 56 / 100;
            int rightW = panelW - 12 - leftW - gap;
            int leftX = panelX + 6;
            int rightX = leftX + leftW + gap;

            if (mx >= leftX && mx < leftX + leftW && my >= listTop && my < listBottom) {
                int idx = (int) ((my - listTop) / rowH) + listScroll;
                List<String> filtered = getFilteredListIds();
                if (idx >= 0 && idx < filtered.size()) toggleListItem(filtered.get(idx));
                return true;
            }
            if (mx >= rightX && mx < rightX + rightW && my >= listTop && my < listBottom) {
                int idx = (int) ((my - listTop) / rowH) + enabledListScroll;
                List<String> en = getEnabledListIds();
                if (idx >= 0 && idx < en.size()) toggleListItem(en.get(idx));
                return true;
            }
            return true;
        }

        if (expandedModule != null) {
            if (my >= panelY && my < panelY + 18 && mx >= panelX && mx < panelX + panelW) {
                if (returnToEditor) { onClose(); return true; }
                expandedModule = null;
                settingsFilter = "";
                settingsScroll = 0;
                return true;
            }
            if (button == 1) {
                if (returnToEditor) { onClose(); return true; }
                expandedModule = null;
                settingsFilter = "";
                settingsScroll = 0;
                return true;
            }

            List<Setting> settings = getVisibleSettings();
            int listTop = panelY + 22;
            int listBottom = panelBottom() - 2;
            int visible = Math.max(1, (listBottom - listTop) / ROW_H);
            int maxScroll = Math.max(0, settings.size() - visible);
            if (settingsScroll > maxScroll) settingsScroll = maxScroll;
            if (settingsScroll < 0) settingsScroll = 0;

            for (int i = 0; i < settings.size(); i++) {
                int rowY = listTop + (i - settingsScroll) * ROW_H;
                if (rowY + ROW_H <= listTop || rowY >= listBottom) continue;

                if (mx >= panelX && mx < panelX + panelW && my >= rowY && my < rowY + ROW_H) {
                    handleSettingClick(settings.get(i), mx);
                    return true;
                }
            }
            return true;
        }

        List<Module> mods = getVisibleModules();
        int listTop = panelY + PAD - 2;
        int listBottom = panelBottom() - 2;
        int visible = Math.max(1, (listBottom - listTop) / ROW_H);
        int maxScroll = Math.max(0, mods.size() - visible);
        if (moduleScroll > maxScroll) moduleScroll = maxScroll;
        if (moduleScroll < 0) moduleScroll = 0;

        for (int i = 0; i < mods.size(); i++) {
            int rowY = listTop + (i - moduleScroll) * ROW_H;
            if (rowY + ROW_H <= listTop || rowY >= listBottom) continue;

            if (mx >= panelX && mx < panelX + panelW && my >= rowY && my < rowY + ROW_H) {
                Module m = mods.get(i);
                if (button == 0) m.toggle();
                else if (button == 1) {
                    expandedModule = m;
                    settingsScroll = 0;
                    searchFocused = false;
                    // A search left over from browsing must not hide this module's settings.
                    setSearchQuery("");
                    settingsFilter = "";
                }
                return true;
            }
        }
        return super.mouseClicked(event, doubled);
    }

    private void handleSettingClick(Setting s, double mx) {
        if (s instanceof BoolSetting b) {
            b.set(!b.get());
        } else if (s instanceof IntSetting is) {
            beginSlider(is, mx, is.get());
        } else if (s instanceof DoubleSetting ds) {
            beginSlider(ds, mx, ds.get());
        } else if (s instanceof ColorSetting cs) {
            colorPickerTarget = s;
            pickerAlpha = (cs.get() >> 24) & 0xFF;
            if (pickerAlpha == 0) pickerAlpha = 255;
            float[] hsv = Color.RGBtoHSB((cs.get() >> 16) & 0xFF, (cs.get() >> 8) & 0xFF, cs.get() & 0xFF, null);
            pickerHue = hsv[0];
            pickerSat = hsv[1];
            pickerVal = hsv[2];
            pickerDragMode = 0;
        } else if (s instanceof StringSetting ss) {
            String n = ss.getName();
            if (n.equals("entityFilter") || n.equals("blockFilter")
                    || n.equals("hiddenModules") || n.equals("potionFilter")) {
                openList(n);
            } else if (n.equals("editPositions")) {
                if (expandedModule instanceof Hud hud) {
                    Minecraft.getInstance().gui.setScreen(new HudEditorScreen(hud));
                }
            }
        } else if (s instanceof KeybindSetting) {
            listeningKeybind = s;
        }
    }

    private void beginSlider(Setting s, double mx, double value) {
        mouseDownSetting = s;
        mouseDownX = (int) mx;
        mouseDownValue = value;
        // The track is pw - 20 wide (barX = px + 10, barW = pw - 20); using the
        // whole panel width made the knob lag the cursor and stopped the slider
        // from ever reaching its maximum.
        sliderRowW = Math.max(1, panelW() - 20);
        sliderDidDrag = false;
    }

    private boolean handlePresetClick(double mx, double my, int px, int py, int pw, int button) {
        if (button == 1) { presetMode = false; return true; }
        if (mx < px || mx >= px + pw) return true;

        int listTop = py + 24;
        int listBottom = panelBottom() - 2;
        if (my < listTop || my >= listBottom) return true;

        com.baggute.cheatclient.config.ConfigManager manager = UtilityClient.configManager();
        if (manager == null) return true;

        int index = (int) ((my - listTop) / ROW_H) + presetScroll;
        List<String> presets = com.baggute.cheatclient.config.ConfigManager.listPresets();

        if (index == 0) {
            String name = searchQuery.isBlank() ? "quick" : searchQuery.trim();
            if (manager.savePreset(name)) {
                Notifications.push("saved preset: " + name, true);
                setSearchQuery("");
            } else {
                Notifications.push("preset save failed", false);
            }
            return true;
        }

        int presetIndex = index - 1;
        if (presetIndex < 0 || presetIndex >= presets.size()) return true;
        String name = presets.get(presetIndex);

        boolean deleteHit = mx >= px + pw - 26 && mx < px + pw - 10;
        if (deleteHit) {
            if (manager.deletePreset(name)) Notifications.push("deleted: " + name, true);
            else Notifications.push("delete failed: " + name, false);
            return true;
        }

        if (manager.loadPreset(name)) Notifications.push("loaded preset: " + name, true);
        else Notifications.push("preset load failed: " + name, false);
        return true;
    }

    private void applySliderDrag(double mx) {
        if (mouseDownSetting == null) return;
        double deltaFraction = (mx - mouseDownX) / (double) sliderRowW;

        if (mouseDownSetting instanceof IntSetting is) {
            double lo = is.getMin(), hi = is.getMax();
            double newValue = mouseDownValue + deltaFraction * (hi - lo);
            is.set((int) Math.round(Math.max(lo, Math.min(hi, newValue))));
        } else if (mouseDownSetting instanceof DoubleSetting ds) {
            double lo = ds.getMin(), hi = ds.getMax();
            double newValue = mouseDownValue + deltaFraction * (hi - lo);
            ds.set(Math.max(lo, Math.min(hi, newValue)));
        }
    }

    private void commitNumericInput() {
        if (numericInputTarget == null) return;
        try {
            if (numericInputTarget instanceof IntSetting i) {
                i.set((int) Double.parseDouble(numericInputValue));
            } else if (numericInputTarget instanceof DoubleSetting d) {
                d.set(Double.parseDouble(numericInputValue));
            }
        } catch (NumberFormatException ignored) {}
        numericInputTarget = null;
        numericInputValue = "";
    }

    private void applyPickerFromMouse(double mx, double my, int panelX, int panelY, int panelW) {
        if (pickerDragMode == 1) {
            int cx = getPickerCx(panelX, panelW);
            int cy = getPickerCy(panelY);
            int R = getPickerRadius();
            double dx = mx - cx;
            double dy = my - cy;
            double dist = Math.sqrt(dx * dx + dy * dy);
            double theta = Math.atan2(dy, dx);
            if (theta < 0) theta += Math.PI * 2;
            pickerHue = (float) (theta / (Math.PI * 2));
            pickerSat = (float) Math.min(1.0, dist / R);
            updatePickerColor();
        } else if (pickerDragMode == 2) {
            int sx = getSliderX(panelX);
            int sw = getSliderW(panelW);
            double t = (mx - sx) / sw;
            pickerVal = (float) Math.max(0.0, Math.min(1.0, t));
            updatePickerColor();
        }
    }

    @Override
    public boolean mouseDragged(MouseButtonEvent event, double dx, double dy) {
        if (dragging) {
            x = (int) event.x() - dragOffX;
            y = (int) event.y() - dragOffY;
            return true;
        }
        if (colorPickerTarget != null && pickerDragMode != 0) {
            ensurePosition();
            applyPickerFromMouse(event.x(), event.y(), panelLeft(), panelTop(), panelW());
            return true;
        }
        if (mouseDownSetting != null) {
            if (Math.abs(event.x() - mouseDownX) > 2) sliderDidDrag = true;
            if (sliderDidDrag) applySliderDrag(event.x());
            return true;
        }
        return super.mouseDragged(event, dx, dy);
    }

    @Override
    public boolean mouseReleased(MouseButtonEvent event) {
        dragging = false;
        pickerDragMode = 0;

        if (mouseDownSetting != null) {
            if (!sliderDidDrag) {
                numericInputTarget = mouseDownSetting;
                if (mouseDownSetting instanceof IntSetting is) {
                    numericInputValue = String.valueOf(is.get());
                } else if (mouseDownSetting instanceof DoubleSetting ds) {
                    numericInputValue = String.format("%.2f", ds.get());
                }
            }
            mouseDownSetting = null;
            sliderDidDrag = false;
        }
        return super.mouseReleased(event);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double hAmount, double vAmount) {
        if (mx < x || mx >= x + W || my < y || my >= y + H) {
            return super.mouseScrolled(mx, my, hAmount, vAmount);
        }

        if (presetMode) {
            int rows = Math.max(1, (panelBottom() - 2 - (panelTop() + 24)) / ROW_H);
            int total = com.baggute.cheatclient.config.ConfigManager.listPresets().size() + 1;
            int max = Math.max(0, total - rows);
            presetScroll = (int) Math.max(0, Math.min(max, presetScroll - vAmount));
            return true;
        }

        if (colorPickerTarget != null) return true;

        if (listMode && expandedModule != null) {
            int listTop = panelTop() + 46;
            int visible = Math.max(1, (panelBottom() - 2 - listTop) / 13);
            // Same 56/44 split as the drawing code: a 50% split scrolled the wrong
            // list whenever the cursor was over the right edge of the left pane.
            int gap = 6;
            int leftW = (panelW() - 12 - gap) * 56 / 100;
            if (mx >= panelLeft() + 6 && mx < panelLeft() + 6 + leftW) {
                int max = Math.max(0, getFilteredListIds().size() - visible);
                listScroll = (int) Math.max(0, Math.min(max, listScroll - vAmount));
            } else {
                int max = Math.max(0, getEnabledListIds().size() - visible);
                enabledListScroll = (int) Math.max(0, Math.min(max, enabledListScroll - vAmount));
            }
            return true;
        }

        if (expandedModule != null) {
            List<Setting> settings = getVisibleSettings();
            int listTop = panelTop() + 22;
            int visible = Math.max(1, (panelBottom() - 2 - listTop) / ROW_H);
            int max = Math.max(0, settings.size() - visible);
            settingsScroll = (int) Math.max(0, Math.min(max, settingsScroll - vAmount));
            return true;
        }

        List<Module> mods = getVisibleModules();
        int listTop = panelTop() + PAD - 2;
        int visible = Math.max(1, (panelBottom() - 2 - listTop) / ROW_H);
        int max = Math.max(0, mods.size() - visible);
        moduleScroll = (int) Math.max(0, Math.min(max, moduleScroll - vAmount));
        return true;
    }

    @Override
    public boolean keyPressed(KeyEvent event) {
        int keyCode = event.key();

        if (searchFocused) {
            if (keyCode == GLFW.GLFW_KEY_ESCAPE) {
                if (isFiltering()) setSearchQuery("");
                else searchFocused = false;
                return true;
            }
            if (keyCode == GLFW.GLFW_KEY_ENTER || keyCode == GLFW.GLFW_KEY_KP_ENTER) {
                searchFocused = false;
                return true;
            }
            if (keyCode == GLFW.GLFW_KEY_BACKSPACE) {
                if (!searchQuery.isEmpty()) setSearchQuery(searchQuery.substring(0, searchQuery.length() - 1));
                return true;
            }
            String typed = typedChar(keyCode, event.modifiers(), true);
            if (typed != null) { setSearchQuery(searchQuery + typed); return true; }
            return true;
        }

        if (numericInputTarget != null) {
            if (keyCode == GLFW.GLFW_KEY_ESCAPE) {
                numericInputTarget = null; numericInputValue = ""; return true;
            }
            if (keyCode == GLFW.GLFW_KEY_ENTER || keyCode == GLFW.GLFW_KEY_KP_ENTER) {
                commitNumericInput(); return true;
            }
            if (keyCode == GLFW.GLFW_KEY_BACKSPACE) {
                if (!numericInputValue.isEmpty())
                    numericInputValue = numericInputValue.substring(0, numericInputValue.length() - 1);
                return true;
            }
            if (keyCode >= GLFW.GLFW_KEY_0 && keyCode <= GLFW.GLFW_KEY_9) {
                numericInputValue += (char) ('0' + (keyCode - GLFW.GLFW_KEY_0)); return true;
            }
            if (keyCode >= GLFW.GLFW_KEY_KP_0 && keyCode <= GLFW.GLFW_KEY_KP_9) {
                numericInputValue += (char) ('0' + (keyCode - GLFW.GLFW_KEY_KP_0)); return true;
            }
            if ((keyCode == GLFW.GLFW_KEY_PERIOD || keyCode == GLFW.GLFW_KEY_KP_DECIMAL)
                    && !numericInputValue.contains(".")) {
                if (numericInputValue.isEmpty()) numericInputValue = "0";
                numericInputValue += ".";
                return true;
            }
            if (keyCode == GLFW.GLFW_KEY_MINUS) {
                numericInputValue = numericInputValue.startsWith("-")
                        ? numericInputValue.substring(1) : "-" + numericInputValue;
                return true;
            }
            return true;
        }

        if (listSearchFocused && listMode) {
            if (keyCode == GLFW.GLFW_KEY_ESCAPE) {
                if (!listSearchQuery.isEmpty()) listSearchQuery = "";
                else listSearchFocused = false;
                listScroll = 0;
                return true;
            }
            if (keyCode == GLFW.GLFW_KEY_BACKSPACE) {
                if (!listSearchQuery.isEmpty())
                    listSearchQuery = listSearchQuery.substring(0, listSearchQuery.length() - 1);
                listScroll = 0;
                return true;
            }
            String typed = typedChar(keyCode, event.modifiers(), true);
            if (typed != null) { listSearchQuery += typed; listScroll = 0; return true; }
            return true;
        }

        if (colorPickerTarget != null && keyCode == GLFW.GLFW_KEY_ESCAPE) {
            colorPickerTarget = null;
            pickerDragMode = 0;
            return true;
        }

        if (listeningKeybind instanceof KeybindSetting k) {
            if (keyCode == GLFW.GLFW_KEY_ESCAPE) k.setKey(-1);
            else k.setKey(keyCode);
            listeningKeybind = null;
            return true;
        }

        if (keyCode == GLFW.GLFW_KEY_ESCAPE) { this.onClose(); return true; }
        return super.keyPressed(event);
    }

    @Override
    public void onClose() {
        UtilityClient.saveConfig();
        if (returnToEditor && UtilityClient.moduleManager != null
                && UtilityClient.moduleManager.getHud() != null) {
            // Esc goes back one level: widget config -> drag positions -> closed.
            Minecraft.getInstance().gui.setScreen(new HudEditorScreen(UtilityClient.moduleManager.getHud()));
            return;
        }
        super.onClose();
    }

    @Override
    public boolean isPauseScreen() { return false; }
}
