package com.baggute.cheatclient.module.player;
import com.baggute.cheatclient.module.Category;
import com.baggute.cheatclient.module.Module;
import com.baggute.cheatclient.settings.IntSetting;
import com.baggute.cheatclient.util.InventoryUtils;
import net.minecraft.client.Minecraft;
public final class CartGrabber extends Module {
 private final IntSetting targetSlot=new IntSetting("targetSlot","TNT minecart hotbar slot",1,1,9); private int cooldown;
 public CartGrabber(){super("CartGrabber","Moves a TNT minecart from inventory into a chosen hotbar slot.",Category.PLAYER);addSetting(targetSlot);}
 public void onTick(){Minecraft mc=Minecraft.getInstance();if(mc.player==null||cooldown>0||mc.player.containerMenu!=mc.player.inventoryMenu){if(cooldown>0)cooldown--;return;}int target=targetSlot.get()-1;var inv=mc.player.getInventory();if(inv.getItem(target).getItem().toString().contains("tnt_minecart"))return;for(int i=9;i<40;i++){if(inv.getItem(i).getItem().toString().contains("tnt_minecart")){InventoryUtils.swapPlayerSlots(mc,i,InventoryUtils.hotbarMenuSlot(target));cooldown=2;return;}}}
}