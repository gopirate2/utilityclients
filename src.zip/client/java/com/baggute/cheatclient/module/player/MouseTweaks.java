package com.baggute.cheatclient.module.player;

import com.baggute.cheatclient.module.Category;
import com.baggute.cheatclient.module.Module;

/**
 * Shift-drag quick-move across container slots.
 *
 * <p>The wheel/drag-split settings that used to live here were never read by
 * anything and are gone instead of pretending to work; the one behaviour this
 * module actually has is the shift-drag quick-move in
 * {@code ContainerMouseTweaksMixin}.
 */
public final class MouseTweaks extends Module {

    public MouseTweaks() {
        super("MouseTweaks", "Shift-drag to quick-move items across container slots.", Category.PLAYER);
    }
}
