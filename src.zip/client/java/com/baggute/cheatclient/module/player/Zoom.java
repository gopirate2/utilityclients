package com.baggute.cheatclient.module.player;

import com.baggute.cheatclient.module.Category;
import com.baggute.cheatclient.module.Module;
import com.baggute.cheatclient.settings.BoolSetting;
import com.baggute.cheatclient.settings.DoubleSetting;
import com.baggute.cheatclient.settings.IntSetting;
import net.minecraft.client.Minecraft;

public final class Zoom extends Module {
    private final DoubleSetting minFov=new DoubleSetting("minFov","Minimum zoom field of view",10.0,2.0,90.0);
    private final DoubleSetting step=new DoubleSetting("step","FOV change per wheel notch",5.0,1.0,20.0);
    private final BoolSetting hideHand=new BoolSetting("hideHand","Hide first-person hand while zoomed",true);
    private final IntSetting scrollNotches=new IntSetting("scrollNotches","Starting zoom notches",3,0,20);
    private int notches;
    private int originalFov = -1;
    public Zoom(){super("Zoom","Zoomify-style scroll zoom with hand hiding.",Category.PLAYER);addSetting(minFov);addSetting(step);addSetting(hideHand);addSetting(scrollNotches);}
    protected void onEnable(){Minecraft mc=Minecraft.getInstance();originalFov=mc.options.fov().get();notches=scrollNotches.get();apply();}
    protected void onDisable(){Minecraft mc=Minecraft.getInstance();if(originalFov>=0)mc.options.fov().set(originalFov);notches=0;originalFov=-1;}
    /** @return true when the notch was consumed by zooming. */
    public boolean onScroll(double amount){if(!isEnabled())return false;if(amount<=0&&notches<=0)return false;notches=Math.max(0,Math.min(20,notches+(amount>0?1:-1)));apply();return true;}
    private void apply(){Minecraft mc=Minecraft.getInstance();double base=originalFov>=0?originalFov:mc.options.fov().get();double fov=base-notches*step.get();mc.options.fov().set((int)Math.max(minFov.get(),fov));}
    public boolean shouldHideHand(){return isEnabled()&&hideHand.get()&&notches>0;}
}
