package com.baggute.cheatclient.module.player;
import com.baggute.cheatclient.module.Category;
import com.baggute.cheatclient.module.Module;
import com.baggute.cheatclient.settings.BoolSetting;
import com.baggute.cheatclient.util.InventoryUtils;
import net.minecraft.client.Minecraft;
import net.minecraft.world.item.Items;
public final class AutoTotem extends Module {
 private final BoolSetting replaceHeld=new BoolSetting("replaceHeld","Replace a non-totem offhand",true); private int cooldown;
 public AutoTotem(){super("AutoTotem","Moves an inventory totem into the offhand slot.",Category.PLAYER);addSetting(replaceHeld);}
 public void onTick(){
  Minecraft mc=Minecraft.getInstance();
  if(mc.player==null||mc.gameMode==null)return;
  if(cooldown>0){cooldown--;return;}
  // Never click a menu the player is using, and never fight a stack on the cursor.
  if(mc.gui.screen()!=null||mc.isPaused())return;
  if(mc.player.containerMenu!=mc.player.inventoryMenu)return;
  if(!mc.player.containerMenu.getCarried().isEmpty())return;
  if(mc.player.getOffhandItem().is(Items.TOTEM_OF_UNDYING))return;
  if(!replaceHeld.get()&&!mc.player.getOffhandItem().isEmpty())return;
  var inv=mc.player.getInventory();
  // 0..35 only: 36..39 are armour slots, not menu hotbar slots.
  for(int i=0;i<36;i++)if(inv.getItem(i).is(Items.TOTEM_OF_UNDYING)){
   int menu=i<9?InventoryUtils.hotbarMenuSlot(i):i;
   if(InventoryUtils.swapPlayerSlots(mc,menu,InventoryUtils.offhandMenuSlot()))cooldown=2;
   return;
  }
 }
}