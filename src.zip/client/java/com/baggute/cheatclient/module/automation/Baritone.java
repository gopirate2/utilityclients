package com.baggute.cheatclient.module.automation;
import com.baggute.cheatclient.module.Category;
import com.baggute.cheatclient.module.Module;
import com.baggute.cheatclient.UtilityClient;
import com.baggute.cheatclient.settings.StringSetting;
public final class Baritone extends Module {
 private final StringSetting command=new StringSetting("command","Baritone command to run on enable","#goto 0 0"); private boolean available;
 public Baritone(){super("Baritone","Optional Baritone API command bridge; install a matching Baritone Fabric build separately.",Category.AUTOMATION);addSetting(command);}
 protected void onEnable(){available=false;try{Class.forName("baritone.api.BaritoneAPI");available=true;Object provider=Class.forName("baritone.api.BaritoneAPI").getMethod("getProvider").invoke(null);Object primary=provider.getClass().getMethod("getPrimaryBaritone").invoke(provider);Object commands=primary.getClass().getMethod("getCommandManager").invoke(primary);commands.getClass().getMethod("execute",String.class).invoke(commands,command.get());}catch(Throwable ignored){UtilityClient.LOGGER.warn("[Baritone] Optional Baritone API not installed or unavailable.");}}
 protected void onDisable(){if(!available)return;try{Object provider=Class.forName("baritone.api.BaritoneAPI").getMethod("getProvider").invoke(null);Object primary=provider.getClass().getMethod("getPrimaryBaritone").invoke(provider);Object pathing=primary.getClass().getMethod("getPathingBehavior").invoke(primary);pathing.getClass().getMethod("cancelEverything").invoke(pathing);}catch(Throwable ignored){}}
}
