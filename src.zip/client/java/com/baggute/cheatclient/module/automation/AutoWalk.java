package com.baggute.cheatclient.module.automation;
import com.baggute.cheatclient.module.Category;
import com.baggute.cheatclient.module.Module;
import com.baggute.cheatclient.settings.BoolSetting;
import net.minecraft.client.Minecraft;
public final class AutoWalk extends Module {
 private final BoolSetting onlyForward=new BoolSetting("onlyForward","Hold forward only",true);
 public AutoWalk(){super("AutoWalk","Walks forward while enabled and in gameplay.",Category.AUTOMATION);addSetting(onlyForward);}
 public void onTick(){Minecraft mc=Minecraft.getInstance();if(mc.player==null||mc.gui.screen()!=null||mc.isPaused()){release(mc);return;}mc.options.keyUp.setDown(true);if(onlyForward.get()){mc.options.keyDown.setDown(false);mc.options.keyLeft.setDown(false);mc.options.keyRight.setDown(false);}}
 protected void onDisable(){release(Minecraft.getInstance());}
 private void release(Minecraft mc){mc.options.keyUp.setDown(false);}
}