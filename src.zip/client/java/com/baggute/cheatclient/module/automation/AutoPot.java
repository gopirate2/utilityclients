package com.baggute.cheatclient.module.automation;

import com.baggute.cheatclient.module.Category;
import com.baggute.cheatclient.module.Module;
import com.baggute.cheatclient.settings.IntSetting;
import com.baggute.cheatclient.util.ModuleUtils;
import net.minecraft.client.Minecraft;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.protocol.game.ServerboundMovePlayerPacket;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.alchemy.PotionContents;

/**
 * Splashes a hotbar instant-health potion on the player: look straight down,
 * throw, then return to the previous slot.
 */
public final class AutoPot extends Module {

    private final IntSetting health = new IntSetting("health", "Splash at or below this health (2 HP = 1 heart)", 6, 1, 20);
    private int oldSlot = -1;
    private int cooldown;

    public AutoPot() {
        super("AutoPot", "Splashes a hotbar instant health potion on yourself when health is low.", Category.AUTOMATION);
        addSetting(health);
    }

    public void onTick() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.gameMode == null || mc.gui.screen() != null || mc.isPaused()) {
            reset(mc);
            return;
        }
        if (cooldown > 0) {
            cooldown--;
            if (cooldown == 0) reset(mc); // throw has gone out, return to the old slot
            return;
        }
        if (mc.player.isUsingItem()) return; // don't interrupt eating/drinking
        if (mc.player.getHealth() > health.get()) {
            reset(mc);
            return;
        }

        int slot = findInstantHealthSplash(mc);
        if (slot < 0) {
            reset(mc);
            return;
        }

        if (oldSlot < 0) oldSlot = mc.player.getInventory().getSelectedSlot();
        ModuleUtils.select(mc, slot);

        if (!isInstantHealthSplash(mc.player.getMainHandItem())) return;
        splashAtFeet(mc);
        cooldown = 3;
    }

    @Override
    protected void onDisable() {
        reset(Minecraft.getInstance());
        cooldown = 0;
    }

    /** A splash potion is thrown along the look vector, so aim straight down to hit ourselves. */
    private void splashAtFeet(Minecraft mc) {
        float yaw = mc.player.getYRot();
        float oldPitch = mc.player.getXRot();
        mc.player.setXRot(90.0f);
        if (mc.player.connection != null) {
            mc.player.connection.send(new ServerboundMovePlayerPacket.Rot(
                    yaw, 90.0f, mc.player.onGround(), mc.player.horizontalCollision));
        }
        mc.gameMode.useItem(mc.player, InteractionHand.MAIN_HAND);
        mc.player.swing(InteractionHand.MAIN_HAND);
        mc.player.setXRot(oldPitch);
    }

    private void reset(Minecraft mc) {
        if (oldSlot >= 0 && mc.player != null) ModuleUtils.select(mc, oldSlot);
        oldSlot = -1;
    }

    private int findInstantHealthSplash(Minecraft mc) {
        for (int i = 0; i < 9; i++) {
            if (isInstantHealthSplash(mc.player.getInventory().getItem(i))) return i;
        }
        return -1;
    }

    private boolean isInstantHealthSplash(ItemStack stack) {
        if (stack == null || !stack.is(Items.SPLASH_POTION)) return false;
        PotionContents contents = stack.get(DataComponents.POTION_CONTENTS);
        if (contents == null) return false;
        for (MobEffectInstance effect : contents.getAllEffects()) {
            if (effect.getEffect().value() == MobEffects.INSTANT_HEALTH.value()) return true;
        }
        return false;
    }
}
