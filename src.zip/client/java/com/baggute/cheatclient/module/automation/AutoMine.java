package com.baggute.cheatclient.module.automation;
import com.baggute.cheatclient.module.Category;
import com.baggute.cheatclient.module.Module;
import com.baggute.cheatclient.settings.BoolSetting;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.phys.BlockHitResult;
public final class AutoMine extends Module {
 private final BoolSetting holdAttack=new BoolSetting("holdAttack","Continue breaking the selected block",true);
 private BlockPos target;
 public AutoMine(){super("AutoMine","Continues mining the block under the crosshair.",Category.AUTOMATION);addSetting(holdAttack);}
 public void onTick(){Minecraft mc=Minecraft.getInstance();if(mc.player==null||mc.level==null||mc.gameMode==null||mc.gui.screen()!=null||mc.isPaused()){target=null;return;}if(!(mc.hitResult instanceof BlockHitResult hit)){target=null;return;}BlockPos pos=hit.getBlockPos();if(mc.level.getBlockState(pos).isAir()){target=null;return;}if(!pos.equals(target)){target=pos;mc.gameMode.startDestroyBlock(pos,hit.getDirection());}
  // holdAttack=false used to only start the break and never continue it, so the
  // block never broke. Without hold, keep mining while the player holds attack.
  else if(holdAttack.get()||mc.options.keyAttack.isDown())mc.gameMode.continueDestroyBlock(pos,hit.getDirection());}
 protected void onDisable(){target=null;}
}