package com.baggute.cheatclient.module.automation;
import com.baggute.cheatclient.module.Category;
import com.baggute.cheatclient.module.Module;
import com.baggute.cheatclient.settings.IntSetting;
import com.baggute.cheatclient.util.ModuleUtils;
import net.minecraft.client.Minecraft;
import net.minecraft.core.component.DataComponents;
import net.minecraft.world.InteractionHand;
public final class AutoEat extends Module {
 private final IntSetting hunger=new IntSetting("hunger","Start eating at hunger or below",14,1,20); private int oldSlot=-1;
 public AutoEat(){super("AutoEat","Automatically eats food below the configured hunger level.",Category.AUTOMATION);addSetting(hunger);}
 public void onTick(){Minecraft mc=Minecraft.getInstance();if(mc.player==null||mc.gameMode==null||mc.gui.screen()!=null||mc.isPaused()){stop(mc);return;}if(mc.player.getFoodData().getFoodLevel()>hunger.get()){stop(mc);return;}if(oldSlot<0)oldSlot=mc.player.getInventory().getSelectedSlot();int s=-1;for(int i=0;i<9;i++)if(isFood(mc.player.getInventory().getItem(i))){s=i;break;}if(s<0){stop(mc);return;}ModuleUtils.select(mc,s);if(isFood(mc.player.getMainHandItem()))mc.gameMode.useItem(mc.player,InteractionHand.MAIN_HAND);}
 protected void onDisable(){stop(Minecraft.getInstance());}
 private void stop(Minecraft mc){if(oldSlot>=0&&mc.player!=null)ModuleUtils.select(mc,oldSlot);oldSlot=-1;}
 private boolean isFood(net.minecraft.world.item.ItemStack stack){return stack.has(DataComponents.FOOD);}
}
