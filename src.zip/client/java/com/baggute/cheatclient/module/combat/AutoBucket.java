package com.baggute.cheatclient.module.combat;

import com.baggute.cheatclient.module.Category;
import com.baggute.cheatclient.module.Module;
import com.baggute.cheatclient.settings.BoolSetting;
import com.baggute.cheatclient.settings.IntSetting;
import com.baggute.cheatclient.util.ModuleUtils;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;

public final class AutoBucket extends Module {
    private final BoolSetting autoSwap=new BoolSetting("autoSwap","Switch to an empty bucket",true);
    private final IntSetting delay=new IntSetting("delay","Ticks between steals",3,1,20);
    private int cooldown;
    public AutoBucket(){super("AutoBucket","Steals water placed in an opponent's immediate area.",Category.COMBAT);addSetting(autoSwap);addSetting(delay);}
    public void onTick(){
        Minecraft mc=Minecraft.getInstance();
        if(mc.player==null||mc.level==null||mc.gameMode==null)return;
        if(cooldown>0){cooldown--;return;}
        var opponent=ModuleUtils.nearestPlayer(mc,6.0);
        if(opponent==null||opponent==mc.player||opponent.distanceToSqr(mc.player)<4.0)return;
        BlockPos water=findOpponentWater(mc,opponent.blockPosition());
        if(water==null)return;
        // The server drops use-on-block packets outside block reach without notice.
        if(!mc.player.isWithinBlockInteractionRange(water,0.5))return;
        int slot=findEmptyBucket(mc); if(slot<0)return;
        if(!isEmptyBucket(mc.player.getMainHandItem())){if(autoSwap.get())ModuleUtils.select(mc,slot);return;}
        var result=mc.gameMode.useItemOn(mc.player,InteractionHand.MAIN_HAND,new BlockHitResult(Vec3.atCenterOf(water),Direction.UP,water,false));
        if(result!=null&&result.consumesAction())cooldown=delay.get();
    }
    private BlockPos findOpponentWater(Minecraft mc,BlockPos center){
        for(int x=-2;x<=2;x++)for(int y=-1;y<=1;y++)for(int z=-2;z<=2;z++){
            BlockPos pos=center.offset(x,y,z);
            if(!mc.level.getBlockState(pos).is(Blocks.WATER))continue;
            if(pos.distSqr(mc.player.blockPosition())<=4.0)continue;
            if(!mc.player.isWithinBlockInteractionRange(pos,0.5))continue;
            return pos;
        }
        return null;
    }
    private int findEmptyBucket(Minecraft mc){for(int i=0;i<9;i++)if(isEmptyBucket(mc.player.getInventory().getItem(i)))return i;return -1;}
    // Exact item only: milk/fish buckets also match the "bucket" substring and do
    // the wrong thing on water.
    private boolean isEmptyBucket(ItemStack s){return s.is(net.minecraft.world.item.Items.BUCKET);}
}
