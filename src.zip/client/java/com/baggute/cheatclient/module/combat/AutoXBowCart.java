// language: Java, file: AutoXBowCart.java, target: Fabric 26.2
package com.baggute.cheatclient.module.combat;

import com.baggute.cheatclient.module.Category;
import com.baggute.cheatclient.module.Module;
import com.baggute.cheatclient.settings.BoolSetting;
import com.baggute.cheatclient.settings.DoubleSetting;
import com.baggute.cheatclient.settings.IntSetting;
import com.baggute.cheatclient.util.ModuleUtils;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;

/**
 * Rail cart: a rail under the target, a TNT minecart on the rail, then ignition.
 *
 * <p>A TNT minecart only primes from fire/explosion damage, so when a Flame bow is
 * in the hotbar it draws and releases one through the cart; otherwise the module
 * still fires its crossbow shot but that bolt cannot prime the cart.
 */
public class AutoXBowCart extends Module {

    private final com.baggute.cheatclient.settings.KeybindSetting activate;
    private final DoubleSetting range;
    private final IntSetting chargeTicks;
    private final IntSetting placeDelay;
    private final BoolSetting lightFire;

    private Stage stage = Stage.IDLE;
    private int cooldown = 0;
    private int stageTicks = 0;
    private int charge = 0;
    private int igniteCharge = 0;
    private BlockPos railPos = null;
    private boolean manualRequest = false;

    private enum Stage { IDLE, RAIL, CART, FIRE, DRAW, RELEASE }

    public AutoXBowCart() {
        super("AutoXBowCart", "Places a rail and TNT minecart, then detonates it with a flame-arrow crossbow shot.", Category.COMBAT);

        this.activate = new com.baggute.cheatclient.settings.KeybindSetting(
                "fire", "Key to run one cart cycle", -1, false);
        this.range = new DoubleSetting("range", "Target range", 6.0, 2.0, 12.0);
        this.chargeTicks = new IntSetting("chargeTicks", "Crossbow charge ticks", 25, 10, 60);
        this.placeDelay = new IntSetting("placeDelay", "Ticks between cycles", 20, 5, 80);
        this.lightFire = new BoolSetting("lightFire", "Ignite the cart with a Flame bow when available", true);

        addSetting(activate);
        addSetting(range);
        addSetting(chargeTicks);
        addSetting(placeDelay);
        addSetting(lightFire);
    }

    @Override
    public void onTick() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null || mc.gameMode == null) return;
        if (mc.gui.screen() != null || mc.isPaused()) { release(mc); return; }
        if (cooldown > 0) cooldown--;
        if (stage == Stage.IDLE) return;
        manualRequest = false;
        if (++stageTicks > 160) { cancel(mc); return; }

        switch (stage) {
            case RAIL -> {
                if (railPos == null) { cancel(mc); return; }
                Placement.Result result = Placement.useOn(mc, "rail", railPos.below());
                if (result == Placement.Result.WAITING) return;
                if (result != Placement.Result.USED) { cancel(mc); return; }
                stage = Stage.CART;
                com.baggute.cheatclient.module.misc.Debug.stage("AutoXBowCart", stage.name());
                stageTicks = 0;
            }
            case CART -> {
                if (railPos == null) { cancel(mc); return; }
                // Use the cart on the rail itself; the floor below is not a rail and
                // MinecartItem refuses to spawn against it.
                Placement.Result result = Placement.useOn(mc, "tnt_minecart", railPos);
                if (result == Placement.Result.WAITING) return;
                if (result != Placement.Result.USED) { cancel(mc); return; }
                stage = lightFire.get() ? Stage.FIRE : Stage.DRAW;
                stageTicks = 0;
            }
            case FIRE -> {
                Entity cart = findCart(mc);
                if (cart == null) return; // wait for the add-entity packet
                int bow = Ignition.flameBowSlot(mc);
                if (bow < 0) {
                    // No Flame bow: fall back to the crossbow shot (it will not
                    // prime the cart, but the cycle still finishes).
                    stage = Stage.DRAW;
                    com.baggute.cheatclient.module.misc.Debug.stage("AutoXBowCart", stage.name());
                    stageTicks = 0;
                    return;
                }
                if (mc.player.getInventory().getSelectedSlot() != bow) {
                    ModuleUtils.select(mc, bow);
                    return;
                }
                // A flame arrow primes the cart; the crossbow bolt cannot because a
                // minecart only ignites from fire/explosion damage.
                Ignition.aimServerSide(mc, cart.position().add(0, cart.getBbHeight() * 0.5, 0));
                if (!mc.player.isUsingItem()) {
                    mc.gameMode.useItem(mc.player, InteractionHand.MAIN_HAND);
                    igniteCharge = 0;
                    return;
                }
                if (++igniteCharge < 20) return;
                mc.gameMode.releaseUsingItem(mc.player);
                mc.player.swing(InteractionHand.MAIN_HAND);
                cancel(mc);
                cooldown = placeDelay.get();
            }
            case DRAW -> {
                Entity cart = findCart(mc);
                if (cart == null) return; // the add-entity packet may still be in flight
                if (ModuleUtils.findHotbarItem(mc, "crossbow") < 0) { cancel(mc); return; }

                if (!ModuleUtils.matches(mc.player.getMainHandItem(), "crossbow")) {
                    ModuleUtils.select(mc, ModuleUtils.findHotbarItem(mc, "crossbow"));
                    charge = 0; // a swap restarts the draw, never inherits a stale count
                    return;
                }

                // Aim through the fire at the cart before the bolt leaves, and send the
                // rotation first: the server resolves the shot with its own rotation.
                AimPipeline.snapTo(mc, cart.position().add(0, cart.getBbHeight() * 0.5, 0));
                if (mc.player.connection != null) {
                    mc.player.connection.send(new net.minecraft.network.protocol.game.ServerboundMovePlayerPacket.Rot(
                            mc.player.getYRot(), mc.player.getXRot(),
                            mc.player.onGround(), mc.player.horizontalCollision));
                }

                if (!mc.player.isUsingItem()) {
                    mc.gameMode.useItem(mc.player, InteractionHand.MAIN_HAND);
                    charge = 0;
                    return;
                }
                if (++charge < chargeTicks.get()) return;
                stage = Stage.RELEASE;
                com.baggute.cheatclient.module.misc.Debug.stage("AutoXBowCart", stage.name());
                stageTicks = 0;
            }
            case RELEASE -> {
                mc.gameMode.releaseUsingItem(mc.player);
                mc.player.swing(InteractionHand.MAIN_HAND);
                cooldown = placeDelay.get();
                cancel(mc);
            }
            default -> cancel(mc);
        }
    }

    @Override
    public void onRenderFrame(float partialTick) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null || stage != Stage.IDLE) return;
        if (cooldown > 0 && !manualRequest) return;
        if (mc.gui.screen() != null || mc.isPaused()) return;
        if (ModuleUtils.findHotbarItem(mc, "rail") < 0
                || ModuleUtils.findHotbarItem(mc, "tnt_minecart") < 0
                || ModuleUtils.findHotbarItem(mc, "crossbow") < 0) return;

        Player target = ModuleUtils.nearestPlayer(mc, range.get());
        if (target == null) return;

        // The block the target is standing IN is the spot to fill; blockPosition().below()
        // is solid ground and can never take a rail.
        BlockPos candidate = target.blockPosition();
        if (candidate.distSqr(mc.player.blockPosition()) > range.get() * range.get()) return;

        // Full spot under the enemy: take the nearest free one beside them instead of
        // skipping the whole cycle.
        if (!mc.level.getBlockState(candidate).canBeReplaced()
                || mc.level.getBlockState(candidate.below()).canBeReplaced()) {
            candidate = Placement.findSpot(mc, candidate, 2.0);
            if (candidate == null) return;
        }

        railPos = candidate;
        stage = Stage.RAIL;
        com.baggute.cheatclient.module.misc.Debug.stage("AutoXBowCart", stage.name());
        stageTicks = 0;
    }

    private Entity findCart(Minecraft mc) {
        if (railPos == null) return null;
        Vec3 center = Vec3.atCenterOf(railPos).add(0, 0.5, 0);
        for (Entity entity : mc.level.entitiesForRendering()) {
            if (!entity.getType().getDescriptionId().toLowerCase().contains("tnt_minecart")) continue;
            if (entity.position().distanceToSqr(center) > 9.0) continue;
            return entity;
        }
        return null;
    }

    private void release(Minecraft mc) {
        if (mc.player == null || mc.gameMode == null) return;
        if (mc.player.isUsingItem()) mc.gameMode.releaseUsingItem(mc.player);
    }

    private void cancel(Minecraft mc) {
        release(mc);
        stage = Stage.IDLE;
        com.baggute.cheatclient.module.misc.Debug.stage("AutoXBowCart", stage.name());
        stageTicks = 0;
        charge = 0;
        igniteCharge = 0;
        railPos = null;
    }

    @Override
    public void onRawKey(int keyCode, int action) {
        if (action != 1) return;
        if (activate.getKey() == -1 || keyCode != activate.getKey()) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null) return;
        if (mc.gui.screen() != null || mc.isPaused()) return;

        // Key press forces one cycle past the cooldown gate.
        if (stage == Stage.IDLE) manualRequest = true;
    }

    @Override
    protected void onEnable() { cancel(Minecraft.getInstance()); cooldown = 0; }

    @Override
    protected void onDisable() { cancel(Minecraft.getInstance()); cooldown = 0; }
}
