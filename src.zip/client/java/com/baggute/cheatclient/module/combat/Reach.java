// language: Java, file: Reach.java, target: Fabric 26.2
package com.baggute.cheatclient.module.combat;

import com.baggute.cheatclient.module.Category;
import com.baggute.cheatclient.module.Module;
import com.baggute.cheatclient.settings.BoolSetting;
import com.baggute.cheatclient.settings.DoubleSetting;
import net.minecraft.client.Minecraft;
import net.minecraft.network.protocol.game.ServerboundMovePlayerPacket;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;

/**
 * PVP reach: while clicking, lands a silent-aim hit on the nearest player inside
 * the extended range instead of waiting for them to step into vanilla reach.
 *
 * <p>The server validates entity interactions with
 * {@code entityInteractionRange + 3.0}, so the slider is capped at 6 blocks and
 * anything the server would drop is never sent.
 */
public final class Reach extends Module {

    private final DoubleSetting range = new DoubleSetting("range", "Maximum attack range", 4.5, 3.0, 6.0);
    private final BoolSetting onlyWhileClicking =
            new BoolSetting("onlyWhileClicking", "Only extend while left-click is held", true);
    private final BoolSetting swing = new BoolSetting("swing", "Swing hand", true);

    public Reach() {
        super("Reach", "Extends your attack range while clicking.", Category.COMBAT);
        addSetting(range);
        addSetting(onlyWhileClicking);
        addSetting(swing);
    }

    @Override
    public void onTick() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.gameMode == null || mc.level == null) return;
        if (mc.gui.screen() != null || mc.isPaused()) return;
        if (onlyWhileClicking.get() && !mc.options.keyAttack.isDown()) return;
        if (mc.player.getAttackStrengthScale(0.5f) < 0.95f) return;

        double max = Math.min(range.get(), mc.player.entityInteractionRange() + 2.5);
        Player target = nearest(mc, max);
        if (target == null) return;

        // Let vanilla handle anything already inside normal reach.
        if (mc.player.distanceTo(target) <= mc.player.entityInteractionRange()) return;

        Vec3 point = AimPipeline.closestPoint(target, mc.player.getEyePosition(1.0f), 0);
        float oldYaw = mc.player.getYRot();
        float oldPitch = mc.player.getXRot();

        AimPipeline.snapTo(mc, point);
        if (mc.player.connection != null) {
            mc.player.connection.send(new ServerboundMovePlayerPacket.Rot(
                    mc.player.getYRot(), mc.player.getXRot(),
                    mc.player.onGround(), mc.player.horizontalCollision));
        }
        mc.gameMode.attack(mc.player, target);
        if (swing.get()) mc.player.swing(InteractionHand.MAIN_HAND);
        AimPipeline.apply(mc, oldYaw, oldPitch);
    }

    /** Nearest living player inside range and roughly in front of the camera. */
    private Player nearest(Minecraft mc, double maxRange) {
        Player best = null;
        double bestDist = maxRange * maxRange;
        Vec3 look = mc.player.getViewVector(1.0f);

        for (var entity : mc.level.entitiesForRendering()) {
            if (!(entity instanceof Player player) || player == mc.player) continue;
            if (!player.isAlive() || player.getHealth() <= 0) continue;
            double distance = player.distanceToSqr(mc.player);
            if (distance > bestDist) continue;

            Vec3 to = player.position().add(0, player.getBbHeight() * 0.5, 0)
                    .subtract(mc.player.getEyePosition()).normalize();
            if (to.dot(look) < 0.5) continue; // ~60 degrees

            bestDist = distance;
            best = player;
        }
        return best;
    }
}
