// language: Java, file: AutoMace.java, target: Fabric 26.2
package com.baggute.cheatclient.module.combat;

import com.baggute.cheatclient.UtilityClient;
import com.baggute.cheatclient.module.Category;
import com.baggute.cheatclient.module.Module;
import com.baggute.cheatclient.settings.BoolSetting;
import com.baggute.cheatclient.settings.DoubleSetting;
import com.baggute.cheatclient.settings.IntSetting;
import com.baggute.cheatclient.util.ModuleUtils;
import net.minecraft.client.Minecraft;
import net.minecraft.network.protocol.game.ServerboundMovePlayerPacket;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;

import java.util.Random;

/**
 * Mace swings with silent aim.
 *
 * The rotation is applied to the player, a rotation packet is sent, the attack
 * fires, and the old rotation is put back in the same tick — so on your screen
 * nothing moved, while the server saw you aimed at the target.
 *
 * minCharge defaults to 0: the swing lands whether or not the attack bar is full,
 * which is how mace spam is meant to feel. Raise it if you want vanilla pacing.
 */
public class AutoMace extends Module {

    private final DoubleSetting range;
    private final DoubleSetting minCharge;
    private final DoubleSetting missChance;
    private final IntSetting cooldownTicks;
    private final BoolSetting autoSwap;
    private final BoolSetting silentAim;
    private final BoolSetting requireFall;
    private final BoolSetting requireLineOfSight;
    private final BoolSetting onlyWhileClicking;

    private final Random rng = new Random();

    private int previousSlot = -1;
    private int swapBackTicks = 0;
    private int attackCooldownTicks = 0;

    public AutoMace() {
        super("AutoMace", "Swings a mace at nearby players with silent aim.", Category.COMBAT);

        this.range = new DoubleSetting("range", "Target range", 4.5, 1.0, 6.0);
        this.minCharge = new DoubleSetting("minCharge", "Minimum attack charge (0 = any)", 0.0, 0.0, 1.0);
        this.missChance = new DoubleSetting("missChance", "Chance to swing air (%)", 0.0, 0.0, 100.0);
        this.cooldownTicks = new IntSetting("cooldownTicks", "Ticks between swings", 8, 1, 40);
        this.autoSwap = new BoolSetting("autoSwap", "Swap to the mace only when attacking", true);
        this.silentAim = new BoolSetting("silentAim", "Aim server-side only", true);
        this.requireFall = new BoolSetting("requireFall", "Only swing while falling (crit)", false);
        this.requireLineOfSight = new BoolSetting("requireLineOfSight", "Skip targets behind blocks", true);
        this.onlyWhileClicking = new BoolSetting("onlyWhileClicking", "Only swing while left-click held", false);

        addSetting(range);
        addSetting(minCharge);
        addSetting(missChance);
        addSetting(cooldownTicks);
        addSetting(autoSwap);
        addSetting(silentAim);
        addSetting(requireFall);
        addSetting(requireLineOfSight);
        addSetting(onlyWhileClicking);
    }

    @Override
    public void onTick() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null || mc.gameMode == null) return;

        if (attackCooldownTicks > 0) attackCooldownTicks--;
        restoreSlotIfReady(mc);
        if (attackCooldownTicks > 0) return;
        if (mc.gui.screen() != null || mc.isPaused()) return;
        if (onlyWhileClicking.get() && !mc.options.keyAttack.isDown()) return;

        if (requireFall.get() && !AimPipeline.isFallingForCrit(mc)) return;
        if (mc.player.getAttackStrengthScale(0.0F) < minCharge.get()) return;

        LivingEntity target = (LivingEntity) AimPipeline.pickTarget(
                mc, range.get(), 180.0, null, requireLineOfSight.get());
        if (target == null) return;

        if (!isMace(mc.player.getMainHandItem())) {
            if (!autoSwap.get()) return;
            int maceSlot = findMaceSlot(mc);
            if (maceSlot < 0 || maceSlot == mc.player.getInventory().getSelectedSlot()) return;
            previousSlot = mc.player.getInventory().getSelectedSlot();
            ModuleUtils.select(mc, maceSlot);
            // Hold the swap open across the next tick so the swing below can land
            // before the swap-back; otherwise the restore undid the equip first and
            // the module flickered the hotbar without ever attacking.
            swapBackTicks = 2;
            return; // swing on the next tick with the mace actually held
        }

        if (missChance.get() > 0.0 && rng.nextDouble() * 100.0 < missChance.get()) {
            mc.player.swing(InteractionHand.MAIN_HAND);
        } else {
            swing(mc, target);
        }

        attackCooldownTicks = cooldownTicks.get();
        if (previousSlot >= 0) swapBackTicks = 2;
    }

    private void swing(Minecraft mc, Entity target) {
        Vec3 point = AimPipeline.closestPoint(target, mc.player.getEyePosition(1.0f), 0);

        if (!silentAim.get()) {
            AimPipeline.snapTo(mc, point);
            mc.gameMode.attack(mc.player, target);
            mc.player.swing(InteractionHand.MAIN_HAND);
            return;
        }

        float oldYaw = mc.player.getYRot();
        float oldPitch = mc.player.getXRot();

        AimPipeline.snapTo(mc, point);
        if (mc.player.connection != null) {
            mc.player.connection.send(new ServerboundMovePlayerPacket.Rot(
                    mc.player.getYRot(), mc.player.getXRot(),
                    mc.player.onGround(), mc.player.horizontalCollision));
        }
        mc.gameMode.attack(mc.player, target);
        mc.player.swing(InteractionHand.MAIN_HAND);

        AimPipeline.apply(mc, oldYaw, oldPitch);
    }

    private void restoreSlotIfReady(Minecraft mc) {
        if (swapBackTicks > 0) swapBackTicks--;
        if (swapBackTicks == 0 && previousSlot >= 0) {
            if (isMace(mc.player.getMainHandItem())
                    && mc.player.getInventory().getSelectedSlot() != previousSlot) {
                ModuleUtils.select(mc, previousSlot);
            }
            previousSlot = -1;
        }
    }

    private boolean isMace(ItemStack stack) {
        return ModuleUtils.matches(stack, "mace");
    }

    private int findMaceSlot(Minecraft mc) {
        return ModuleUtils.findHotbarItem(mc, "mace");
    }

    @Override
    protected void onEnable() {
        previousSlot = -1;
        swapBackTicks = 0;
        attackCooldownTicks = 0;
        UtilityClient.LOGGER.info("[AutoMace] enabled");
    }

    @Override
    protected void onDisable() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player != null && previousSlot >= 0 && isMace(mc.player.getMainHandItem())) {
            ModuleUtils.select(mc, previousSlot);
        }
        previousSlot = -1;
        swapBackTicks = 0;
        attackCooldownTicks = 0;
    }
}
