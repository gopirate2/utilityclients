package com.baggute.cheatclient.module.combat;

import com.baggute.cheatclient.module.Category;
import com.baggute.cheatclient.module.Module;
import com.baggute.cheatclient.settings.BoolSetting;
import com.baggute.cheatclient.settings.DoubleSetting;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;

/**
 * Rotates toward a visible living target while attacking. Target selection and
 * rotation both come from AimPipeline, so it shares behaviour with AimAssist.
 */
public final class Aimbot extends Module {

    private final DoubleSetting range  = new DoubleSetting("range", "Target range", 4.5, 1.0, 6.0);
    private final DoubleSetting speed  = new DoubleSetting("speed", "Aim speed", 0.5, 0.05, 1.0);
    private final DoubleSetting fov    = new DoubleSetting("fov", "Target FOV", 120.0, 5.0, 180.0);
    private final BoolSetting snapEyes = new BoolSetting("aimEyes", "Aim at the head instead of the box", false);

    public Aimbot() {
        super("Aimbot", "Rotates toward a visible living target while attacking.", Category.COMBAT);
        addSetting(range);
        addSetting(speed);
        addSetting(fov);
        addSetting(snapEyes);
    }

    @Override
    public void onTick() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null) return;
        if (mc.gui.screen() != null || mc.isPaused()) return;
        if (!mc.options.keyAttack.isDown()) return;

        Entity target = AimPipeline.pickTarget(mc, range.get(), fov.get(), null, true);
        if (!(target instanceof LivingEntity living)) return;

        Vec3 point = snapEyes.get()
                ? living.getEyePosition()
                : AimPipeline.closestPoint(living, mc.player.getEyePosition(1.0f), 0);

        AimPipeline.rotateTo(mc, point, speed.get(), 1.0, true, 0.2);
    }
}
