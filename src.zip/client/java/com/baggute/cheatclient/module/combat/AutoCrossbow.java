package com.baggute.cheatclient.module.combat;

import com.baggute.cheatclient.UtilityClient;
import com.baggute.cheatclient.module.Category;
import com.baggute.cheatclient.module.Module;
import com.baggute.cheatclient.settings.BoolSetting;
import com.baggute.cheatclient.settings.IntSetting;
import com.baggute.cheatclient.settings.KeybindSetting;
import com.baggute.cheatclient.util.ModuleUtils;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.world.InteractionHand;

/**
 * Keybind macro: rail, cart, fire, then a fully charged crossbow bolt.
 *
 * <p>One action per tick so the carried-item packet always lands before the use
 * packet. The old version released the crossbow in the same tick it started the
 * draw, which cancelled the charge and made the bolt stage pointless.
 */
public final class AutoCrossbow extends Module {

    private final KeybindSetting xbow = new KeybindSetting("Xbow", "Place rail, cart, fire, and shoot", -1, false);
    private final BoolSetting autoSwap = new BoolSetting("autoSwap", "Switch through required items", true);
    private final IntSetting railSlot = new IntSetting("railSlot", "Rail hotbar slot", 1, 1, 9);
    private final IntSetting cartSlot = new IntSetting("cartSlot", "Cart hotbar slot", 2, 1, 9);
    private final IntSetting fireSlot = new IntSetting("fireSlot", "Flint and steel hotbar slot", 3, 1, 9);
    private final IntSetting crossbowSlot = new IntSetting("crossbowSlot", "Crossbow hotbar slot", 4, 1, 9);
    private final IntSetting chargeTicks = new IntSetting("chargeTicks", "Crossbow charge ticks", 25, 10, 60);

    private boolean armed;
    private int stage;
    private int charge;
    private int stageTicks;
    private int oldSlot = -1;
    private BlockPos railPos;

    public AutoCrossbow() {
        super("AutoCrossbow", "Xbow keybind rail-cart-fire-crossbow sequence.", Category.COMBAT);
        addSetting(xbow);
        addSetting(autoSwap);
        addSetting(railSlot);
        addSetting(cartSlot);
        addSetting(fireSlot);
        addSetting(crossbowSlot);
        addSetting(chargeTicks);
    }

    @Override
    public void onRawKey(int key, int action) {
        if (!isEnabled() || action != 1 || key != xbow.getKey()) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.gameMode == null) return;
        if (mc.gui.screen() != null || mc.isPaused()) return;
        if (armed) return;
        if (!has(mc, railSlot.get() - 1, "rail")
                || !has(mc, cartSlot.get() - 1, "minecart")
                || !has(mc, fireSlot.get() - 1, "flint_and_steel")
                || !has(mc, crossbowSlot.get() - 1, "crossbow")) {
            return;
        }
        armed = true;
        stage = 0;
        charge = 0;
        stageTicks = 0;
    }

    @Override
    public void onTick() {
        Minecraft mc = Minecraft.getInstance();
        if (!armed || mc.player == null || mc.gameMode == null) return;
        if (mc.gui.screen() != null || mc.isPaused()) { abort(mc); return; }
        if (++stageTicks > 200) { abort(mc); return; }

        switch (stage) {
            case 0 -> {
                oldSlot = mc.player.getInventory().getSelectedSlot();
                if (!select(mc, railSlot.get() - 1, "rail")) { abort(mc); return; }
                next();
            }
            case 1 -> {
                BlockPos target = crosshairBlock(mc);
                if (target == null) { abort(mc); return; }
                Placement.Result result = Placement.useOn(mc, "rail", target.below());
                if (result == Placement.Result.WAITING) return;
                if (result != Placement.Result.USED) { abort(mc); return; }
                railPos = target;
                next();
            }
            case 2 -> {
                if (!select(mc, cartSlot.get() - 1, "minecart")) { abort(mc); return; }
                next();
            }
            case 3 -> {
                if (railPos == null) { abort(mc); return; }
                Placement.Result result = Placement.useOn(mc, "tnt_minecart", railPos);
                if (result == Placement.Result.WAITING) return;
                if (result != Placement.Result.USED) { abort(mc); return; }
                next();
            }
            case 4 -> {
                if (!select(mc, fireSlot.get() - 1, "flint_and_steel")) { abort(mc); return; }
                next();
            }
            case 5 -> {
                // Fire is cosmetic here (a plain bolt cannot prime the cart); a
                // failed ignition must not abort the rest of the sequence.
                BlockPos target = crosshairBlock(mc);
                if (target != null) {
                    Placement.Result result = Placement.useOn(mc, "flint_and_steel", target.below());
                    if (result == Placement.Result.WAITING) return;
                }
                next();
            }
            case 6 -> {
                if (!select(mc, crossbowSlot.get() - 1, "crossbow")) { abort(mc); return; }
                next();
            }
            case 7 -> {
                if (!use(mc, "crossbow")) { abort(mc); return; }
                charge = 0;
                next();
                return;
            }
            case 8 -> {
                // Hold the crossbow selected until the draw is complete; swapping
                // the held stack cancels the use and fires nothing.
                if (!mc.player.isUsingItem()) {
                    if (!ModuleUtils.matches(mc.player.getMainHandItem(), "crossbow")) {
                        abort(mc);
                        return;
                    }
                    mc.gameMode.useItem(mc.player, InteractionHand.MAIN_HAND);
                    return;
                }
                if (++charge < chargeTicks.get()) return;
                next();
            }
            case 9 -> {
                mc.gameMode.releaseUsingItem(mc.player);
                mc.player.swing(InteractionHand.MAIN_HAND);
                finish(mc);
            }
            default -> abort(mc);
        }
    }

    private void next() {
        stage++;
        stageTicks = 0;
    }

    private void finish(Minecraft mc) {
        if (oldSlot >= 0) ModuleUtils.select(mc, oldSlot);
        armed = false;
        stage = 0;
        charge = 0;
        oldSlot = -1;
        railPos = null;
    }

    private void abort(Minecraft mc) {
        if (mc.player != null && mc.player.isUsingItem()) {
            mc.gameMode.releaseUsingItem(mc.player);
        }
        if (oldSlot >= 0) ModuleUtils.select(mc, oldSlot);
        armed = false;
        stage = 0;
        charge = 0;
        oldSlot = -1;
        railPos = null;
    }

    private boolean has(Minecraft mc, int slot, String item) {
        return slot >= 0 && slot < 9 && ModuleUtils.matches(mc.player.getInventory().getItem(slot), item);
    }

    private boolean select(Minecraft mc, int slot, String item) {
        if (!has(mc, slot, item)) return false;
        if (autoSwap.get()) ModuleUtils.select(mc, slot);
        return ModuleUtils.matches(mc.player.getMainHandItem(), item);
    }

    private boolean use(Minecraft mc, String item) {
        if (!ModuleUtils.matches(mc.player.getMainHandItem(), item)) return false;
        mc.gameMode.useItem(mc.player, InteractionHand.MAIN_HAND);
        return true;
    }

    private BlockPos crosshairBlock(Minecraft mc) {
        if (mc.hitResult instanceof net.minecraft.world.phys.BlockHitResult hit
                && hit.getType() == net.minecraft.world.phys.HitResult.Type.BLOCK) {
            return hit.getBlockPos();
        }
        return null;
    }

    @Override
    protected void onEnable() {
        armed = false;
        stage = 0;
        charge = 0;
        oldSlot = -1;
        railPos = null;
        UtilityClient.LOGGER.info("[AutoCrossbow] enabled");
    }

    @Override
    protected void onDisable() {
        abort(Minecraft.getInstance());
    }
}
