package com.baggute.cheatclient.module.combat;

import com.baggute.cheatclient.module.Category;
import com.baggute.cheatclient.module.Module;
import com.baggute.cheatclient.settings.BoolSetting;
import com.baggute.cheatclient.settings.IntSetting;
import com.baggute.cheatclient.util.ModuleUtils;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.level.block.Blocks;

public final class WebDrain extends Module {
    private final BoolSetting autoSwap=new BoolSetting("autoSwap","Switch to water bucket",true);
    private final IntSetting delay=new IntSetting("delay","Ticks between drains",4,1,20);
    private int cooldown;
    public WebDrain(){super("WebDrain","Uses water to drain cobwebs trapping the player.",Category.COMBAT);addSetting(autoSwap);addSetting(delay);}
    public void onTick(){Minecraft mc=Minecraft.getInstance();if(mc.player==null||mc.level==null||mc.gameMode==null)return;if(cooldown>0){cooldown--;return;}if(!isInCobweb(mc))return;int s=ModuleUtils.findHotbarItem(mc,"water_bucket");if(s<0)return;if(!ModuleUtils.matches(mc.player.getMainHandItem(),"water_bucket")){if(autoSwap.get())ModuleUtils.select(mc,s);return;}mc.gameMode.useItem(mc.player,InteractionHand.MAIN_HAND);cooldown=delay.get();}
    /** Cobwebs are not solid, so isInWall()/isInWater() never fire while stuck in one. */
    private boolean isInCobweb(Minecraft mc){BlockPos feet=mc.player.blockPosition();return mc.level.getBlockState(feet).is(Blocks.COBWEB)||mc.level.getBlockState(feet.above()).is(Blocks.COBWEB);}
}
