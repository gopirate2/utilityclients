// language: Java, file: Placement.java, target: Fabric 26.2
package com.baggute.cheatclient.module.combat;

import com.baggute.cheatclient.util.ModuleUtils;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.Vec3;

/**
 * One placement path for every automation module.
 *
 * <p>The result is deliberately multi-state. "I selected the item, try again next
 * tick" is NOT the same as "placed" — collapsing the two into a boolean made the
 * callers advance their stage without ever placing anything.
 *
 * <p>The server validates every use-on-block packet with
 * {@code isWithinBlockInteractionRange(pos, 1.0)} and drops it silently when the
 * block is too far, so placements are range-checked here first and the
 * interaction result is actually inspected.
 */
public final class Placement {

    private Placement() {}

    public enum Result {
        /** The item was used on the block this tick. */
        USED,
        /** The right item was selected but is not in hand yet; retry next tick. */
        WAITING,
        /** The item is not in the hotbar at all. */
        MISSING,
        /** The block is beyond interaction range; the server would drop the packet. */
        OUT_OF_RANGE,
        /** The click went out but the game refused it (wrong face, occupied block, ...). */
        FAILED
    }

    /**
     * Nearest block position around {@code center} that can take a block with solid
     * ground beneath it and is actually reachable from the player's eyes.
     */
    public static BlockPos findSpot(Minecraft mc, BlockPos center, double range) {
        if (mc.level == null || mc.player == null) return null;

        BlockPos best = null;
        double bestDist = Double.MAX_VALUE;
        for (int dx = -1; dx <= 1; dx++) {
            for (int dz = -1; dz <= 1; dz++) {
                for (int dy = 0; dy <= 1; dy++) {
                    BlockPos p = center.offset(dx, dy, dz);
                    if (!mc.level.getBlockState(p).canBeReplaced()) continue;
                    if (mc.level.getBlockState(p.below()).canBeReplaced()) continue;
                    if (!inRange(mc, p)) continue;
                    double dist = p.distSqr(center);
                    if (dist > range * range) continue;
                    if (dist < bestDist) { bestDist = dist; best = p; }
                }
            }
        }
        return best;
    }

    /** Server-side reach test, so a stage never advances on a packet the server drops. */
    private static boolean inRange(Minecraft mc, BlockPos pos) {
        // The server allows blockInteractionRange + 1.0; keep a small margin so a
        // ping spike between the check and the packet cannot reject the click.
        return mc.player != null && mc.player.isWithinBlockInteractionRange(pos, 0.5);
    }

    /**
     * Nearest cell whose block above is a legal crystal volume: replaceable, with
     * solid ground below, inside reach, and with no entity standing in the
     * two-block space the crystal needs. EndCrystalItem refuses to spawn when an
     * entity (the target) overlaps that volume, which is why placing the base in
     * the target's own feet block never produced a crystal.
     */
    public static BlockPos findCrystalBase(Minecraft mc, BlockPos center, double range) {
        if (mc.level == null || mc.player == null) return null;

        BlockPos best = null;
        double bestDist = Double.MAX_VALUE;
        for (int dx = -2; dx <= 2; dx++) {
            for (int dz = -2; dz <= 2; dz++) {
                for (int dy = -1; dy <= 1; dy++) {
                    BlockPos p = center.offset(dx, dy, dz);
                    if (!mc.level.getBlockState(p).canBeReplaced()) continue;
                    if (mc.level.getBlockState(p.below()).canBeReplaced()) continue;
                    if (!inRange(mc, p)) continue;
                    net.minecraft.world.phys.AABB volume = new net.minecraft.world.phys.AABB(
                            p.getX(), p.getY() + 1, p.getZ(),
                            p.getX() + 1, p.getY() + 3, p.getZ() + 1);
                    if (!mc.level.getEntities((Entity) null, volume).isEmpty()) continue;
                    double dist = p.distSqr(center);
                    if (dist > range * range) continue;
                    if (dist < bestDist) { bestDist = dist; best = p; }
                }
            }
        }
        return best;
    }

    /** Existing respawn anchor near {@code center}, or null. */
    public static BlockPos findAnchor(Minecraft mc, BlockPos center, int radius) {
        if (mc.level == null) return null;
        for (BlockPos pos : BlockPos.betweenClosed(
                center.offset(-radius, -1, -radius), center.offset(radius, 1, radius))) {
            if (mc.level.getBlockState(pos).getBlock()
                    instanceof net.minecraft.world.level.block.RespawnAnchorBlock) {
                return pos.immutable();
            }
        }
        return null;
    }

    /** Uses {@code itemName} on the top face of {@code support}. */
    public static Result useOn(Minecraft mc, String itemName, BlockPos support) {
        if (mc.player == null || mc.gameMode == null || support == null) return Result.MISSING;
        if (!inRange(mc, support)) return Result.OUT_OF_RANGE;

        if (!ModuleUtils.matches(mc.player.getMainHandItem(), itemName)) {
            int slot = ModuleUtils.findHotbarItem(mc, itemName);
            if (slot < 0) return Result.MISSING;
            ModuleUtils.select(mc, slot);
            return Result.WAITING;
        }

        Vec3 hit = Vec3.atCenterOf(support).add(0, 0.5, 0);
        InteractionResult result = mc.gameMode.useItemOn(mc.player, InteractionHand.MAIN_HAND,
                new BlockHitResult(hit, Direction.UP, support, false));
        mc.player.swing(InteractionHand.MAIN_HAND);
        return result != null && result.consumesAction() ? Result.USED : Result.FAILED;
    }

    /**
     * Uses the held item directly on an entity (flint on a TNT minecart, a bucket on
     * a cow, ...). Entity packets are resolved by id instead of by look ray, so no
     * rotation packet has to win a race with this one.
     */
    public static boolean useOnEntity(Minecraft mc, Entity entity) {
        if (mc.player == null || mc.gameMode == null || entity == null) return false;
        // Mirrors the server's own entity check (range + 3.0) with a small margin.
        if (!mc.player.isWithinEntityInteractionRange(entity, 2.5)) return false;

        Vec3 point = entity.position().add(0, entity.getBbHeight() * 0.5, 0);
        mc.gameMode.interact(mc.player, entity, new EntityHitResult(entity, point),
                InteractionHand.MAIN_HAND);
        mc.player.swing(InteractionHand.MAIN_HAND);
        return true;
    }
}
