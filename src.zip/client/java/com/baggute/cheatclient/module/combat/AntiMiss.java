package com.baggute.cheatclient.module.combat;

import com.baggute.cheatclient.UtilityClient;
import com.baggute.cheatclient.module.Category;
import com.baggute.cheatclient.module.Module;
import com.baggute.cheatclient.settings.BoolSetting;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;

/**
 * Rejects attack packets that cannot do anything: dead targets, yourself, and
 * (optionally) anything outside the range the server accepts.
 *
 * <p>This used to clear {@code keyAttack} on the client, which killed the input
 * until the next physical press and blinded every other click-gated module. The
 * filter now runs inside {@code MultiPlayerGameMode.attack} instead, so the input
 * state and the click itself are untouched.
 */
public final class AntiMiss extends Module {

    private final BoolSetting reachCheck =
            new BoolSetting("reachCheck", "Block attacks the server would reject", true);

    public AntiMiss() {
        super("AntiMiss", "Drops attacks that would hit nothing or nobody in reach.", Category.COMBAT);
        addSetting(reachCheck);
    }

    /** Called from the game mode mixin before an attack packet is built. */
    public static boolean shouldBlock(Player player, Entity target) {
        if (UtilityClient.moduleManager == null) return false;
        Module module = UtilityClient.moduleManager.getByName("AntiMiss");
        if (!(module instanceof AntiMiss anti) || !anti.isEnabled()) return false;

        if (target == null || target == player) return true;
        if (!(target instanceof LivingEntity living) || !living.isAlive()) return true;
        // The server validates interactions with entityInteractionRange + 3.0.
        return anti.reachCheck.get() && !player.isWithinEntityInteractionRange(target, 3.0);
    }
}
