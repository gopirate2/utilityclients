// language: Java, file: AutoJumpReset.java, target: Fabric 26.2
package com.baggute.cheatclient.module.combat;

import com.baggute.cheatclient.UtilityClient;
import com.baggute.cheatclient.module.Category;
import com.baggute.cheatclient.module.Module;
import com.baggute.cheatclient.settings.BoolSetting;
import com.baggute.cheatclient.settings.DoubleSetting;
import com.baggute.cheatclient.settings.IntSetting;
import net.minecraft.client.Minecraft;
import net.minecraft.world.phys.Vec3;

import java.util.Random;

/**
 * Jump reset: the tick you take a hit, jump. The jump converts the incoming
 * horizontal knockback into vertical momentum, so the combo shoves you up
 * instead of away and the hit sequence drops.
 *
 * Detection is client-side only: a decrease in health (live + absorption)
 * between ticks that is accompanied by a horizontal velocity spike. The jump
 * itself is a real key press on keyJump for one tick, so the server sees an
 * ordinary jump packet.
 */
public class AutoJumpReset extends Module {

    private final IntSetting jumpDelay;
    private final IntSetting holdTicks;
    private final BoolSetting onlyOnGround;
    private final BoolSetting requireKnockback;
    private final DoubleSetting minDamage;
    private final DoubleSetting chance;

    private final Random rng = new Random();

    private double lastHealth = -1.0;
    private int pendingJumpTicks = 0;
    private int jumpHeldTicks = 0;
    private boolean syntheticJump = false;

    public AutoJumpReset() {
        super("AutoJumpReset", "Jumps on the tick you get hit to cancel knockback.", Category.COMBAT);

        this.jumpDelay      = new IntSetting("jumpDelay", "Ticks to wait after the hit", 0, 0, 4);
        this.holdTicks      = new IntSetting("holdTicks", "Ticks to hold the jump key", 1, 1, 4);
        this.onlyOnGround   = new BoolSetting("onlyOnGround", "Only jump when standing on ground", true);
        this.requireKnockback = new BoolSetting("requireKnockback", "Only jump on real knockback", true);
        this.minDamage      = new DoubleSetting("minDamage", "Minimum damage taken to react", 0.0, 0.0, 20.0);
        this.chance         = new DoubleSetting("chance", "Chance to react (%)", 100.0, 0.0, 100.0);

        addSetting(jumpDelay);
        addSetting(holdTicks);
        addSetting(onlyOnGround);
        addSetting(requireKnockback);
        addSetting(minDamage);
        addSetting(chance);
    }

    @Override
    public void onTick() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null) {
            releaseJump(mc);
            lastHealth = -1.0;
            return;
        }

        // Release the synthetic press before sampling anything else, so a hold of
        // more than one tick never overlaps the next detection.
        if (syntheticJump && jumpHeldTicks-- <= 0) {
            releaseJump(mc);
        }

        double health = mc.player.getHealth() + mc.player.getAbsorptionAmount();
        if (lastHealth < 0.0) {
            lastHealth = health;
            return;
        }

        double lost = lastHealth - health;
        lastHealth = health;

        if (mc.gui.screen() != null || mc.isPaused()) return;
        if (lost <= 0.0 || lost < minDamage.get()) return;
        if (onlyOnGround.get() && !mc.player.onGround()) return;
        if (requireKnockback.get() && !hasKnockback(mc)) return;
        if (chance.get() < 100.0 && rng.nextDouble() * 100.0 >= chance.get()) return;
        if (pendingJumpTicks > 0 || syntheticJump) return;

        pendingJumpTicks = jumpDelay.get() + 1;
    }

    @Override
    public void onRenderFrame(float partialTick) {
        // Frame-paced so the delay does not stretch when client ticks stall.
        if (pendingJumpTicks <= 0) return;
        pendingJumpTicks--;
        if (pendingJumpTicks > 0) return;

        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;
        if (onlyOnGround.get() && !mc.player.onGround()) return;
        pressJump(mc);
    }

    private boolean hasKnockback(Minecraft mc) {
        Vec3 velocity = mc.player.getDeltaMovement();
        return Math.hypot(velocity.x, velocity.z) > 0.05;
    }

    private void pressJump(Minecraft mc) {
        // Never fight the human: if the key is already down, vanilla jumps anyway.
        if (mc.options.keyJump.isDown()) return;
        mc.options.keyJump.setDown(true);
        syntheticJump = true;
        jumpHeldTicks = holdTicks.get() - 1;
        UtilityClient.LOGGER.debug("[AutoJumpReset] jump reset fired");
    }

    private void releaseJump(Minecraft mc) {
        if (syntheticJump && mc.options != null) mc.options.keyJump.setDown(false);
        syntheticJump = false;
        jumpHeldTicks = 0;
    }

    @Override
    protected void onEnable() {
        lastHealth = -1.0;
        pendingJumpTicks = 0;
        jumpHeldTicks = 0;
        syntheticJump = false;
        UtilityClient.LOGGER.info("[AutoJumpReset] enabled");
    }

    @Override
    protected void onDisable() {
        releaseJump(Minecraft.getInstance());
        pendingJumpTicks = 0;
        lastHealth = -1.0;
        UtilityClient.LOGGER.info("[AutoJumpReset] disabled");
    }
}
