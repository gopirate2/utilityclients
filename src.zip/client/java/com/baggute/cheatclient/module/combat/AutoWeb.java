package com.baggute.cheatclient.module.combat;

import com.baggute.cheatclient.module.Category;
import com.baggute.cheatclient.module.Module;
import com.baggute.cheatclient.settings.BoolSetting;
import com.baggute.cheatclient.settings.KeybindSetting;
import com.baggute.cheatclient.util.ModuleUtils;
import net.minecraft.client.Minecraft;
import net.minecraft.world.phys.BlockHitResult;

/**
 * Places a cobweb where the crosshair is pointing.
 *
 * <p>The old version used {@code gameMode.useItem}, which only runs an item's own
 * right-click action; cobweb is a BlockItem with only {@code useOn}, so nothing
 * was ever placed. This version goes through {@link Placement} and the crosshair
 * block, and checks the result before restoring the hotbar.
 */
public final class AutoWeb extends Module {

    private final KeybindSetting web = new KeybindSetting("Web", "Place a web at the crosshair", -1, false);
    private final BoolSetting autoSwap = new BoolSetting("autoSwap", "Switch to cobweb", true);

    private boolean armed;
    private int stage;
    private int oldSlot = -1;

    public AutoWeb() {
        super("AutoWeb", "Swaps to a web and places it at the crosshair on command.", Category.COMBAT);
        addSetting(web);
        addSetting(autoSwap);
    }

    @Override
    public void onRawKey(int key, int action) {
        if (isEnabled() && action == 1 && key == web.getKey()) armed = true;
    }

    @Override
    public void onTick() {
        Minecraft mc = Minecraft.getInstance();
        if (!armed || mc.player == null || mc.gameMode == null || mc.level == null) return;

        if (stage == 0) {
            int slot = ModuleUtils.findHotbarItem(mc, "cobweb");
            if (slot < 0) { reset(); return; }
            oldSlot = mc.player.getInventory().getSelectedSlot();
            if (autoSwap.get()) ModuleUtils.select(mc, slot);
            stage = 1;
            return;
        }

        if (!ModuleUtils.matches(mc.player.getMainHandItem(), "cobweb")) { reset(); return; }
        if (!(mc.hitResult instanceof BlockHitResult hit)
                || hit.getType() != net.minecraft.world.phys.HitResult.Type.BLOCK) {
            reset();
            return;
        }

        Placement.Result result = Placement.useOn(mc, "cobweb", hit.getBlockPos());
        if (result == Placement.Result.WAITING) return;
        reset();
    }

    private void reset() {
        Minecraft mc = Minecraft.getInstance();
        if (oldSlot >= 0 && mc.player != null
                && mc.player.getInventory().getSelectedSlot() != oldSlot) {
            ModuleUtils.select(mc, oldSlot);
        }
        armed = false;
        stage = 0;
        oldSlot = -1;
    }
}
