// language: Java, file: AutoPearlCatch.java, target: Fabric 26.2
package com.baggute.cheatclient.module.combat;

import com.baggute.cheatclient.UtilityClient;
import com.baggute.cheatclient.module.Category;
import com.baggute.cheatclient.module.Module;
import com.baggute.cheatclient.settings.BoolSetting;
import com.baggute.cheatclient.settings.DoubleSetting;
import com.baggute.cheatclient.settings.IntSetting;
import com.baggute.cheatclient.settings.KeybindSetting;
import com.baggute.cheatclient.util.ModuleUtils;
import net.minecraft.client.Minecraft;
import net.minecraft.network.protocol.game.ServerboundMovePlayerPacket;
import net.minecraft.world.InteractionHand;

import java.util.Arrays;

/**
 * Pearl catch (IPC): throw an ender pearl, then throw a wind charge one tick
 * later. The charge bursts while the pearl is still travelling, so the pearl
 * lands on top of the boost and the momentum carries instead of dropping.
 *
 * One action per tick, fixed phase order, so the slot packet always reaches the
 * server before the matching use packet.
 */
public class AutoPearlCatch extends Module {

    private final KeybindSetting activate;
    private final BoolSetting autoTrigger;
    private final BoolSetting requireWindCharge;
    private final IntSetting pearlDelay;
    private final IntSetting restoreDelay;
    private final BoolSetting aimDown;
    private final DoubleSetting aimPitch;

    private final int[] lastPearlCounts = new int[9];
    private boolean countsPrimed = false;

    private Phase phase = Phase.IDLE;
    private int timer = 0;
    private int phaseTicks = 0;
    private int previousSlot = -1;
    private boolean rotationDirty = false;
    private float savedYaw;
    private float savedPitch;

    private enum Phase { IDLE, SWAP_PEARL, THROW_PEARL, WAIT_CHARGE, SWAP_CHARGE, THROW_CHARGE, RESTORE }

    /** HELD means the item is in hand right now and can be used this tick. */
    private enum Ready { HELD, SWAPPING, MISSING }

    public AutoPearlCatch() {
        super("AutoPearlCatch", "Throws a pearl then a wind charge to catch it mid-flight.", Category.COMBAT);

        this.activate          = new KeybindSetting("PearlCatch", "Throw the pearl-catch sequence", -1, false);
        this.autoTrigger       = new BoolSetting("autoTrigger", "Follow your own pearl throws", true);
        this.requireWindCharge = new BoolSetting("requireWindCharge", "Only run when a wind charge is in the hotbar", true);
        this.pearlDelay        = new IntSetting("pearlDelay", "Ticks between pearl and charge", 1, 0, 10);
        this.restoreDelay      = new IntSetting("restoreDelay", "Ticks before restoring the slot", 4, 1, 20);
        this.aimDown           = new BoolSetting("aimDown", "Snap your pitch for the charge", false);
        this.aimPitch          = new DoubleSetting("aimPitch", "Snap pitch for the charge (deg)", 65.0, 10.0, 90.0);

        addSetting(activate);
        addSetting(autoTrigger);
        addSetting(requireWindCharge);
        addSetting(pearlDelay);
        addSetting(restoreDelay);
        addSetting(aimDown);
        addSetting(aimPitch);
    }

    @Override
    public void onRawKey(int keyCode, int action) {
        if (action != 1 || !isEnabled()) return;
        if (activate.getKey() == -1 || keyCode != activate.getKey()) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null) return;
        if (mc.gui.screen() != null || mc.isPaused()) return;
        begin(mc);
    }

    @Override
    public void onTick() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null || mc.gameMode == null) return;

        if (rotationDirty) {
            rotationDirty = false;
            mc.player.setYRot(savedYaw);
            mc.player.setXRot(savedPitch);
            sendRotation(mc);
        }

        pollPearlCounts(mc);

        if (phase == Phase.IDLE) return;
        if (++phaseTicks > 40) {
            // Anything stuck for two seconds is a desync or an empty hotbar.
            restoreSlot(mc);
            phase = Phase.IDLE;
            return;
        }

        switch (phase) {
            case SWAP_PEARL -> {
                Ready ready = hold(mc, "ender_pearl");
                if (ready == Ready.MISSING) { abort(mc); return; }
                if (ready == Ready.SWAPPING) return;   // retry next tick, now in hand
                setPhase(Phase.THROW_PEARL);
            }
            case THROW_PEARL -> {
                mc.gameMode.useItem(mc.player, InteractionHand.MAIN_HAND);
                mc.player.swing(InteractionHand.MAIN_HAND);
                timer = pearlDelay.get();
                setPhase(Phase.WAIT_CHARGE);
            }
            case WAIT_CHARGE -> {
                if (timer > 0) { timer--; return; }
                Ready ready = hold(mc, "wind_charge");
                if (ready == Ready.MISSING) { abort(mc); return; }
                if (ready == Ready.SWAPPING) return;
                setPhase(Phase.THROW_CHARGE);
            }
            case THROW_CHARGE -> {
                if (aimDown.get()) {
                    savedYaw = mc.player.getYRot();
                    savedPitch = mc.player.getXRot();
                    mc.player.setXRot((float) aimPitch.get());
                    sendRotation(mc);
                    rotationDirty = true;
                }
                mc.gameMode.useItem(mc.player, InteractionHand.MAIN_HAND);
                mc.player.swing(InteractionHand.MAIN_HAND);
                timer = restoreDelay.get();
                setPhase(Phase.RESTORE);
            }
            case RESTORE -> {
                if (timer > 0) { timer--; return; }
                restoreSlot(mc);
                setPhase(Phase.IDLE);
            }
            default -> setPhase(Phase.IDLE);
        }
    }

    private void begin(Minecraft mc) {
        if (phase != Phase.IDLE) return;
        if (ModuleUtils.findHotbarItem(mc, "ender_pearl") < 0) return;
        if (requireWindCharge.get() && ModuleUtils.findHotbarItem(mc, "wind_charge") < 0) return;
        if (previousSlot < 0) previousSlot = mc.player.getInventory().getSelectedSlot();
        setPhase(Phase.SWAP_PEARL);
    }

    /**
     * Auto-trigger entry: the player already threw the pearl, so skip straight to
     * the wind charge instead of throwing a second pearl.
     */
    private void beginFromThrow(Minecraft mc) {
        if (phase != Phase.IDLE) return;
        if (ModuleUtils.findHotbarItem(mc, "wind_charge") < 0) return;
        if (previousSlot < 0) previousSlot = mc.player.getInventory().getSelectedSlot();
        timer = pearlDelay.get();
        setPhase(Phase.WAIT_CHARGE);
    }

    /**
     * Makes sure `itemName` is in the main hand. SWAPPING means the slot packet went
     * out this tick and the use has to wait for the next one — treating that as a
     * failure is what used to abort the sequence after the pearl.
     */
    private Ready hold(Minecraft mc, String itemName) {
        if (ModuleUtils.matches(mc.player.getMainHandItem(), itemName)) return Ready.HELD;
        int slot = ModuleUtils.findHotbarItem(mc, itemName);
        if (slot < 0) return Ready.MISSING;
        ModuleUtils.select(mc, slot);
        return Ready.SWAPPING;
    }

    private void sendRotation(Minecraft mc) {
        if (mc.player.connection == null) return;
        mc.player.connection.send(new ServerboundMovePlayerPacket.Rot(
                mc.player.getYRot(), mc.player.getXRot(),
                mc.player.onGround(), mc.player.horizontalCollision));
    }

    /**
     * Auto trigger. A hotbar pearl stack losing exactly one item between ticks is
     * a pearl leaving the hand, which is the throw we want to follow.
     */
    private void pollPearlCounts(Minecraft mc) {
        if (!autoTrigger.get()) { countsPrimed = false; return; }

        for (int slot = 0; slot < 9; slot++) {
            int count = ModuleUtils.matches(mc.player.getInventory().getItem(slot), "ender_pearl")
                    ? mc.player.getInventory().getItem(slot).getCount() : 0;
            boolean thrown = countsPrimed && count == lastPearlCounts[slot] - 1;
            lastPearlCounts[slot] = count;
            if (thrown && phase == Phase.IDLE) {
                countsPrimed = true;
                // Follow the player's own throw: only the charge has to be
                // thrown, not a second pearl (the pearl was already in flight).
                beginFromThrow(mc);
                return;
            }
        }
        countsPrimed = true;
    }

    private void abort(Minecraft mc) {
        restoreSlot(mc);
        setPhase(Phase.IDLE);
    }

    private void restoreSlot(Minecraft mc) {
        if (previousSlot >= 0 && mc.player != null
                && mc.player.getInventory().getSelectedSlot() != previousSlot) {
            ModuleUtils.select(mc, previousSlot);
        }
        previousSlot = -1;
    }

    private void setPhase(Phase next) {
        phase = next;
        phaseTicks = 0;
        com.baggute.cheatclient.module.misc.Debug.stage("AutoPearlCatch", next.name());
    }

    @Override
    protected void onEnable() {
        phase = Phase.IDLE;
        timer = 0;
        phaseTicks = 0;
        previousSlot = -1;
        rotationDirty = false;
        Arrays.fill(lastPearlCounts, 0);
        countsPrimed = false;
        UtilityClient.LOGGER.info("[AutoPearlCatch] enabled");
    }

    @Override
    protected void onDisable() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player != null) {
            if (rotationDirty) {
                mc.player.setYRot(savedYaw);
                mc.player.setXRot(savedPitch);
            }
            restoreSlot(mc);
        }
        rotationDirty = false;
        phase = Phase.IDLE;
        timer = 0;
        phaseTicks = 0;
        Arrays.fill(lastPearlCounts, 0);
        countsPrimed = false;
    }
}
