// language: Java, file: AimPipeline.java, target: Fabric 26.2
package com.baggute.cheatclient.module.combat;

import net.minecraft.client.Minecraft;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.Set;

/**
 * One aiming path for every combat module: pick a target, then rotate toward a
 * point with the same speed/smoothing/quantisation rules everywhere.
 *
 * Rotation is quantised to the mouse GCD so the resulting deltas look like real
 * mouse movement rather than a straight clamp.
 */
public final class AimPipeline {

    private AimPipeline() {}

    /** Nearest visible living entity inside range and FOV, filtered by registry id. */
    public static Entity pickTarget(Minecraft mc, double range, double fovDegrees,
                                    Set<String> filter, boolean requireLineOfSight) {
        if (mc.player == null || mc.level == null) return null;
        double rangeSq = range * range;
        double fovCos = Math.cos(Math.toRadians(fovDegrees / 2.0));
        Vec3 eye = mc.player.getEyePosition();
        Vec3 look = mc.player.getViewVector(1.0f);

        Entity best = null;
        double bestScore = Double.MAX_VALUE;

        for (Entity entity : mc.level.entitiesForRendering()) {
            if (entity == mc.player || !entity.isAlive()) continue;
            if (!(entity instanceof LivingEntity)) continue;
            if (entity.distanceToSqr(eye) > rangeSq) continue;
            if (requireLineOfSight && !mc.player.hasLineOfSight(entity)) continue;

            if (filter != null && !filter.isEmpty()) {
                Identifier id = BuiltInRegistries.ENTITY_TYPE.getKey(entity.getType());
                if (id == null || !filter.contains(id.toString())) continue;
            }

            Vec3 targetPos = entity.position().add(0, entity.getBbHeight() * 0.5, 0);
            Vec3 toTarget = targetPos.subtract(eye).normalize();
            double dot = toTarget.dot(look);
            if (dot < fovCos) continue;

            double score = entity.distanceToSqr(eye) - dot * 100.0;
            if (score < bestScore) {
                bestScore = score;
                best = entity;
            }
        }
        return best;
    }

    /** Closest point on the target box, optionally extrapolated forward. */
    public static Vec3 closestPoint(Entity entity, Vec3 from, int predictTicks) {
        AABB box = entity.getBoundingBox();
        if (predictTicks > 0) {
            Vec3 velocity = entity.getDeltaMovement();
            box = box.move(velocity.x * predictTicks, velocity.y * predictTicks, velocity.z * predictTicks);
        }
        double cx = Mth.clamp(from.x, box.minX, box.maxX);
        double cy = Mth.clamp(from.y, box.minY, box.maxY);
        double cz = Mth.clamp(from.z, box.minZ, box.maxZ);
        return new Vec3(cx, cy, cz);
    }

    /** Steers the player rotation toward a world point. */
    public static void rotateTo(Minecraft mc, Vec3 worldPoint, double speed, double smoothness,
                                boolean vertical, double stopAngle) {
        if (mc.player == null) return;
        Vec3 eye = mc.player.getEyePosition(1.0f);
        Vec3 delta = worldPoint.subtract(eye);
        double horizontal = Math.sqrt(delta.x * delta.x + delta.z * delta.z);

        float targetYaw = (float) (Math.toDegrees(Math.atan2(delta.z, delta.x)) - 90.0);
        float targetPitch = (float) -Math.toDegrees(Math.atan2(delta.y, horizontal));

        float currentYaw = mc.player.getYRot();
        float currentPitch = mc.player.getXRot();

        float yawDelta = Mth.wrapDegrees(targetYaw - currentYaw);
        float pitchDelta = vertical ? targetPitch - currentPitch : 0f;

        float stop = (float) stopAngle;
        if (Math.abs(yawDelta) < stop) yawDelta = 0f;
        if (Math.abs(pitchDelta) < stop) pitchDelta = 0f;

        float t = (float) (speed / Math.max(0.01, smoothness));
        t = Mth.clamp(t, 0.01f, 1.0f);

        float gcd = mouseGcd(mc);
        float newYaw = currentYaw + quantize(yawDelta * t, gcd);
        float newPitch = Mth.clamp(currentPitch + quantize(pitchDelta * t, gcd), -90.0f, 90.0f);

        apply(mc, newYaw, newPitch);
    }

    /** Absolute snap, used by modules that need the hit to land this tick. */
    public static void snapTo(Minecraft mc, Vec3 worldPoint) {
        if (mc.player == null) return;
        Vec3 eye = mc.player.getEyePosition(1.0f);
        Vec3 delta = worldPoint.subtract(eye);
        double horizontal = Math.sqrt(delta.x * delta.x + delta.z * delta.z);
        float yaw = (float) (Math.toDegrees(Math.atan2(delta.z, delta.x)) - 90.0);
        float pitch = (float) -Math.toDegrees(Math.atan2(delta.y, horizontal));
        apply(mc, yaw, Mth.clamp(pitch, -90.0f, 90.0f));
    }

    public static void apply(Minecraft mc, float yaw, float pitch) {
        if (mc.player == null) return;
        mc.player.setYRot(yaw);
        mc.player.setXRot(pitch);
        mc.player.yRotO = yaw;
        mc.player.xRotO = pitch;
    }

    /** Vanilla mouse step size for the current sensitivity. */
    public static float mouseGcd(Minecraft mc) {
        double sensitivity = mc.options.sensitivity().get();
        double f = sensitivity * 0.6 + 0.2;
        double gcd = f * f * f * 1.2;
        return (float) (gcd * 0.15);
    }

    public static float quantize(float delta, float step) {
        if (step <= 0) return delta;
        return Math.round(delta / step) * step;
    }

    /**
     * A critical hit needs a fall: airborne, descending, and already carrying fall
     * distance. Every module that wants a crit asks here instead of rolling its own.
     */
    public static boolean isFallingForCrit(Minecraft mc) {
        if (mc.player == null) return false;
        if (mc.player.onGround()) return false;
        if (mc.player.isInWater()) return false;
        if (mc.player.onClimbable()) return false;
        if (mc.player.isPassenger()) return false;
        if (mc.player.getDeltaMovement().y >= 0) return false;
        return mc.player.fallDistance > 0.0f;
    }

    /** True when the entity is in front of the player's eyes within the angle. */
    public static boolean inFov(Minecraft mc, Entity entity, double fovDegrees) {
        if (mc.player == null) return false;
        Vec3 eye = mc.player.getEyePosition();
        Vec3 to = entity.position().add(0, entity.getBbHeight() * 0.5, 0).subtract(eye).normalize();
        return to.dot(mc.player.getViewVector(1.0f)) >= Math.cos(Math.toRadians(fovDegrees / 2.0));
    }
}
