package com.baggute.cheatclient.module.combat;

import com.baggute.cheatclient.module.Category;
import com.baggute.cheatclient.module.Module;
import com.baggute.cheatclient.settings.BoolSetting;
import com.baggute.cheatclient.settings.IntSetting;
import com.baggute.cheatclient.util.ModuleUtils;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;

/**
 * Bow shot, then a rail and a minecart at the crosshair.
 *
 * <p>Blocks have to go through {@link Placement}: {@code gameMode.useItem} only
 * runs an item's own right-click action and a BlockItem has none, so the old
 * version switched items and placed nothing.
 */
public final class AutoInstacart extends Module {

    private final BoolSetting autoSwap = new BoolSetting("autoSwap", "Switch to rail and cart", true);
    private final IntSetting railSlot = new IntSetting("railSlot", "Rail hotbar slot", 1, 1, 9);
    private final IntSetting cartSlot = new IntSetting("cartSlot", "Minecart hotbar slot", 2, 1, 9);

    private boolean drawing;
    private int stage;
    private int oldSlot = -1;
    private BlockPos railPos;

    public AutoInstacart() {
        super("AutoInstacart", "Bow shot then delayed rail and minecart placement.", Category.COMBAT);
        addSetting(autoSwap);
        addSetting(railSlot);
        addSetting(cartSlot);
    }

    @Override
    public void onTick() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.gameMode == null || mc.level == null) return;

        boolean use = mc.options.keyUse.isDown();

        if (stage == 0) {
            if (use && ModuleUtils.matches(mc.player.getMainHandItem(), "bow")) {
                drawing = true;
            } else if (!use && drawing) {
                drawing = false;
                oldSlot = mc.player.getInventory().getSelectedSlot();
                stage = 1;
            }
            return;
        }

        if (stage == 1) {
            if (!select(mc, railSlot.get() - 1, "rail")) { abort(mc); return; }
            stage = 2;
            return;
        }

        if (stage == 2) {
            if (!ModuleUtils.matches(mc.player.getMainHandItem(), "rail")) { abort(mc); return; }
            BlockPos target = crosshairBlock(mc);
            if (target == null) { abort(mc); return; }
            Placement.Result result = Placement.useOn(mc, "rail", target.below());
            if (result == Placement.Result.WAITING) return;
            if (result != Placement.Result.USED) { abort(mc); return; }
            railPos = target;
            stage = 3;
            return;
        }

        if (stage == 3) {
            if (!select(mc, cartSlot.get() - 1, "minecart")) { abort(mc); return; }
            stage = 4;
            return;
        }

        if (stage == 4) {
            if (!ModuleUtils.matches(mc.player.getMainHandItem(), "minecart")) { abort(mc); return; }
            if (railPos == null) { abort(mc); return; }
            Placement.Result result = Placement.useOn(mc, "tnt_minecart", railPos);
            if (result == Placement.Result.WAITING) return;
            reset(mc);
        }
    }

    private BlockPos crosshairBlock(Minecraft mc) {
        if (mc.hitResult instanceof BlockHitResult hit && hit.getType() == HitResult.Type.BLOCK) {
            return hit.getBlockPos();
        }
        return null;
    }

    private boolean select(Minecraft mc, int slot, String name) {
        if (slot < 0 || slot >= 9) return false;
        if (!ModuleUtils.matches(mc.player.getInventory().getItem(slot), name)) return false;
        if (autoSwap.get()) ModuleUtils.select(mc, slot);
        return ModuleUtils.matches(mc.player.getMainHandItem(), name);
    }

    private void reset(Minecraft mc) {
        if (oldSlot >= 0 && mc.player != null
                && mc.player.getInventory().getSelectedSlot() != oldSlot) {
            ModuleUtils.select(mc, oldSlot);
        }
        drawing = false;
        stage = 0;
        oldSlot = -1;
        railPos = null;
    }

    private void abort(Minecraft mc) {
        reset(mc);
    }
}
