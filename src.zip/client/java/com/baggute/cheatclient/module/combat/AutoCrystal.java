// language: Java, file: AutoCrystal.java, target: Fabric 26.2
package com.baggute.cheatclient.module.combat;

import com.baggute.cheatclient.module.Category;
import com.baggute.cheatclient.module.Module;
import com.baggute.cheatclient.settings.BoolSetting;
import com.baggute.cheatclient.settings.DoubleSetting;
import com.baggute.cheatclient.settings.IntSetting;
import com.baggute.cheatclient.util.ModuleUtils;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;

/**
 * Placed-base crystal cycle: put obsidian under the target, spawn a crystal on it,
 * then detonate it by attacking the crystal.
 *
 * One action per tick so the slot packet always lands before the use packet.
 */
public class AutoCrystal extends Module {

    private final DoubleSetting range;
    private final IntSetting placeDelay;
    private final BoolSetting detonate;
    private final BoolSetting onlyWhileClicking;

    private Stage stage = Stage.IDLE;
    private int cooldown = 0;
    private int stageTicks = 0;
    private BlockPos basePos = null;

    private enum Stage { IDLE, BASE, CRYSTAL, BOOM }

    public AutoCrystal() {
        super("AutoCrystal", "Places obsidian, spawns a crystal and detonates it.", Category.COMBAT);

        this.range = new DoubleSetting("range", "Target range", 4.5, 2.0, 6.0);
        this.placeDelay = new IntSetting("placeDelay", "Ticks between cycles", 4, 1, 20);
        this.detonate = new BoolSetting("detonate", "Detonate the crystal", true);
        this.onlyWhileClicking = new BoolSetting("onlyWhileClicking", "Only run while left-click held", false);

        addSetting(range);
        addSetting(placeDelay);
        addSetting(detonate);
        addSetting(onlyWhileClicking);
    }

    @Override
    public void onTick() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null || mc.gameMode == null) return;
        if (mc.gui.screen() != null || mc.isPaused()) return;
        if (cooldown > 0) cooldown--;
        if (stage == Stage.IDLE) return;
        if (++stageTicks > 30) { reset(); return; }

        switch (stage) {
            case BASE -> {
                if (basePos == null) { reset(); return; }
                Placement.Result result = Placement.useOn(mc, "obsidian", basePos.below());
                if (result == Placement.Result.WAITING) return; // swap first, place next tick
                if (result != Placement.Result.USED) { reset(); return; }
                stage = Stage.CRYSTAL;
                com.baggute.cheatclient.module.misc.Debug.stage("AutoCrystal", stage.name());
                stageTicks = 0;
            }
            case CRYSTAL -> {
                if (basePos == null) { reset(); return; }
                Placement.Result result = Placement.useOn(mc, "end_crystal", basePos);
                if (result == Placement.Result.WAITING) return;
                if (result != Placement.Result.USED) { reset(); return; }
                stage = detonate.get() ? Stage.BOOM : Stage.IDLE;
                stageTicks = 0;
                cooldown = placeDelay.get();
            }
            case BOOM -> {
                // The crystal entity only exists after the server's add-entity
                // packet, so wait for it instead of aborting on the next tick.
                Entity crystal = findCrystal(mc);
                if (crystal == null) return;
                // Attacks are validated at entity reach; a crystal spawned further
                // away can only be hit by walking up to it.
                if (!mc.player.isWithinEntityInteractionRange(crystal, 0.0)) { reset(); return; }
                mc.gameMode.attack(mc.player, crystal);
                mc.player.swing(InteractionHand.MAIN_HAND);
                reset();
                cooldown = placeDelay.get();
            }
            default -> { }
        }
    }

    /** Runs from IDLE: picks the base spot and starts the cycle. */
    private void begin(Minecraft mc) {
        if (cooldown > 0 || stage != Stage.IDLE) return;
        if (onlyWhileClicking.get() && !mc.options.keyAttack.isDown()) return;

        // The cycle ends by attacking the crystal, so only start inside entity reach.
        double reach = Math.min(range.get(), mc.player.entityInteractionRange() + 2.5);
        Player target = ModuleUtils.nearestPlayer(mc, reach);
        if (target == null) return;

        // The block the target stands in is not usable: the crystal volume above the
        // obsidian would contain the target and EndCrystalItem refuses to spawn.
        BlockPos base = Placement.findCrystalBase(mc, target.blockPosition(), 2.0);
        if (base == null) return;

        basePos = base;
        stage = Stage.BASE;
        stageTicks = 0;
    }

    private Entity findCrystal(Minecraft mc) {
        if (basePos == null) return null;
        Vec3 center = Vec3.atCenterOf(basePos).add(0, 0.5, 0);
        for (Entity entity : mc.level.entitiesForRendering()) {
            if (!entity.getType().getDescriptionId().toLowerCase().contains("end_crystal")) continue;
            if (entity.position().distanceToSqr(center) > 9.0) continue;
            return entity;
        }
        return null;
    }

    @Override
    public void onRenderFrame(float partialTick) {
        begin(Minecraft.getInstance());
    }

    private void reset() {
        stage = Stage.IDLE;
        com.baggute.cheatclient.module.misc.Debug.stage("AutoCrystal", stage.name());
        stageTicks = 0;
        basePos = null;
    }

    @Override
    protected void onEnable() { reset(); cooldown = 0; }

    @Override
    protected void onDisable() { reset(); cooldown = 0; }
}
