// language: Java, file: Triggerbot.java, target: Fabric 26.2
package com.baggute.cheatclient.module.combat;

import com.baggute.cheatclient.UtilityClient;
import com.baggute.cheatclient.module.Category;
import com.baggute.cheatclient.module.Module;
import com.baggute.cheatclient.settings.BoolSetting;
import com.baggute.cheatclient.settings.DoubleSetting;
import com.baggute.cheatclient.settings.IntSetting;
import com.baggute.cheatclient.settings.StringSetting;
import net.minecraft.client.Minecraft;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.protocol.game.ServerboundPlayerCommandPacket;
import net.minecraft.resources.Identifier;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

import java.util.HashSet;
import java.util.Random;
import java.util.Set;

public class Triggerbot extends Module {

    private final StringSetting entityFilter;
    private final DoubleSetting missChance;
    private final DoubleSetting rangeMin;
    private final DoubleSetting rangeMax;
    private final IntSetting cpsCap;
    private final IntSetting tickDelayMin;
    private final IntSetting tickDelayMax;
    private final IntSetting jitterMs;
    private final DoubleSetting attackCooldown;
    private final BoolSetting onlyWeapon;
    private final BoolSetting swing;
    private final BoolSetting ignoreInvisible;
    private final BoolSetting wtap;
    private final BoolSetting smartCrits;

    private final Random rng = new Random();
    private int ticksSinceLastAttack = 0;
    private int currentDelay = 2;
    private long lastAttackMs = 0L;
    private long lastSprintPacketMs = 0L;

    private double lastYVel = 0.0;
    private int knockbackTicks = 0;

    public Triggerbot() {
        super("Triggerbot", "Attacks the entity under your crosshair.", Category.COMBAT);

        this.entityFilter   = new StringSetting("entityFilter", "Enabled entity IDs",
                "minecraft:player,minecraft:zombie,minecraft:skeleton,minecraft:creeper,minecraft:enderman");
        this.missChance     = new DoubleSetting("missChance", "Chance to swing air instead of hit (%)", 0.0, 0.0, 50.0);
        this.rangeMin       = new DoubleSetting("rangeMin", "Minimum attack range", 0.0, 0.0, 3.0);
        this.rangeMax       = new DoubleSetting("rangeMax", "Maximum attack range", 3.0, 0.0, 3.0);
        this.cpsCap         = new IntSetting("cpsCap", "Max attacks per second (0 = uncapped)", 8, 0, 20);
        this.tickDelayMin   = new IntSetting("tickDelayMin", "Min ticks between attacks", 1, 0, 20);
        this.tickDelayMax   = new IntSetting("tickDelayMax", "Max ticks between attacks", 4, 0, 20);
        this.jitterMs       = new IntSetting("jitterMs", "Random timing jitter (+/- ms)", 30, 0, 200);
        this.attackCooldown = new DoubleSetting("attackCooldown", "Min attack cooldown (0-1)", 1.0, 0.0, 1.0);
        this.onlyWeapon     = new BoolSetting("onlyWeapon", "Only attack with sword or axe", true);
        this.swing          = new BoolSetting("swing", "Swing hand on attack", true);
        this.ignoreInvisible= new BoolSetting("ignoreInvisible", "Skip invisible entities", true);
        this.wtap           = new BoolSetting("wtap", "Auto-sprint before each hit", false);
        this.smartCrits     = new BoolSetting("smartCrits", "After knockback, wait until falling to crit", false);

        addSetting(entityFilter);
        addSetting(missChance);
        addSetting(rangeMin);
        addSetting(rangeMax);
        addSetting(cpsCap);
        addSetting(tickDelayMin);
        addSetting(tickDelayMax);
        addSetting(jitterMs);
        addSetting(attackCooldown);
        addSetting(onlyWeapon);
        addSetting(swing);
        addSetting(ignoreInvisible);
        addSetting(wtap);
        addSetting(smartCrits);
    }

    public Set<String> getEntityFilter() {
        Set<String> out = new HashSet<>();
        for (String part : entityFilter.get().split(",")) {
            String t = part.trim();
            if (!t.isEmpty()) out.add(t);
        }
        return out;
    }

    public StringSetting getEntityFilterSetting() { return entityFilter; }

    @Override
    public void onTick() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null || mc.gameMode == null) return;

        // ---- knockback tracking ----
        double yVel = mc.player.getDeltaMovement().y;
        if (yVel > 0.35 && lastYVel <= 0.35) {
            knockbackTicks = 40;
        }
        if (knockbackTicks > 0) knockbackTicks--;
        lastYVel = yVel;

        // ---- timing gates ----
        if (ticksSinceLastAttack < currentDelay) {
            ticksSinceLastAttack++;
            return;
        }

        if (cpsCap.get() > 0) {
            long now = System.currentTimeMillis();
            long minInterval = 1000L / cpsCap.get();
            long jitter = rng.nextInt(jitterMs.get() * 2 + 1) - jitterMs.get();
            if (now - lastAttackMs < minInterval + jitter) return;
        }

        HitResult hit = mc.hitResult;
        if (!(hit instanceof EntityHitResult ehr)) return;

        Entity target = ehr.getEntity();
        if (target == null || target == mc.player || !target.isAlive()) return;

        Identifier id = BuiltInRegistries.ENTITY_TYPE.getKey(target.getType());
        if (id == null || !getEntityFilter().contains(id.toString())) return;

        if (ignoreInvisible.get() && target.isInvisible()) return;

        // ---- range gate (closest distance from eye to hitbox) ----
        double distance = eyeToHitboxDistance(mc.player.getEyePosition(), target.getBoundingBox());
        double rMin = rangeMin.get();
        double rMax = rangeMax.get();
        if (rMax <= rMin) rMax = rMin + 0.01; // enforce max > min
        if (distance < rMin || distance > rMax) return;

        if (attackCooldown.get() > 0.0
                && mc.player.getAttackStrengthScale(0.0F) < attackCooldown.get()) return;

        if (onlyWeapon.get()) {
            String item = mc.player.getMainHandItem().getItem().toString();
            // "pickaxe" also contains "axe", so match the registry suffixes.
            if (!item.contains("_sword") && !item.contains("_axe")) return;
        }

        // ---- smart crits gate ----
        if (smartCrits.get() && knockbackTicks > 0 && !isFallingForCrit(mc)) {
            return;
        }

        // ---- miss chance: swing animation, no attack packet ----
        if (missChance.get() > 0.0 && rng.nextDouble() * 100.0 < missChance.get()) {
            if (swing.get()) mc.player.swing(InteractionHand.MAIN_HAND);
            // no gameMode.attack call — server sees the swing, no hit registers
            ticksSinceLastAttack = 0;
            currentDelay = randomDelay();
            lastAttackMs = System.currentTimeMillis();
            return;
        }

        doAttack(mc, target);
    }

    private void doAttack(Minecraft mc, Entity target) {
        if (mc.player == null) return;

        if (wtap.get() && mc.player.connection != null) {
            long now = System.currentTimeMillis();
            if (now - lastSprintPacketMs > 100) {
                mc.player.setSprinting(true);
                mc.player.connection.send(new ServerboundPlayerCommandPacket(
                        mc.player, ServerboundPlayerCommandPacket.Action.START_SPRINTING));
                lastSprintPacketMs = now;
            }
        }

        mc.gameMode.attack(mc.player, target);
        if (swing.get()) mc.player.swing(InteractionHand.MAIN_HAND);

        ticksSinceLastAttack = 0;
        currentDelay = randomDelay();
        lastAttackMs = System.currentTimeMillis();
    }

    /** Euclidean distance from a point to the closest point on an AABB. */
    private static double eyeToHitboxDistance(Vec3 eye, AABB box) {
        double dx = Math.max(Math.max(box.minX - eye.x, 0), eye.x - box.maxX);
        double dy = Math.max(Math.max(box.minY - eye.y, 0), eye.y - box.maxY);
        double dz = Math.max(Math.max(box.minZ - eye.z, 0), eye.z - box.maxZ);
        return Math.sqrt(dx * dx + dy * dy + dz * dz);
    }

    private boolean isFallingForCrit(Minecraft mc) {
        return AimPipeline.isFallingForCrit(mc);
    }

    private int randomDelay() {
        int lo = Math.min(tickDelayMin.get(), tickDelayMax.get());
        int hi = Math.max(tickDelayMin.get(), tickDelayMax.get());
        if (lo == hi) return lo;
        return lo + rng.nextInt(hi - lo + 1);
    }

    @Override
    protected void onEnable() {
        ticksSinceLastAttack = 0;
        currentDelay = randomDelay();
        lastAttackMs = 0L;
        lastSprintPacketMs = 0L;
        knockbackTicks = 0;
        lastYVel = 0.0;
        UtilityClient.LOGGER.info("[Triggerbot] enabled");
    }

    @Override
    protected void onDisable() {
        UtilityClient.LOGGER.info("[Triggerbot] disabled");
    }
}