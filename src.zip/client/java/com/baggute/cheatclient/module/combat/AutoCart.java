// language: Java, file: AutoCart.java, target: Fabric 26.2
package com.baggute.cheatclient.module.combat;

import com.baggute.cheatclient.module.Category;
import com.baggute.cheatclient.module.Module;
import com.baggute.cheatclient.settings.BoolSetting;
import com.baggute.cheatclient.settings.DoubleSetting;
import com.baggute.cheatclient.settings.IntSetting;
import com.baggute.cheatclient.util.ModuleUtils;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;

/**
 * Fast cart: rails under the target, a TNT minecart on the rails, then ignition
 * with flint and steel on the minecart.
 */
public class AutoCart extends Module {

    private final DoubleSetting range;
    private final IntSetting placeDelay;
    private final BoolSetting ignite;

    private Stage stage = Stage.IDLE;
    private int cooldown = 0;
    private int stageTicks = 0;
    private int igniteCharge = 0;
    private BlockPos railPos = null;

    private enum Stage { IDLE, RAIL, CART, IGNITE }

    public AutoCart() {
        super("AutoCart", "Places a rail and TNT minecart, then ignites it.", Category.COMBAT);

        this.range = new DoubleSetting("range", "Target range", 5.0, 2.0, 6.0);
        this.placeDelay = new IntSetting("placeDelay", "Ticks between cycles", 10, 2, 40);
        this.ignite = new BoolSetting("ignite", "Light the minecart", true);

        addSetting(range);
        addSetting(placeDelay);
        addSetting(ignite);
    }

    @Override
    public void onTick() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null || mc.gameMode == null) return;
        if (mc.gui.screen() != null || mc.isPaused()) return;
        if (cooldown > 0) cooldown--;
        if (stage == Stage.IDLE) return;
        if (++stageTicks > 80) { reset(); return; }

        switch (stage) {
            case RAIL -> {
                if (railPos == null) { reset(); return; }
                Placement.Result result = Placement.useOn(mc, "rail", railPos.below());
                if (result == Placement.Result.WAITING) return;
                if (result != Placement.Result.USED) { reset(); return; }
                stage = Stage.CART;
                com.baggute.cheatclient.module.misc.Debug.stage("AutoCart", stage.name());
                stageTicks = 0;
            }
            case CART -> {
                if (railPos == null) { reset(); return; }
                // The cart has to be used *on the rail block itself*: MinecartItem
                // only spawns against BlockTags.RAILS, and useOn clicks the top face
                // of the position it is given.
                Placement.Result result = Placement.useOn(mc, "tnt_minecart", railPos);
                if (result == Placement.Result.WAITING) return;
                if (result != Placement.Result.USED) { reset(); return; }
                stage = ignite.get() ? Stage.IGNITE : Stage.IDLE;
                stageTicks = 0;
                cooldown = placeDelay.get();
            }
            case IGNITE -> {
                Entity cart = findCart(mc);
                if (cart == null) return; // the add-entity packet may still be in flight
                int bow = Ignition.flameBowSlot(mc);
                if (bow < 0) { reset(); return; } // nothing here can prime a cart
                if (mc.player.getInventory().getSelectedSlot() != bow) {
                    ModuleUtils.select(mc, bow);
                    return;
                }
                Ignition.aimServerSide(mc, cart.position().add(0, cart.getBbHeight() * 0.5, 0));
                if (!mc.player.isUsingItem()) {
                    mc.gameMode.useItem(mc.player, InteractionHand.MAIN_HAND);
                    igniteCharge = 0;
                    return;
                }
                if (++igniteCharge < 20) return;
                mc.gameMode.releaseUsingItem(mc.player);
                mc.player.swing(InteractionHand.MAIN_HAND);
                reset();
                cooldown = placeDelay.get();
            }
            default -> { }
        }
    }

    @Override
    public void onRenderFrame(float partialTick) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null || stage != Stage.IDLE || cooldown > 0) return;
        if (mc.gui.screen() != null || mc.isPaused()) return;
        if (ModuleUtils.findHotbarItem(mc, "rail") < 0
                || ModuleUtils.findHotbarItem(mc, "tnt_minecart") < 0) return;

        // The cycle ends with a flame-arrow ignition, so the target has to be close
        // enough that the cart stays in reach while it is drawn and released.
        double reach = Math.min(range.get(), mc.player.entityInteractionRange() + 2.5);
        Player target = ModuleUtils.nearestPlayer(mc, reach);
        if (target == null) return;

        // Fill the block the target stands in, not the solid floor under it.
        BlockPos candidate = target.blockPosition();

        if (!mc.level.getBlockState(candidate).canBeReplaced()
                || mc.level.getBlockState(candidate.below()).canBeReplaced()) {
            candidate = Placement.findSpot(mc, candidate, 2.0);
            if (candidate == null) return;
        }

        railPos = candidate;
        stage = Stage.RAIL;
        com.baggute.cheatclient.module.misc.Debug.stage("AutoCart", stage.name());
        stageTicks = 0;
    }

    private Entity findCart(Minecraft mc) {
        if (railPos == null) return null;
        Vec3 center = Vec3.atCenterOf(railPos).add(0, 0.5, 0);
        for (Entity entity : mc.level.entitiesForRendering()) {
            if (!entity.getType().getDescriptionId().toLowerCase().contains("tnt_minecart")) continue;
            if (entity.position().distanceToSqr(center) > 9.0) continue;
            return entity;
        }
        return null;
    }

    private void reset() {
        stage = Stage.IDLE;
        com.baggute.cheatclient.module.misc.Debug.stage("AutoCart", stage.name());
        stageTicks = 0;
        igniteCharge = 0;
        railPos = null;
    }

    @Override
    protected void onEnable() { reset(); cooldown = 0; }

    @Override
    protected void onDisable() { reset(); cooldown = 0; }
}
