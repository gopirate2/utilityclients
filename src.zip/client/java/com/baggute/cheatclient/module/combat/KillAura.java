// language: Java, file: KillAura.java, target: Fabric 26.2
package com.baggute.cheatclient.module.combat;

import com.baggute.cheatclient.UtilityClient;
import com.baggute.cheatclient.module.Category;
import com.baggute.cheatclient.module.Module;
import com.baggute.cheatclient.settings.BoolSetting;
import com.baggute.cheatclient.settings.DoubleSetting;
import com.baggute.cheatclient.settings.StringSetting;
import net.minecraft.client.Minecraft;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.protocol.game.ServerboundMovePlayerPacket;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.Items;
import net.minecraft.world.phys.Vec3;

import java.util.HashSet;
import java.util.Set;

public class KillAura extends Module {

    private final StringSetting entityFilter;
    private final DoubleSetting range;
    private final BoolSetting autoBlock;
    private final BoolSetting noSwing;
    private final DoubleSetting aimSpeed;
    private boolean blocking;

    public KillAura() {
        super("KillAura", "Silently attacks entities around you.", Category.COMBAT);

        this.entityFilter = new StringSetting("entityFilter", "Entity types to attack",
                "minecraft:player,minecraft:zombie,minecraft:skeleton,minecraft:creeper,minecraft:enderman");
        this.range = new DoubleSetting("range", "Attack range", 4.5, 1.0, 6.0);
        this.autoBlock = new BoolSetting("autoBlock", "Auto-shield when not attacking", false);
        this.noSwing = new BoolSetting("noSwing", "Do not swing hand", false);
        this.aimSpeed = new DoubleSetting("aimSpeed", "Silent aim speed", 1.0, 0.1, 1.0);

        addSetting(entityFilter);
        addSetting(range);
        addSetting(autoBlock);
        addSetting(noSwing);
        addSetting(aimSpeed);
    }

    public Set<String> getEntityFilter() {
        Set<String> out = new HashSet<>();
        for (String p : entityFilter.get().split(",")) {
            String t = p.trim();
            if (!t.isEmpty()) out.add(t);
        }
        return out;
    }

    @Override
    public void onTick() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null || mc.gameMode == null) return;

        Entity target = findTarget(mc);

        // Only drive right-click when an offhand shield can actually block: otherwise
        // this eats/throws whatever is in the main hand, and the key can stay down.
        boolean canBlock = mc.player.getOffhandItem().is(Items.SHIELD);
        if (autoBlock.get() && canBlock) {
            boolean want = target == null || mc.player.getAttackStrengthScale(0.0F) < 0.9F;
            if (want != blocking) {
                blocking = want;
                mc.options.keyUse.setDown(want);
            }
        } else if (blocking) {
            blocking = false;
            mc.options.keyUse.setDown(false);
        }

        if (target == null) return;

        silentAttack(mc, target);
    }

    private Entity findTarget(Minecraft mc) {
        Entity best = null;
        double bestDist = range.get() * range.get();
        Set<String> filter = getEntityFilter();

        for (Entity e : mc.level.entitiesForRendering()) {
            if (!(e instanceof LivingEntity) || e == mc.player || !e.isAlive()) continue;

            String id = BuiltInRegistries.ENTITY_TYPE.getKey(e.getType()) == null
                    ? e.getType().toString()
                    : BuiltInRegistries.ENTITY_TYPE.getKey(e.getType()).toString();
            if (!filter.contains(id)) continue;

            double d = e.distanceToSqr(mc.player);
            if (d < bestDist) {
                bestDist = d;
                best = e;
            }
        }
        return best;
    }

    private void silentAttack(Minecraft mc, Entity target) {
        if (mc.player.getAttackStrengthScale(0.0F) < 0.9F) return;

        Vec3 eye = mc.player.getEyePosition();
        Vec3 targetPos = target.position().add(0, target.getBbHeight() * 0.5, 0);
        Vec3 delta = targetPos.subtract(eye);

        double hDist = Math.sqrt(delta.x * delta.x + delta.z * delta.z);
        float targetYaw = (float) (Math.toDegrees(Math.atan2(delta.z, delta.x)) - 90.0);
        float targetPitch = (float) -Math.toDegrees(Math.atan2(delta.y, hDist));

        float oldYaw = mc.player.getYRot();
        float oldPitch = mc.player.getXRot();

        float speed = (float) aimSpeed.get();
        // Wrap the yaw delta, or crossing the +/-180 seam rotates the long way
        // round and the packet ends up pointing away from the target.
        float yawDelta = net.minecraft.util.Mth.wrapDegrees(targetYaw - oldYaw);
        float pitchDelta = net.minecraft.util.Mth.clamp(targetPitch - oldPitch, -90f, 90f);
        float newYaw = oldYaw + yawDelta * speed;
        float newPitch = net.minecraft.util.Mth.clamp(oldPitch + pitchDelta * speed, -90f, 90f);

        mc.player.setYRot(newYaw);
        mc.player.setXRot(newPitch);

        mc.player.connection.send(new ServerboundMovePlayerPacket.Rot(
                newYaw, newPitch, mc.player.onGround(), mc.player.horizontalCollision
        ));

        mc.gameMode.attack(mc.player, target);
        if (!noSwing.get()) mc.player.swing(InteractionHand.MAIN_HAND);

        // Restore through the pipeline: setting only the current rotation leaves
        // yRotO/xRotO behind, and the client then interpolates the whole camera
        // back with a visible snap on the next frame.
        AimPipeline.apply(mc, oldYaw, oldPitch);
    }

    @Override
    protected void onEnable() {
        UtilityClient.LOGGER.info("[KillAura] enabled");
    }

    @Override
    protected void onDisable() {
        Minecraft mc = Minecraft.getInstance();
        blocking = false;
        if (mc.options != null) mc.options.keyUse.setDown(false);
        UtilityClient.LOGGER.info("[KillAura] disabled");
    }
}