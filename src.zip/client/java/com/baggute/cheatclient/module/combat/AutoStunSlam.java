// language: Java, file: AutoStunSlam.java, target: Fabric 26.2
package com.baggute.cheatclient.module.combat;

import com.baggute.cheatclient.UtilityClient;
import com.baggute.cheatclient.module.Category;
import com.baggute.cheatclient.module.Module;
import com.baggute.cheatclient.settings.BoolSetting;
import com.baggute.cheatclient.settings.DoubleSetting;
import com.baggute.cheatclient.settings.IntSetting;
import net.minecraft.client.Minecraft;
import net.minecraft.network.protocol.game.ServerboundMovePlayerPacket;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.AxeItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.ShieldItem;
import net.minecraft.world.phys.Vec3;

import java.util.concurrent.ThreadLocalRandom;

/**
 * Shield break into a mace hit.
 *
 * <p>The sequence is axe → wait → mace, and every wait is a tick counter. The
 * earlier version swapped to the axe and attacked in the same tick, which the
 * server resolves against the item you were holding *before* the swap: an axe
 * swing that broke nothing, followed by a mace hit on a shield that was never
 * stunned. One tick is the minimum for the carried-item packet to land; the mace
 * gets two, because it also has to survive the shield's block-delay.
 *
 * <p>Both hits are silent-aimed: the server receives a rotation aimed at the
 * target while your camera never moves.
 */
public class AutoStunSlam extends Module {

    private final DoubleSetting range;
    private final BoolSetting autoSwap;
    private final IntSetting missChance;
    private final BoolSetting silentAim;

    /** Ticks between selecting the axe and swinging it. */
    private static final int AXE_SWAP_TICKS = 1;
    /** Ticks between breaking the shield and the mace hit. */
    private static final int MACE_SWAP_TICKS = 2;
    /** Ticks to hold the mace in hand after the hit before returning. */
    private static final int RESTORE_TICKS = 2;

    private int previousSlot = -1;
    private int axeTicks = -1;
    private int maceTicks = -1;
    private int restoreTicks = -1;
    private int cooldownTicks = 0;
    private int targetId = -1;

    public AutoStunSlam() {
        super("AutoStunSlam", "Breaks a raised shield with an axe, then slams with a mace.", Category.COMBAT);
        this.range = new DoubleSetting("range", "Reach for both hits", 4.5, 1.0, 6.0);
        this.autoSwap = new BoolSetting("autoSwap", "Switch weapons only when attacking", true);
        this.missChance = new IntSetting("missChance", "Chance to swing and miss (%)", 0, 0, 100);
        this.silentAim = new BoolSetting("silentAim", "Aim server-side only", true);
        addSetting(range);
        addSetting(autoSwap);
        addSetting(missChance);
        addSetting(silentAim);
    }

    @Override
    public void onTick() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null || mc.gameMode == null) return;

        if (axeTicks > 0) {
            if (--axeTicks == 0) {
                axeTicks = -1;
                swingAt(mc, true);
            }
            return;
        }

        if (maceTicks > 0) {
            if (--maceTicks == 0) {
                maceTicks = -1;
                swingAt(mc, false);
            }
            return;
        }

        if (restoreTicks > 0) {
            if (--restoreTicks == 0) {
                restoreTicks = -1;
                restoreSlot(mc);
            }
            return;
        }

        if (cooldownTicks > 0) {
            cooldownTicks--;
            return;
        }

        // Do not start a combo on a half-charged weapon: the hit would be a wet noodle.
        if (mc.player.getAttackStrengthScale(0.0F) < 0.9F) return;

        Entity target = findShieldingTarget(mc);
        if (target == null) return;

        int axeSlot = autoSwap.get() ? findSlot(mc, true) : -1;
        if (axeSlot < 0) {
            // No axe in the hotbar: nothing to break with, so do not flail.
            return;
        }

        previousSlot = mc.player.getInventory().getSelectedSlot();
        targetId = target.getId();
        mc.player.getInventory().setSelectedSlot(axeSlot);
        axeTicks = AXE_SWAP_TICKS;
    }

    private void swingAt(Minecraft mc, boolean withAxe) {
        Entity target = mc.level == null ? null : mc.level.getEntity(targetId);
        if (target == null || !target.isAlive() || !inRange(mc, target)) {
            restoreSlot(mc);
            cooldownTicks = 4;
            return;
        }

        int wanted = findSlot(mc, withAxe);
        if (wanted >= 0 && mc.player.getInventory().getSelectedSlot() != wanted) {
            mc.player.getInventory().setSelectedSlot(wanted);
            // Switching now would mean swinging the old item: wait a tick for the
            // server to resolve the swap, then come back here.
            if (withAxe) axeTicks = 1; else maceTicks = 1;
            return;
        }

        if (rollMiss()) {
            mc.player.swing(InteractionHand.MAIN_HAND);
        } else {
            attackSilently(mc, target);
        }

        if (withAxe) {
            // Mace comes out now so the server has it two ticks before the slam.
            int maceSlot = findSlot(mc, false);
            if (maceSlot >= 0) mc.player.getInventory().setSelectedSlot(maceSlot);
            maceTicks = MACE_SWAP_TICKS;
        } else {
            restoreTicks = RESTORE_TICKS;
            cooldownTicks = 10;
            targetId = -1;
        }
    }

    /** Snap, hit, snap back: the camera never shows the rotation. */
    private void attackSilently(Minecraft mc, Entity target) {
        Vec3 point = AimPipeline.closestPoint(target, mc.player.getEyePosition(1.0f), 0);

        if (!silentAim.get()) {
            AimPipeline.snapTo(mc, point);
            mc.gameMode.attack(mc.player, target);
            mc.player.swing(InteractionHand.MAIN_HAND);
            return;
        }

        float oldYaw = mc.player.getYRot();
        float oldPitch = mc.player.getXRot();
        AimPipeline.snapTo(mc, point);
        // The server resolves the hit against the rotation it is told about, so the
        // rotation packet has to be on the wire before the interaction packet.
        if (mc.player.connection != null) {
            mc.player.connection.send(new ServerboundMovePlayerPacket.Rot(
                    mc.player.getYRot(), mc.player.getXRot(),
                    mc.player.onGround(), mc.player.horizontalCollision));
        }
        mc.gameMode.attack(mc.player, target);
        mc.player.swing(InteractionHand.MAIN_HAND);
        AimPipeline.apply(mc, oldYaw, oldPitch);
    }

    private boolean rollMiss() {
        int chance = missChance.get();
        if (chance <= 0) return false;
        if (chance >= 100) return true;
        return ThreadLocalRandom.current().nextInt(100) < chance;
    }

    private Entity findShieldingTarget(Minecraft mc) {
        Entity best = null;
        double bestDistance = range.get() * range.get();
        for (Entity entity : mc.level.entitiesForRendering()) {
            if (!(entity instanceof Player player) || player == mc.player || !player.isAlive()) continue;
            if (!player.isUsingItem() || !(player.getUseItem().getItem() instanceof ShieldItem)) continue;
            double distance = player.distanceToSqr(mc.player);
            if (distance < bestDistance) {
                bestDistance = distance;
                best = player;
            }
        }
        return best;
    }

    private boolean inRange(Minecraft mc, Entity target) {
        return mc.player.distanceToSqr(target) <= range.get() * range.get();
    }

    private void restoreSlot(Minecraft mc) {
        if (previousSlot >= 0 && mc.player != null
                && mc.player.getInventory().getSelectedSlot() != previousSlot) {
            mc.player.getInventory().setSelectedSlot(previousSlot);
        }
        previousSlot = -1;
    }

    private int findSlot(Minecraft mc, boolean axe) {
        for (int slot = 0; slot < 9; slot++) {
            ItemStack stack = mc.player.getInventory().getItem(slot);
            if (axe ? stack.getItem() instanceof AxeItem : isMace(stack)) return slot;
        }
        return -1;
    }

    private boolean isMace(ItemStack stack) {
        return !stack.isEmpty() && stack.getItem().toString().toLowerCase().contains("mace");
    }

    @Override
    protected void onEnable() {
        previousSlot = -1;
        axeTicks = -1;
        maceTicks = -1;
        restoreTicks = -1;
        cooldownTicks = 0;
        targetId = -1;
        UtilityClient.LOGGER.info("[AutoStunSlam] enabled");
    }

    @Override
    protected void onDisable() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player != null) restoreSlot(mc);
        axeTicks = -1;
        maceTicks = -1;
        restoreTicks = -1;
        cooldownTicks = 0;
        targetId = -1;
    }
}
