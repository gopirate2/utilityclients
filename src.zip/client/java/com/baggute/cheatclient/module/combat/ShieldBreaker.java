// language: Java, file: ShieldBreaker.java, target: Fabric 26.2
package com.baggute.cheatclient.module.combat;

import com.baggute.cheatclient.UtilityClient;
import com.baggute.cheatclient.module.Category;
import com.baggute.cheatclient.module.Module;
import com.baggute.cheatclient.settings.BoolSetting;
import com.baggute.cheatclient.settings.DoubleSetting;
import com.baggute.cheatclient.settings.IntSetting;
import net.minecraft.client.Minecraft;
import net.minecraft.network.protocol.game.ServerboundPlayerCommandPacket;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.AxeItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;

import java.util.Random;

/**
 * Auto shield break. Two routes into a blocked target:
 *
 *  - axe disable: an axe hit puts the shield on cooldown and a critical axe hit
 *    disables it outright. With critBreak on, the module hops first, waits for
 *    the fall, then swings so the hit lands as a crit.
 *  - durability drain: spamAxe keeps swinging the axe until the shield breaks.
 *
 * Target comes from the crosshair when it is on a player, otherwise from the
 * nearest blocking player inside range.
 */
public class ShieldBreaker extends Module {

    private final BoolSetting onclick;
    private final DoubleSetting range;
    private final BoolSetting critBreak;
    private final DoubleSetting missChance;
    private final BoolSetting spamAxe;
    private final BoolSetting autoSwap;
    private final IntSetting swapToSlot;
    private final IntSetting swapBackDelay;
    private final IntSetting delayBeforeBreaking;
    private final BoolSetting shieldStun;

    private final Random rng = new Random();

    private Entity lastTarget = null;
    private boolean targetWasBlocking = false;
    private long firstBlockDetectedMs = 0L;
    private long lastAttackMs = 0L;
    private long lastStunPacketMs = 0L;

    private boolean critJumpHeld = false;
    private int critWaitTicks = 0;
    /** Safety window for the hop; a vanilla jump only starts falling around tick 6. */
    private int critTimeout = 0;

    private int axeSlot = -1;
    private int previousSlot = -1;
    private int swapBackTicksRemaining = 0;

    private int stunTicksRemaining = 0;

    public ShieldBreaker() {
        super("ShieldBreaker", "Breaks player shields and follows up with a stun.", Category.COMBAT);

        this.onclick             = new BoolSetting("onclick", "Only act while left-click held", false);
        this.range               = new DoubleSetting("range", "Search range when not aiming", 3.5, 1.0, 6.0);
        this.critBreak           = new BoolSetting("critBreak", "Jump-crit the axe for an instant disable", true);
        this.missChance          = new DoubleSetting("missChance", "Chance to skip axe swap (%)", 0.0, 0.0, 100.0);
        this.spamAxe             = new BoolSetting("spamAxe", "Keep swinging until shield breaks", true);
        this.autoSwap            = new BoolSetting("autoSwap", "Auto-swap to axe from hotbar", true);
        this.swapToSlot          = new IntSetting("swapToSlot", "Slot to return to (1-9)", 1, 1, 9);
        this.swapBackDelay       = new IntSetting("swapBackDelay", "Ticks before swapping back", 4, 0, 20);
        this.delayBeforeBreaking = new IntSetting("delayBeforeBreaking", "Delay before breaking (ms)", 150, 0, 2000);
        this.shieldStun          = new BoolSetting("shieldStun", "Knock up after shield breaks", true);

        addSetting(onclick);
        addSetting(range);
        addSetting(critBreak);
        addSetting(missChance);
        addSetting(spamAxe);
        addSetting(autoSwap);
        addSetting(swapToSlot);
        addSetting(swapBackDelay);
        addSetting(delayBeforeBreaking);
        addSetting(shieldStun);
    }

    @Override
    public void onTick() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null || mc.gameMode == null) return;

        if (swapBackTicksRemaining > 0) {
            swapBackTicksRemaining--;
            if (swapBackTicksRemaining == 0) {
                if (axeSlot >= 0 && mc.player.getInventory().getSelectedSlot() == axeSlot) {
                    selectFallback(mc);
                }
                axeSlot = -1;
            }
        }

        if (onclick.get() && !mc.options.keyAttack.isDown()) return;

        Entity target = findTarget(mc);
        if (target == null) { reset(); releaseCritJump(mc); return; }

        long now = System.currentTimeMillis();
        boolean blocking = isTargetBlocking(target);

        if (target != lastTarget) {
            lastTarget = target;
            targetWasBlocking = blocking;
            firstBlockDetectedMs = blocking ? now : 0L;
            lastAttackMs = 0L;
            stunTicksRemaining = 0;
            critWaitTicks = 0;
        }

        if (targetWasBlocking && !blocking && lastAttackMs > 0 && now - lastAttackMs < 400) {
            stunTicksRemaining = 5;
            UtilityClient.LOGGER.info("[ShieldBreaker] shield down - arming stun");
        }
        targetWasBlocking = blocking;

        if (!blocking) {
            releaseCritJump(mc);
            if (shieldStun.get() && stunTicksRemaining > 0) {
                stunTicksRemaining--;
                doStun(mc, target);
            }
            return;
        }

        if (firstBlockDetectedMs == 0L) firstBlockDetectedMs = now;
        if (!spamAxe.get()) return;
        if (now - firstBlockDetectedMs < delayBeforeBreaking.get()) return;

        // Crit route: the swing only fires once the hop has turned into a fall.
        // The jump reaches its apex around tick 6, so the window has to outlive a
        // 3-tick counter - that counter expired mid-flight and left keyJump down.
        if (critBreak.get() && critJumpHeld) {
            critTimeout--;
            if (!mc.player.onGround() && mc.player.getDeltaMovement().y < 0.0) {
                swingAxe(mc, target);
                lastAttackMs = now;
                if (axeSlot >= 0) swapBackTicksRemaining = swapBackDelay.get() + 1;
                releaseCritJump(mc);
            } else if (critTimeout <= 0) {
                // Ceiling or blocked hop: never leave the jump key latched.
                releaseCritJump(mc);
            }
            return;
        }

        if (now - lastAttackMs < 250) return;
        if (missChance.get() > 0.0 && rng.nextDouble() * 100.0 < missChance.get()) return;

        if (!isAxeHeld(mc)) {
            if (!autoSwap.get()) return;
            int slot = findAxeSlot(mc);
            if (slot < 0 || slot == mc.player.getInventory().getSelectedSlot()) return;
            axeSlot = slot;
            // Remember what was held so the cycle restores it instead of jumping
            // to the configured slot and silently moving the player's item.
            if (previousSlot < 0) previousSlot = mc.player.getInventory().getSelectedSlot();
            mc.player.getInventory().setSelectedSlot(slot);
            // Swing on the next tick so the axe is the held item server-side.
            return;
        }

        if (critBreak.get() && mc.player.onGround() && !critJumpHeld) {
            mc.options.keyJump.setDown(true);
            critJumpHeld = true;
            critTimeout = 12;
            return;
        }

        swingAxe(mc, target);
        lastAttackMs = now;
        if (axeSlot >= 0) swapBackTicksRemaining = swapBackDelay.get() + 1;
    }

    private void swingAxe(Minecraft mc, Entity target) {
        mc.gameMode.attack(mc.player, target);
        mc.player.swing(InteractionHand.MAIN_HAND);
    }

    private void doStun(Minecraft mc, Entity target) {
        if (mc.player.connection == null) return;

        long now = System.currentTimeMillis();
        if (now - lastStunPacketMs < 100) return;
        lastStunPacketMs = now;

        mc.player.setSprinting(true);
        mc.player.connection.send(new ServerboundPlayerCommandPacket(
                mc.player, ServerboundPlayerCommandPacket.Action.START_SPRINTING));

        mc.gameMode.attack(mc.player, target);
        mc.player.swing(InteractionHand.MAIN_HAND);

        UtilityClient.LOGGER.info("[ShieldBreaker] stun swing landed");
    }

    private Entity findTarget(Minecraft mc) {
        HitResult hit = mc.hitResult;
        if (hit instanceof EntityHitResult ehr) {
            Entity aimed = ehr.getEntity();
            if (aimed instanceof Player p && p != mc.player && p.isAlive()) return p;
        }

        Entity best = null;
        double bestDistance = range.get() * range.get();
        for (Entity entity : mc.level.entitiesForRendering()) {
            if (!(entity instanceof Player p) || p == mc.player || !p.isAlive()) continue;
            if (!isTargetBlocking(p)) continue;
            double distance = p.distanceToSqr(mc.player);
            if (distance <= bestDistance) {
                bestDistance = distance;
                best = p;
            }
        }
        return best;
    }

    private boolean isTargetBlocking(Entity target) {
        if (!(target instanceof Player p)) return false;
        try {
            return p.isBlocking();
        } catch (Throwable t) {
            return p.isUsingItem();
        }
    }

    private boolean isAxeHeld(Minecraft mc) {
        return mc.player.getMainHandItem().getItem() instanceof AxeItem;
    }

    private int findAxeSlot(Minecraft mc) {
        for (int i = 0; i < 9; i++) {
            ItemStack stack = mc.player.getInventory().getItem(i);
            if (!stack.isEmpty() && stack.getItem() instanceof AxeItem) return i;
        }
        return -1;
    }

    private void selectFallback(Minecraft mc) {
        int target = previousSlot >= 0
                ? previousSlot
                : Math.max(0, Math.min(8, swapToSlot.get() - 1));
        previousSlot = -1;
        mc.player.getInventory().setSelectedSlot(target);
    }

    private void releaseCritJump(Minecraft mc) {
        if (critJumpHeld && mc.options != null) mc.options.keyJump.setDown(false);
        critJumpHeld = false;
        critWaitTicks = 0;
        critTimeout = 0;
    }

    private void reset() {
        lastTarget = null;
        targetWasBlocking = false;
        firstBlockDetectedMs = 0L;
        lastAttackMs = 0L;
        stunTicksRemaining = 0;
        critWaitTicks = 0;
        critTimeout = 0;
        // swap-back state is left alone so it completes even if the target is lost
    }

    @Override
    protected void onEnable() {
        lastTarget = null;
        targetWasBlocking = false;
        firstBlockDetectedMs = 0L;
        lastAttackMs = 0L;
        stunTicksRemaining = 0;
        swapBackTicksRemaining = 0;
        critJumpHeld = false;
        critWaitTicks = 0;
        critTimeout = 0;
        axeSlot = -1;
        previousSlot = -1;
        UtilityClient.LOGGER.info("[ShieldBreaker] enabled");
    }

    @Override
    protected void onDisable() {
        Minecraft mc = Minecraft.getInstance();
        releaseCritJump(mc);
        if (mc.player != null && axeSlot >= 0
                && mc.player.getInventory().getSelectedSlot() == axeSlot) {
            selectFallback(mc);
        }
        axeSlot = -1;
        swapBackTicksRemaining = 0;
        UtilityClient.LOGGER.info("[ShieldBreaker] disabled");
    }
}
