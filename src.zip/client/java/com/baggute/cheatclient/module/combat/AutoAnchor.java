// language: Java, file: AutoAnchor.java, target: Fabric 26.2
package com.baggute.cheatclient.module.combat;

import com.baggute.cheatclient.module.Category;
import com.baggute.cheatclient.module.Module;
import com.baggute.cheatclient.settings.BoolSetting;
import com.baggute.cheatclient.settings.DoubleSetting;
import com.baggute.cheatclient.settings.IntSetting;
import com.baggute.cheatclient.util.ModuleUtils;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;

/**
 * Anchor cycle: place a respawn anchor at the target's feet, charge it with
 * glowstone, then detonate it by using it again.
 *
 * Explosion only fires in the overworld; in the nether the anchor just sits there
 * charged, which is correct vanilla behaviour.
 */
public class AutoAnchor extends Module {

    private final DoubleSetting range;
    private final IntSetting placeDelay;
    private final BoolSetting charge;
    private final BoolSetting explode;

    private Stage stage = Stage.IDLE;
    private int cooldown = 0;
    private int stageTicks = 0;
    private BlockPos anchorPos = null;

    private enum Stage { IDLE, PLACE, CHARGE, BOOM }

    public AutoAnchor() {
        super("AutoAnchor", "Places, charges and detonates respawn anchors.", Category.COMBAT);

        this.range = new DoubleSetting("range", "Target range", 4.0, 2.0, 6.0);
        this.placeDelay = new IntSetting("placeDelay", "Ticks between cycles", 6, 1, 30);
        this.charge = new BoolSetting("charge", "Charge with glowstone", true);
        this.explode = new BoolSetting("explode", "Detonate after charging", true);

        addSetting(range);
        addSetting(placeDelay);
        addSetting(charge);
        addSetting(explode);
    }

    @Override
    public void onTick() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null || mc.gameMode == null) return;
        if (mc.gui.screen() != null || mc.isPaused()) return;
        if (cooldown > 0) cooldown--;
        if (stage == Stage.IDLE) return;
        if (++stageTicks > 60) { reset(); return; }

        switch (stage) {
            case PLACE -> {
                if (anchorPos == null) { reset(); return; }
                Placement.Result result = Placement.useOn(mc, "respawn_anchor", anchorPos.below());
                if (result == Placement.Result.WAITING) return;
                if (result != Placement.Result.USED) { reset(); return; }
                stage = charge.get() ? Stage.CHARGE : Stage.IDLE;
                stageTicks = 0;
            }
            case CHARGE -> {
                if (anchorPos == null) { reset(); return; }
                // Charge by using the glowstone on the anchor block itself; passing
                // anchorPos.below() placed the glowstone into the occupied anchor
                // slot, so the anchor stayed uncharged and BOOM re-charged it.
                Placement.Result result = Placement.useOn(mc, "glowstone", anchorPos);
                if (result == Placement.Result.WAITING) return;
                if (result != Placement.Result.USED) { reset(); return; }
                stage = explode.get() ? Stage.BOOM : Stage.IDLE;
                stageTicks = 0;
                cooldown = placeDelay.get();
            }
            case BOOM -> {
                if (anchorPos == null) { reset(); return; }
                // Glowstone in hand is respawn fuel: the anchor would charge again
                // instead of detonating, so switch to any other hotbar item first.
                if (ModuleUtils.matches(mc.player.getMainHandItem(), "glowstone")) {
                    int slot = nonGlowstoneSlot(mc);
                    if (slot < 0) { reset(); return; }
                    ModuleUtils.select(mc, slot);
                    return;
                }
                if (!explodeAnchor(mc, anchorPos)) { reset(); return; }
                reset();
                cooldown = placeDelay.get();
            }
            default -> { }
        }
    }

    @Override
    public void onRenderFrame(float partialTick) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null || stage != Stage.IDLE || cooldown > 0) return;
        if (mc.gui.screen() != null || mc.isPaused()) return;

        // The anchor is placed at the target's feet, so the cycle needs block reach
        // for placement and the same reach for the detonation click.
        double reach = Math.min(range.get(), mc.player.blockInteractionRange() + 0.5);
        Player target = ModuleUtils.nearestPlayer(mc, reach);
        if (target == null) return;

        // Fill the block the target stands in; the floor below it is solid.
        BlockPos candidate = target.blockPosition();
        if (candidate.distSqr(mc.player.blockPosition()) > 30.0) return;

        if (!mc.level.getBlockState(candidate).canBeReplaced()) {
            candidate = Placement.findSpot(mc, candidate, 2.0);
            if (candidate == null) return;
        }
        if (ModuleUtils.findHotbarItem(mc, "respawn_anchor") < 0) return;

        anchorPos = candidate;
        stage = Stage.PLACE;
        com.baggute.cheatclient.module.misc.Debug.stage("AutoAnchor", stage.name());
        stageTicks = 0;
    }

    /** A charged anchor detonates when used with any item in hand. */
    private boolean explodeAnchor(Minecraft mc, BlockPos pos) {
        if (mc.player == null || mc.gameMode == null) return false;
        if (!mc.player.isWithinBlockInteractionRange(pos, 0.0)) return false;
        Vec3 hit = Vec3.atCenterOf(pos);
        mc.gameMode.useItemOn(mc.player, InteractionHand.MAIN_HAND,
                new BlockHitResult(hit, Direction.UP, pos, false));
        mc.player.swing(InteractionHand.MAIN_HAND);
        return true;
    }

    /** Any hotbar slot that is not glowstone, so BOOM does not recharge the anchor. */
    private int nonGlowstoneSlot(Minecraft mc) {
        for (int i = 0; i < 9; i++) {
            if (!ModuleUtils.matches(mc.player.getInventory().getItem(i), "glowstone")) return i;
        }
        return -1;
    }

    private void reset() {
        stage = Stage.IDLE;
        com.baggute.cheatclient.module.misc.Debug.stage("AutoAnchor", stage.name());
        stageTicks = 0;
        anchorPos = null;
    }

    @Override
    protected void onEnable() { reset(); cooldown = 0; }

    @Override
    protected void onDisable() { reset(); cooldown = 0; }
}
