// language: Java, file: AutoClicker.java, target: Fabric 26.2
package com.baggute.cheatclient.module.combat;

import com.baggute.cheatclient.module.Category;
import com.baggute.cheatclient.module.Module;
import com.baggute.cheatclient.settings.BoolSetting;
import com.baggute.cheatclient.settings.DoubleSetting;
import net.minecraft.client.Minecraft;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.EntityHitResult;

import java.util.Random;

/**
 * PVP auto clicker: while left-click is held it fires attack clicks at a
 * randomised rate inside the configured CPS window.
 */
public final class AutoClicker extends Module {

    private final DoubleSetting cpsMin = new DoubleSetting("cpsMin", "Minimum clicks per second", 8.0, 1.0, 20.0);
    private final DoubleSetting cpsMax = new DoubleSetting("cpsMax", "Maximum clicks per second", 12.0, 1.0, 20.0);
    private final BoolSetting playersOnly = new BoolSetting("playersOnly", "Only click players", false);
    private final BoolSetting swing = new BoolSetting("swing", "Swing hand", true);

    private final Random rng = new Random();
    private double carried;
    private long lastMs;

    public AutoClicker() {
        super("AutoClicker", "Clicks for you while left-click is held, with randomised CPS.", Category.COMBAT);
        addSetting(cpsMin);
        addSetting(cpsMax);
        addSetting(playersOnly);
        addSetting(swing);
    }

    @Override
    public void onTick() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.gameMode == null) return;

        if (mc.gui.screen() != null || mc.isPaused() || !mc.options.keyAttack.isDown()) {
            carried = 0;
            lastMs = 0;
            return;
        }

        long now = System.currentTimeMillis();
        if (lastMs == 0) { lastMs = now; return; }
        double seconds = Math.min(250, now - lastMs) / 1000.0;
        lastMs = now;

        double low = Math.min(cpsMin.get(), cpsMax.get());
        double high = Math.max(cpsMin.get(), cpsMax.get());
        double cps = low + rng.nextDouble() * (high - low);
        carried += cps * seconds;

        int clicks = 0;
        while (carried >= 1.0 && clicks < 4) {
            carried -= 1.0;
            clicks++;
            click(mc);
        }
    }

    private void click(Minecraft mc) {
        // Vanilla 1.9+: an attack fired before the cooldown fills deals a fraction
        // of its damage. Uncapped CPS therefore looks fast and hits like a hand of
        // wet paper — the extra clicks are noise the server discards.
        if (mc.player.getAttackStrengthScale(0.0F) < 0.9F) {
            if (swing.get()) mc.player.swing(InteractionHand.MAIN_HAND);
            return;
        }

        Entity target = null;
        if (mc.hitResult instanceof EntityHitResult hit) {
            Entity aimed = hit.getEntity();
            if (aimed instanceof LivingEntity living && living.isAlive()
                    && (!playersOnly.get() || aimed instanceof Player)) {
                target = aimed;
            }
        }

        if (target != null && mc.player.isWithinEntityInteractionRange(target, 2.5)) {
            mc.gameMode.attack(mc.player, target);
        }
        if (swing.get()) mc.player.swing(InteractionHand.MAIN_HAND);
    }

    @Override
    protected void onEnable() {
        carried = 0;
        lastMs = 0;
    }
}
