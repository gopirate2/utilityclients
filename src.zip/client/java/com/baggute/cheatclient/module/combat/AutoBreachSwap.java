package com.baggute.cheatclient.module.combat;

import com.baggute.cheatclient.module.Category;
import com.baggute.cheatclient.module.Module;
import com.baggute.cheatclient.settings.BoolSetting;
import com.baggute.cheatclient.util.ModuleUtils;
import net.minecraft.client.Minecraft;
import net.minecraft.core.component.DataComponents;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.item.enchantment.ItemEnchantments;
import net.minecraft.world.phys.EntityHitResult;

/**
 * One breach-mace hit, then back to the old item.
 *
 * <p>Equip and swing are split over two ticks (the swing has to happen with the
 * mace actually selected), so the target is resolved again on the swing tick and
 * falls back to the nearest entity in front. The swap-back is armed as soon as
 * the mace is equipped, so a drift in the crosshair can never leave the player
 * holding the mace with no way back.
 */
public final class AutoBreachSwap extends Module {

    private final BoolSetting onlyWhileClicking =
            new BoolSetting("onlyWhileClicking", "Attack only while left-click is held", true);

    private int oldSlot = -1;
    private int restoreTicks;
    private boolean pendingSwing;

    public AutoBreachSwap() {
        super("AutoBreachSwap", "Attacks once with a BREACH mace, then returns.", Category.COMBAT);
        addSetting(onlyWhileClicking);
    }

    @Override
    public void onTick() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.gameMode == null || mc.level == null) return;

        if (restoreTicks > 0) {
            restoreTicks--;
            if (restoreTicks == 0 && oldSlot >= 0) {
                ModuleUtils.select(mc, oldSlot);
                oldSlot = -1;
            }
            return;
        }

        if (pendingSwing) {
            pendingSwing = false;
            LivingEntity target = resolveTarget(mc);
            if (target != null) {
                mc.gameMode.attack(mc.player, target);
                mc.player.swing(InteractionHand.MAIN_HAND);
            }
            // Armed even on a whiff so the hotbar always comes back.
            if (oldSlot >= 0) restoreTicks = 2;
            return;
        }

        if (onlyWhileClicking.get() && !mc.options.keyAttack.isDown()) return;
        if (mc.player.getAttackStrengthScale(0.0F) < 0.9F) return;

        LivingEntity target = resolveTarget(mc);
        if (target == null) return;

        int slot = findBreachMaceSlot(mc);
        if (slot < 0) return;

        if (!hasBreachMace(mc.player.getMainHandItem())) {
            if (oldSlot < 0) oldSlot = mc.player.getInventory().getSelectedSlot();
            ModuleUtils.select(mc, slot);
            pendingSwing = true;
            return;
        }

        mc.gameMode.attack(mc.player, target);
        mc.player.swing(InteractionHand.MAIN_HAND);
        if (oldSlot >= 0) restoreTicks = 2;
    }

    /** Crosshair entity first, then the nearest living entity in front of us. */
    private LivingEntity resolveTarget(Minecraft mc) {
        if (mc.hitResult instanceof EntityHitResult hit
                && hit.getEntity() instanceof LivingEntity living
                && living != mc.player && living.isAlive()) {
            return living;
        }
        Entity fallback = AimPipeline.pickTarget(
                mc, mc.player.entityInteractionRange() + 1.0, 120.0, null, false);
        return fallback instanceof LivingEntity living && living.isAlive() ? living : null;
    }

    private int findBreachMaceSlot(Minecraft mc) {
        for (int i = 0; i < 9; i++) {
            if (hasBreachMace(mc.player.getInventory().getItem(i))) return i;
        }
        return -1;
    }

    private boolean hasBreachMace(ItemStack s) {
        if (!ModuleUtils.matches(s, "mace")) return false;
        ItemEnchantments e = s.get(DataComponents.ENCHANTMENTS);
        if (e == null) return false;
        for (var x : e.entrySet()) {
            if (x.getKey().is(Enchantments.BREACH) && x.getIntValue() > 0) return true;
        }
        return false;
    }

    @Override
    protected void onEnable() {
        oldSlot = -1;
        restoreTicks = 0;
        pendingSwing = false;
    }

    @Override
    protected void onDisable() {
        Minecraft mc = Minecraft.getInstance();
        if (oldSlot >= 0) {
            if (mc.player != null) ModuleUtils.select(mc, oldSlot);
            oldSlot = -1;
        }
        restoreTicks = 0;
        pendingSwing = false;
    }
}
