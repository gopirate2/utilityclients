// language: Java, file: BowAimbot.java, target: Fabric 26.2
package com.baggute.cheatclient.module.combat;

import com.baggute.cheatclient.module.Category;
import com.baggute.cheatclient.module.Module;
import com.baggute.cheatclient.settings.BoolSetting;
import com.baggute.cheatclient.settings.DoubleSetting;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;

/**
 * Solves the arrow drop instead of aiming flat. Pitch is bisected against a
 * per-tick drag simulation of the actual arrow physics (0.99 drag, 0.05 gravity),
 * so a distant target gets the same lead a good player computes by feel.
 */
public class BowAimbot extends Module {

    private final DoubleSetting range;
    private final BoolSetting onlyWhileDrawing;
    private final DoubleSetting minCharge;
    private final BoolSetting silent;

    public BowAimbot() {
        super("BowAimbot", "Aims bow shots with real arrow drop compensation.", Category.COMBAT);

        this.range = new DoubleSetting("range", "Max target distance", 40.0, 5.0, 96.0);
        this.onlyWhileDrawing = new BoolSetting("onlyWhileDrawing", "Only aim while the bow is drawn", true);
        this.minCharge = new DoubleSetting("minCharge", "Minimum draw before aiming", 0.5, 0.1, 1.0);
        this.silent = new BoolSetting("silent", "Snap back after aiming", false);

        addSetting(range);
        addSetting(onlyWhileDrawing);
        addSetting(minCharge);
        addSetting(silent);
    }

    @Override
    public void onTick() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null) return;

        boolean drawing = mc.player.isUsingItem();
        if (onlyWhileDrawing.get() && !drawing) return;
        if (drawing && drawCharge(mc) < minCharge.get()) return;

        boolean holdingBow = mc.player.getMainHandItem().getItem().toString().toLowerCase().contains("bow")
                || mc.player.getOffhandItem().getItem().toString().toLowerCase().contains("bow");
        if (!holdingBow) return;

        LivingEntity target = pick(mc);
        if (target == null) return;

        Vec3 eye = mc.player.getEyePosition();
        Vec3 aim = target.position().add(0, target.getBbHeight() * 0.55, 0);
        double dx = aim.x - eye.x;
        double dz = aim.z - eye.z;
        double horizontal = Math.sqrt(dx * dx + dz * dz);
        double dy = aim.y - eye.y;

        float yaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90);
        float pitch = solvePitch(horizontal, dy, velocity(mc));

        float oldYaw = mc.player.getYRot();
        float oldPitch = mc.player.getXRot();
        mc.player.setYRot(yaw);
        mc.player.setXRot(pitch);
        if (silent.get()) {
            // Send the aim to the server, then hand the camera back untouched.
            if (mc.player.connection != null) {
                mc.player.connection.send(new net.minecraft.network.protocol.game.ServerboundMovePlayerPacket.Rot(
                        yaw, pitch, mc.player.onGround(), mc.player.horizontalCollision));
            }
            mc.player.setYRot(oldYaw);
            mc.player.setXRot(oldPitch);
        }
    }

    private double velocity(Minecraft mc) {
        float charge = mc.player.getTicksUsingItem() / 20.0f;
        charge = (charge * charge + charge * 2) / 3;
        charge = Math.min(1.0f, charge);
        return charge * 3.0;
    }

    /** Draw progress 0..1, matching the vanilla charge curve the velocity uses. */
    private double drawCharge(Minecraft mc) {
        return Math.min(1.0, mc.player.getTicksUsingItem() / 20.0);
    }

    /** Bisect the launch pitch against a tick simulation of the arrow path. */
    private float solvePitch(double horizontal, double dy, double speed) {
        float lo = -89f, hi = 89f;
        for (int i = 0; i < 26; i++) {
            float mid = (lo + hi) / 2;
            double reach = simulate(mid, speed, horizontal).y - dy;
            if (reach < 0) lo = mid;
            else hi = mid;
        }
        return -(lo + hi) / 2;
    }

    /**
     * Where the arrow is vertically once it has covered `horizontal` blocks.
     * The loop has to run until it reaches the target distance: returning on the
     * first step (x >= 0) left the whole drop compensation unused.
     */
    private Vec3 simulate(float pitchDeg, double speed, double horizontal) {
        double pitch = Math.toRadians(pitchDeg);
        double vx = Math.cos(pitch) * speed;
        double vy = Math.sin(pitch) * speed;
        double x = 0, y = 0;

        for (int tick = 0; tick < 120; tick++) {
            x += vx;
            y += vy;
            vy -= 0.05;
            vx *= 0.99;
            vy *= 0.99;
            if (x >= horizontal) return new Vec3(x, y, 0);
        }
        return new Vec3(x, y, 0);
    }

    private LivingEntity pick(Minecraft mc) {
        Vec3 eye = mc.player.getEyePosition();
        LivingEntity best = null;
        double bestScore = Double.MAX_VALUE;

        for (var entity : mc.level.entitiesForRendering()) {
            if (!(entity instanceof LivingEntity living) || living == mc.player) continue;
            if (!(living instanceof net.minecraft.world.entity.player.Player)) continue;
            if (living.getHealth() <= 0) continue;

            double dist = living.distanceTo(mc.player);
            if (dist > range.get()) continue;

            // Prefer what the crosshair is already near so aiming stays predictable.
            Vec3 to = living.position().subtract(eye).normalize();
            Vec3 look = mc.player.getLookAngle();
            double dot = to.dot(look);
            double score = (1.0 - dot) * 10 + dist * 0.1;
            if (score < bestScore) { bestScore = score; best = living; }
        }
        return best;
    }
}
