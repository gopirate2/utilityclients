// language: Java, file: Ignition.java, target: Fabric 26.2
package com.baggute.cheatclient.module.combat;

import net.minecraft.client.Minecraft;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.protocol.game.ServerboundMovePlayerPacket;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.item.enchantment.ItemEnchantments;
import net.minecraft.world.phys.Vec3;

import java.util.Locale;

/**
 * TNT minecart ignition.
 *
 * <p>A minecart only primes from an explosion or from a projectile that is
 * already on fire ({@code MinecartTNT.damageSourceIgnitesTnt}). Flint and steel
 * cannot do it (it only has {@code useOn}), so the reliable player-available
 * method is a Flame bow: the arrow is lit at release and the impact primes the
 * cart.
 */
final class Ignition {

    private Ignition() {}

    /** Hotbar slot with a bow (not a crossbow) carrying Flame, or -1. */
    static int flameBowSlot(Minecraft mc) {
        if (mc.player == null) return -1;
        for (int slot = 0; slot < 9; slot++) {
            ItemStack stack = mc.player.getInventory().getItem(slot);
            if (stack.isEmpty()) continue;
            String id = stack.getItem().toString().toLowerCase(Locale.ROOT);
            if (!id.endsWith("bow") || id.contains("crossbow")) continue;
            if (hasEnchantment(stack, Enchantments.FLAME)) return slot;
        }
        return -1;
    }

    static boolean hasEnchantment(ItemStack stack, net.minecraft.resources.ResourceKey<net.minecraft.world.item.enchantment.Enchantment> enchantment) {
        ItemEnchantments enchants = stack.get(DataComponents.ENCHANTMENTS);
        if (enchants == null) return false;
        for (var entry : enchants.entrySet()) {
            if (entry.getKey().is(enchantment) && entry.getIntValue() > 0) return true;
        }
        return false;
    }

    /** Points the client and the server at {@code point} before a projectile release. */
    static void aimServerSide(Minecraft mc, Vec3 point) {
        AimPipeline.snapTo(mc, point);
        if (mc.player != null && mc.player.connection != null) {
            mc.player.connection.send(new ServerboundMovePlayerPacket.Rot(
                    mc.player.getYRot(), mc.player.getXRot(),
                    mc.player.onGround(), mc.player.horizontalCollision));
        }
    }
}
