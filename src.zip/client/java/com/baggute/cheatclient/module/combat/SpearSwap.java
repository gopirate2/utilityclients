// language: Java, file: SpearSwap.java, target: Fabric 26.2
package com.baggute.cheatclient.module.combat;

import com.baggute.cheatclient.module.Category;
import com.baggute.cheatclient.module.Module;
import com.baggute.cheatclient.settings.BoolSetting;
import com.baggute.cheatclient.settings.IntSetting;
import com.baggute.cheatclient.settings.KeybindSetting;
import com.baggute.cheatclient.util.ModuleUtils;
import net.minecraft.client.Minecraft;
import net.minecraft.network.protocol.game.ServerboundMovePlayerPacket;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.Vec3;

import java.util.concurrent.ThreadLocalRandom;

/**
 * Swap-to-spear macro: selects the spear, hits on a timed tick, returns.
 *
 * <p>The old version hit on the very next tick after the swap and returned one
 * tick later. Against a real opponent that is a coin flip, not a combo: the
 * server applies the carried-item packet at a tick boundary, and an interaction
 * packet sent before that boundary resolves is evaluated against the item you
 * were holding when it arrived. Hitting two ticks after the swap is the earliest
 * point where the spear is reliably the weapon the server resolves the attack
 * with; anything faster is a plain hit with the old item that merely looks like a
 * spear hit on your screen.
 *
 * <p>Both waits are tick counts, not wall-clock sleeps, so they stay in step with
 * server ticks even under lag — a task that slept 100ms would drift against a
 * server that is applying its own tick boundaries.
 */
public final class SpearSwap extends Module {

    private final KeybindSetting activate =
            new KeybindSetting("Spear", "Swap, click, and return", -1, false);
    private final BoolSetting restore =
            new BoolSetting("restore", "Return to the previous item", true);
    private final IntSetting swapDelay = new IntSetting(
            "swapDelay", "Ticks between swap and hit", 2, 1, 5);
    private final IntSetting returnDelay = new IntSetting(
            "returnDelay", "Ticks after the hit before returning", 2, 1, 10);
    private final IntSetting missChance = new IntSetting(
            "missChance", "Chance to swing and miss (%)", 0, 0, 100);

    private int oldSlot = -1;
    /** Ticks left before the hit; -1 when no swap is pending. */
    private int swapTicks = -1;
    /** Ticks left before returning; -1 when nothing is pending. */
    private int returnTicks = -1;

    public SpearSwap() {
        super("SpearSwap", "Swaps to a spear, attacks once, and swaps back.", Category.COMBAT);
        addSetting(activate);
        addSetting(restore);
        addSetting(swapDelay);
        addSetting(returnDelay);
        addSetting(missChance);
    }

    @Override
    public void onRawKey(int key, int action) {
        if (action != 1 || !isEnabled()) return;
        if (activate.getKey() == -1 || key != activate.getKey()) return;
        // One macro at a time: re-pressing mid sequence would re-trigger the hit.
        if (swapTicks >= 0 || returnTicks >= 0) return;

        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.gameMode == null) return;
        if (mc.gui.screen() != null || mc.isPaused()) return;

        int slot = ModuleUtils.findHotbarItem(mc, "spear");
        if (slot < 0) return;

        oldSlot = mc.player.getInventory().getSelectedSlot();
        ModuleUtils.select(mc, slot);
        swapTicks = Math.max(1, swapDelay.get());
    }

    @Override
    public void onTick() {
        Minecraft mc = Minecraft.getInstance();

        if (swapTicks > 0) {
            swapTicks--;
            if (swapTicks == 0) {
                swapTicks = -1;
                hit(mc);
            }
            return;
        }

        if (returnTicks > 0) {
            returnTicks--;
            if (returnTicks == 0) {
                returnTicks = -1;
                restore(mc);
            }
        }
    }

    private void hit(Minecraft mc) {
        if (mc.player == null || mc.gameMode == null || mc.level == null) {
            restore(mc);
            return;
        }
        if (!ModuleUtils.matches(mc.player.getMainHandItem(), "spear")) {
            // The hotbar changed under us; never swing a different weapon.
            restore(mc);
            return;
        }

        if (rollMiss()) {
            // A real whiff: the swing plays, no entity is hit, nothing is sent.
            mc.player.swing(InteractionHand.MAIN_HAND);
            startReturn();
            return;
        }

        Entity target = null;
        if (mc.hitResult instanceof EntityHitResult hitResult && hitResult.getEntity().isAlive()) {
            target = hitResult.getEntity();
        }
        if (target == null) {
            target = AimPipeline.pickTarget(mc, mc.player.entityInteractionRange(), 80.0, null, false);
        }

        if (target != null) {
            Vec3 point = AimPipeline.closestPoint(target, mc.player.getEyePosition(1.0f), 0);
            float oldYaw = mc.player.getYRot();
            float oldPitch = mc.player.getXRot();

            AimPipeline.snapTo(mc, point);
            if (mc.player.connection != null) {
                mc.player.connection.send(new ServerboundMovePlayerPacket.Rot(
                        mc.player.getYRot(), mc.player.getXRot(),
                        mc.player.onGround(), mc.player.horizontalCollision));
            }
            mc.gameMode.attack(mc.player, target);
            AimPipeline.apply(mc, oldYaw, oldPitch);
        }

        mc.player.swing(InteractionHand.MAIN_HAND);
        startReturn();
    }

    private boolean rollMiss() {
        int chance = missChance.get();
        if (chance <= 0) return false;
        if (chance >= 100) return true;
        return ThreadLocalRandom.current().nextInt(100) < chance;
    }

    private void startReturn() {
        if (!restore.get()) {
            oldSlot = -1;
            return;
        }
        returnTicks = Math.max(1, returnDelay.get());
    }

    private void restore(Minecraft mc) {
        if (oldSlot >= 0 && mc.player != null
                && mc.player.getInventory().getSelectedSlot() != oldSlot) {
            ModuleUtils.select(mc, oldSlot);
        }
        oldSlot = -1;
        returnTicks = -1;
    }

    @Override
    protected void onDisable() {
        swapTicks = -1;
        returnTicks = -1;
        restore(Minecraft.getInstance());
    }
}
