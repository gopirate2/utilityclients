// language: Java, file: SmartWTap.java, target: Fabric 26.2
package com.baggute.cheatclient.module.combat;

import com.baggute.cheatclient.module.Category;
import com.baggute.cheatclient.module.Module;
import com.baggute.cheatclient.settings.BoolSetting;
import com.baggute.cheatclient.settings.DoubleSetting;
import com.baggute.cheatclient.settings.IntSetting;
import net.minecraft.client.Minecraft;
import net.minecraft.network.protocol.game.ServerboundPlayerCommandPacket;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;

/**
 * WTap: the sprint flag is what decides whether a hit knocks back. After each
 * landed hit this drops sprint for a tick and puts it back, so the next hit
 * arrives with sprint knockback again instead of the weaker follow-up.
 */
public class SmartWTap extends Module {

    private final IntSetting holdTicks;
    private final DoubleSetting range;
    private final BoolSetting playersOnly;

    private int cooldown = 0;
    private int restoreTicks = -1;

    public SmartWTap() {
        super("SmartWTap", "Breaks sprint after a landed hit so the next hit knocks back.", Category.COMBAT);

        this.holdTicks = new IntSetting("holdTicks", "Ticks to stay unsprinted", 1, 1, 5);
        this.range = new DoubleSetting("range", "Hit detection distance", 3.2, 1.0, 6.0);
        this.playersOnly = new BoolSetting("playersOnly", "Only react to players", true);

        addSetting(holdTicks);
        addSetting(range);
        addSetting(playersOnly);
    }

    @Override
    public void onTick() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null) return;
        if (mc.player.connection == null) return;

        if (restoreTicks >= 0) {
            if (--restoreTicks <= 0) {
                restoreTicks = -1;
                // STOP_SPRINTING cleared the flag above, so restore when it is off.
                if (!mc.player.isSprinting()) sendSprint(mc, true);
            }
            return;
        }

        if (cooldown > 0) { cooldown--; return; }

        // attackStrengthScale drops below 1 right after our own swing lands.
        if (mc.player.getAttackStrengthScale(0.5f) > 0.98f) return;
        if (!mc.options.keyAttack.isDown()) return;

        Entity target = nearest(mc);
        if (target == null) return;

        sendSprint(mc, false);
        restoreTicks = holdTicks.get() + 1;
        cooldown = 6;
    }

    private void sendSprint(Minecraft mc, boolean sprinting) {
        mc.player.setSprinting(sprinting);
        mc.player.connection.send(new ServerboundPlayerCommandPacket(
                mc.player,
                sprinting ? ServerboundPlayerCommandPacket.Action.START_SPRINTING
                        : ServerboundPlayerCommandPacket.Action.STOP_SPRINTING));
    }

    private Entity nearest(Minecraft mc) {
        double best = range.get() * range.get();
        Entity found = null;
        for (var entity : mc.level.entitiesForRendering()) {
            if (entity == mc.player) continue;
            if (playersOnly.get() && !(entity instanceof Player)) continue;
            if (!(entity instanceof net.minecraft.world.entity.LivingEntity living) || living.getHealth() <= 0) continue;
            double d = entity.distanceToSqr(mc.player);
            if (d < best) { best = d; found = entity; }
        }
        return found;
    }

    @Override
    protected void onEnable() {
        cooldown = 0;
        restoreTicks = -1;
    }

    @Override
    protected void onDisable() {
        cooldown = 0;
        restoreTicks = -1;
    }
}
