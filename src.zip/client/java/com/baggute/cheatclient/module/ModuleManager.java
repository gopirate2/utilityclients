// language: Java, file: ModuleManager.java, target: Fabric 26.2
package com.baggute.cheatclient.module;

import com.baggute.cheatclient.UtilityClient;
import com.baggute.cheatclient.module.combat.AimAssist;
import com.baggute.cheatclient.module.combat.Aimbot;
import com.baggute.cheatclient.module.combat.AntiMiss;
import com.baggute.cheatclient.module.combat.AutoClicker;
import com.baggute.cheatclient.module.combat.Reach;
import com.baggute.cheatclient.module.combat.AutoJumpReset;
import com.baggute.cheatclient.module.combat.AutoMace;
import com.baggute.cheatclient.module.combat.AutoPearlCatch;
import com.baggute.cheatclient.module.combat.AutoStunSlam;
import com.baggute.cheatclient.module.combat.KillAura;
import com.baggute.cheatclient.module.combat.ShieldBreaker;
import com.baggute.cheatclient.module.combat.Triggerbot;
import com.baggute.cheatclient.module.combat.AutoAnchor;
import com.baggute.cheatclient.module.combat.AutoBreachSwap;
import com.baggute.cheatclient.module.combat.AutoCart;
import com.baggute.cheatclient.module.combat.AutoCrystal;
import com.baggute.cheatclient.module.combat.AutoBucket;
import com.baggute.cheatclient.module.combat.AutoCrossbow;
import com.baggute.cheatclient.module.combat.AutoInstacart;
import com.baggute.cheatclient.module.combat.AutoWeb;
import com.baggute.cheatclient.module.combat.AutoXBowCart;
import com.baggute.cheatclient.module.combat.BowAimbot;
import com.baggute.cheatclient.module.combat.HitSelect;
import com.baggute.cheatclient.module.combat.SmartWTap;
import com.baggute.cheatclient.module.combat.SpearSwap;
import com.baggute.cheatclient.module.combat.WebDrain;
import com.baggute.cheatclient.module.apex.ApexModules;
import com.baggute.cheatclient.module.misc.Debug;
import com.baggute.cheatclient.module.misc.Hud;
import com.baggute.cheatclient.module.misc.Panic;
import com.baggute.cheatclient.module.misc.Notifications;
import com.baggute.cheatclient.module.misc.PresetSwitch;
import com.baggute.cheatclient.module.misc.SeedCrackerX;
import com.baggute.cheatclient.module.player.AutoTotem;
import com.baggute.cheatclient.module.player.CartGrabber;
import com.baggute.cheatclient.module.player.MouseTweaks;
import com.baggute.cheatclient.module.player.Zoom;
import com.baggute.cheatclient.module.movement.Flight;
import com.baggute.cheatclient.module.movement.NoFall;
import com.baggute.cheatclient.module.movement.Speed;
import com.baggute.cheatclient.module.movement.StepUp;
import com.baggute.cheatclient.module.movement.WaterWalk;
import com.baggute.cheatclient.module.render.ArrayListModule;
import com.baggute.cheatclient.module.render.BlockESP;
import com.baggute.cheatclient.module.render.ESP;
import com.baggute.cheatclient.module.render.Freecam;
import com.baggute.cheatclient.module.render.Fullbright;
import com.baggute.cheatclient.module.render.StorageESP;
import com.baggute.cheatclient.module.render.ArmorIndicators;
import com.baggute.cheatclient.module.render.HealthIndicators;
import com.baggute.cheatclient.module.render.Nametags;
import com.baggute.cheatclient.module.render.TargetHud;
import com.baggute.cheatclient.module.render.Trajectory;
import com.baggute.cheatclient.module.automation.AutoEat;
import com.baggute.cheatclient.module.automation.AutoMine;
import com.baggute.cheatclient.module.automation.AutoPot;
import com.baggute.cheatclient.module.automation.AutoWalk;
import com.baggute.cheatclient.module.automation.Baritone;
import com.baggute.cheatclient.settings.KeybindSetting;
import com.baggute.cheatclient.settings.Setting;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;

public class ModuleManager {

    private final List<Module> modules = new ArrayList<>();
    private final Map<Category, List<Module>> byCategory = new EnumMap<>(Category.class);

    public void init() {
        for (Category c : Category.values()) byCategory.put(c, new ArrayList<>());

        // ---- COMBAT ----
        register(new Triggerbot());
        register(new AutoClicker());
        register(new AimAssist());
        register(new Aimbot());
        register(new AntiMiss());
        register(new Reach());
        register(new ShieldBreaker());
        register(new AutoPearlCatch());
        register(new AutoJumpReset());
        register(new AutoMace());
        register(new AutoStunSlam());
        register(new KillAura());
        register(new AutoCrossbow());
        register(new AutoInstacart());
        register(new SpearSwap());
        register(new AutoBucket());
        register(new WebDrain());
        register(new AutoWeb());
        register(new AutoBreachSwap());
        register(new AutoCrystal());
        register(new AutoAnchor());
        register(new AutoCart());
        register(new AutoXBowCart());

        // ---- AUTOMATION ----
        register(new AutoWalk());
        register(new AutoMine());
        register(new AutoPot());
        register(new AutoEat());
        register(new Baritone());

        // ---- MOVEMENT ----
        register(new Flight());
        register(new Speed());
        register(new StepUp());
        register(new WaterWalk());
        register(new NoFall());

        // ---- PLAYER ----
        register(new AutoTotem());
        register(new CartGrabber());
        register(new MouseTweaks());
        register(new Zoom());

        // ---- RENDER ----
        register(new ESP());
        register(new ArrayListModule());
        register(new Notifications());
        register(new BlockESP());
        register(new StorageESP());
        register(new Fullbright());
        register(new Freecam());
        register(new HealthIndicators());
        register(new ArmorIndicators());

        // ---- MISC ----
        register(new Hud());
        register(new PresetSwitch());
        register(new SeedCrackerX());

        register(new Debug());
        register(new Panic());
        register(new HitSelect());
        register(new SmartWTap());
        register(new BowAimbot());
        register(new Nametags());
        register(new TargetHud());
        register(new Trajectory());

        // ---- APEX IMPORT (labels only, tab: skidded off apex) ----
        for (Module apex : ApexModules.createAll()) register(apex);
    }

    private void register(Module module) {
        // A duplicate name breaks getByName, the config keys and the HUD list, so
        // the first module to claim a name keeps it and the import is dropped.
        for (Module existing : modules) {
            if (existing.getName().equalsIgnoreCase(module.getName())) {
                UtilityClient.LOGGER.warn("[ModuleManager] duplicate module '{}' ignored", module.getName());
                return;
            }
        }
        ensureKeybind(module);
        modules.add(module);
        byCategory.get(module.getCategory()).add(module);
    }

    private void ensureKeybind(Module m) {
        for (Setting s : m.getSettings()) if (s instanceof KeybindSetting ks && "keybind".equals(ks.getName())) return;
        m.insertSetting(0, new KeybindSetting("keybind", "Toggle keybind", -1, false));
    }

    private KeybindSetting getKeybind(Module m) {
        for (Setting s : m.getSettings()) if (s instanceof KeybindSetting ks && "keybind".equals(ks.getName())) return ks;
        return null;
    }

    private boolean hasSecondaryKey(Module m, int keyCode) {
        for (Setting s : m.getSettings()) {
            if (s instanceof KeybindSetting ks && !"keybind".equals(ks.getName()) && ks.getKey() == keyCode) return true;
        }
        return false;
    }

    public void onTick() {
        for (Module m : modules) {
            if (m.isEnabled()) {
                try { m.onTick(); }
                catch (Throwable t) {
                    UtilityClient.LOGGER.error("[ModuleManager] {} tick failed", m.getName(), t);
                }
            }
        }
    }

    public void onRenderFrame(float partialTick) {
        for (Module m : modules) {
            if (m.isEnabled()) {
                try { m.onRenderFrame(partialTick); }
                catch (Throwable t) {
                    UtilityClient.LOGGER.error("[ModuleManager] {} render frame failed", m.getName(), t);
                }
            }
        }
    }

    public void onKey(int keyCode, int action) {
        for (Module m : modules) {
            KeybindSetting ks = getKeybind(m);
            if (ks == null || ks.getKey() == -1 || ks.getKey() != keyCode) continue;

            if (ks.isHeld()) {
                // Held binds follow the key: down means on, release means off.
                if (action == GLFW.GLFW_PRESS) m.setEnabledHeld(true);
                else if (action == GLFW.GLFW_RELEASE) m.setEnabledHeld(false);
            } else if (action == GLFW.GLFW_PRESS) {
                m.toggle();
            }
        }
        // Secondary binds reach every module, enabled or not: Panic and PresetSwitch
        // exist precisely to act when nothing else is on, so gating them on enabled
        // state made them dead keys.
        for (Module m : modules) {
            if (hasSecondaryKey(m, keyCode)) m.onRawKey(keyCode, action);
        }
        for (Module m : modules) {
            if (m.isEnabled()) {
                try { m.onKey(keyCode, action); }
                catch (Throwable t) {
                    UtilityClient.LOGGER.error("[ModuleManager] {} key handler failed", m.getName(), t);
                }
            }
        }
    }

    /**
     * Keys that must work regardless of an open screen (the panic switch).
     *
     * @return true when the key was consumed
     */
    public boolean onGlobalKey(int keyCode, int action) {
        for (Module m : modules) {
            if (m instanceof Panic panic && panic.tryTrigger(keyCode, action)) return true;
        }
        return false;
    }

    public List<Module> getModules() { return modules; }

    /**
     * Modules already bound to this key, primary or secondary. Empty means the bind
     * is clean.
     */
    public List<Module> getKeyConflicts(int keyCode, Module self) {
        List<Module> out = new ArrayList<>();
        if (keyCode == -1 || keyCode == GLFW.GLFW_KEY_UNKNOWN) return out;
        for (Module m : modules) {
            if (m == self) continue;
            KeybindSetting primary = getKeybind(m);
            if (primary != null && primary.getKey() == keyCode) { out.add(m); continue; }
            for (Setting s : m.getSettings()) {
                if (s instanceof KeybindSetting k && !"keybind".equals(k.getName()) && k.getKey() == keyCode) {
                    out.add(m);
                    break;
                }
            }
        }
        return out;
    }

    public List<Module> getByCategory(Category category) {
        return byCategory.computeIfAbsent(category, k -> new ArrayList<>());
    }

    public Module getByName(String name) {
        for (Module m : modules) if (m.getName().equalsIgnoreCase(name)) return m;
        return null;
    }

    /**
     * Every module that currently has at least one key bound, primary or
     * secondary. The BINDS tab used to look only at the toggle key, which hid
     * action binds like Panic, preset cycling or the spear macro.
     */
    public List<Module> getBoundModules() {
        List<Module> out = new ArrayList<>();
        for (Module m : modules) {
            if (!getBoundKeys(m).isEmpty()) out.add(m);
        }
        out.sort((a, b) -> a.getName().compareToIgnoreCase(b.getName()));
        return out;
    }

    /** Non-default keybind settings on a module, primary toggle first. */
    public List<KeybindSetting> getBoundKeys(Module module) {
        List<KeybindSetting> out = new ArrayList<>();
        for (Setting s : module.getSettings()) {
            if (s instanceof KeybindSetting k
                    && k.getKey() != -1 && k.getKey() != GLFW.GLFW_KEY_UNKNOWN) {
                out.add(k);
            }
        }
        return out;
    }

    public Module getByKey(int keyCode) {
        // -1 (and GLFW's unknown key) means "unbound"; every module defaults to it,
        // so matching on it would return the first module in the list.
        if (keyCode == -1 || keyCode == GLFW.GLFW_KEY_UNKNOWN) return null;
        for (Module m : modules) {
            KeybindSetting ks = getKeybind(m);
            if (ks != null && ks.getKey() == keyCode) return m;
        }
        return null;
    }

    // ---- typed accessors ----

    public ESP getESP() { return (ESP) getByName("ESP"); }
    public BlockESP getBlockESP() { return (BlockESP) getByName("BlockESP"); }
    public StorageESP getStorageESP() { return (StorageESP) getByName("StorageESP"); }
    public Triggerbot getTriggerbot() { return (Triggerbot) getByName("Triggerbot"); }
    public AimAssist getAimAssist() { return (AimAssist) getByName("AimAssist"); }
    public ShieldBreaker getShieldBreaker() { return (ShieldBreaker) getByName("ShieldBreaker"); }
    public AutoPearlCatch getAutoPearlCatch() { return (AutoPearlCatch) getByName("AutoPearlCatch"); }
    public AutoJumpReset getAutoJumpReset() { return (AutoJumpReset) getByName("AutoJumpReset"); }
    public AutoMace getAutoMace() { return (AutoMace) getByName("AutoMace"); }
    public AutoStunSlam getAutoStunSlam() { return (AutoStunSlam) getByName("AutoStunSlam"); }
    public KillAura getKillAura() { return (KillAura) getByName("KillAura"); }
    public Fullbright getFullbright() { return (Fullbright) getByName("Fullbright"); }
    public Freecam getFreecam() { return (Freecam) getByName("Freecam"); }
    public Flight getFlight() { return (Flight) getByName("Flight"); }
    public Speed getSpeed() { return (Speed) getByName("Speed"); }
    public StepUp getStepUp() { return (StepUp) getByName("StepUp"); }
    public WaterWalk getWaterWalk() { return (WaterWalk) getByName("WaterWalk"); }
    public NoFall getNoFall() { return (NoFall) getByName("NoFall"); }
    public Hud getHud() { return (Hud) getByName("Hud"); }
    public SeedCrackerX getSeedCrackerX() { return (SeedCrackerX) getByName("SeedCrackerX"); }
}
