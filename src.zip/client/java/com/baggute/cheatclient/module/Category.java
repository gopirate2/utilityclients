package com.baggute.cheatclient.module;

public enum Category {
    COMBAT("Combat"),
    AUTOMATION("Automation"),
    MOVEMENT("Movement"),
    PLAYER("Player"),
    RENDER("Render"),
    WORLD("World"),
    MISC("Misc"),
    EXPLOITS("Exploits"),
    ENABLED("Enabled"),
    BINDS("Binds"),
    APEX("skidded off apex");

    private final String displayName;

    Category(String displayName) {
        this.displayName = displayName;
    }

    public String getDisplayName() {
        return displayName;
    }
}
