// language: Java, file: WaterWalk.java, target: Fabric 26.2
package com.baggute.cheatclient.module.movement;

import com.baggute.cheatclient.UtilityClient;
import com.baggute.cheatclient.module.Category;
import com.baggute.cheatclient.module.Module;
import com.baggute.cheatclient.settings.BoolSetting;
import com.baggute.cheatclient.settings.DoubleSetting;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.tags.FluidTags;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;

public class WaterWalk extends Module {

    private final DoubleSetting hoverHeight;
    private final BoolSetting lavaToo;
    private final BoolSetting forceSprint;

    public WaterWalk() {
        super("WaterWalk", "Walk on top of water.", Category.MOVEMENT);
        this.hoverHeight = new DoubleSetting("hoverHeight", "Height above surface", 0.0, 0.0, 0.4);
        this.lavaToo     = new BoolSetting("lavaToo", "Also walk on lava", false);
        this.forceSprint = new BoolSetting("forceSprint", "Force sprint on water", true);
        addSetting(hoverHeight);
        addSetting(lavaToo);
        addSetting(forceSprint);
    }

    @Override
    public void onTick() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null) return;

        // Find the fluid we're standing on — only check feet level, not above.
        BlockPos feet = mc.player.blockPosition();
        BlockState feetState = mc.level.getBlockState(feet);
        boolean feetWater = feetState.getFluidState().is(FluidTags.WATER);
        boolean feetLava = lavaToo.get() && feetState.getFluidState().is(FluidTags.LAVA);

        if (!feetWater && !feetLava) {
            // Feet in air (we've hovered above the surface). Look one block below.
            BlockPos below = feet.below();
            BlockState belowState = mc.level.getBlockState(below);
            boolean belowWater = belowState.getFluidState().is(FluidTags.WATER);
            boolean belowLava = lavaToo.get() && belowState.getFluidState().is(FluidTags.LAVA);
            if (!belowWater && !belowLava) return;    // not near water at all
            feet = below;
        }

        // Source water is 0.8888 blocks tall. Standing at fluidY + 0.8888 +
        // hoverHeight puts us right on the surface, not a quarter-block above.
        double surfaceY = feet.getY() + 0.8888 + hoverHeight.get();

        Vec3 pos = mc.player.position();
        Vec3 vel = mc.player.getDeltaMovement();

        // Snap position hard to surface every tick. Because we ALSO set onGround
        // below, vanilla skips gravity next tick — no oscillation, no bob.
        if (Math.abs(pos.y - surfaceY) > 0.001) {
            mc.player.setPos(pos.x, surfaceY, pos.z);
        }

        // Kill vertical velocity — prevents any residual bob from vanilla physics.
        if (vel.y != 0) {
            mc.player.setDeltaMovement(vel.x, 0, vel.z);
        }

        // This is what stops gravity from pulling us back under next tick.
        mc.player.setOnGround(true);
        mc.player.fallDistance = 0.0f;

        if (forceSprint.get() && !mc.player.isSprinting()) {
            mc.player.setSprinting(true);
        }
    }

    @Override
    protected void onEnable() {
        UtilityClient.LOGGER.info("[WaterWalk] enabled");
    }
    @Override
    protected void onDisable() {
        UtilityClient.LOGGER.info("[WaterWalk] disabled");
    }
}