// language: Java, file: NoFall.java, target: Fabric 26.2
package com.baggute.cheatclient.module.movement;

import com.baggute.cheatclient.UtilityClient;
import com.baggute.cheatclient.module.Category;
import com.baggute.cheatclient.module.Module;
import net.minecraft.client.Minecraft;
import net.minecraft.network.protocol.game.ServerboundMovePlayerPacket;

public class NoFall extends Module {

    public NoFall() {
        super("NoFall", "Prevents fall damage.", Category.MOVEMENT);
    }

    @Override
    public void onTick() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.getConnection() == null) return;

        if (mc.player.onGround()) return;
        if (mc.player.getAbilities().flying) return;
        if (mc.player.isFallFlying() || mc.player.isInWater() || mc.player.isInLava()) return;
        if (mc.player.getDeltaMovement().y >= 0) return;
        // Only once a real fall is building: one spoof every airborne tick is a
        // louder anticheat signal than a few packets near the damage threshold.
        if (mc.player.fallDistance < 2.0f) return;

        // Claims the ground the same tick so the server clears its fall tracker.
        // Report the actual horizontal collision state instead of always false.
        mc.getConnection().send(new ServerboundMovePlayerPacket.StatusOnly(
                true, mc.player.horizontalCollision));
    }

    @Override
    protected void onEnable() {
        UtilityClient.LOGGER.info("[NoFall] enabled (packet-based)");
    }
    @Override
    protected void onDisable() {
        UtilityClient.LOGGER.info("[NoFall] disabled");
    }
}