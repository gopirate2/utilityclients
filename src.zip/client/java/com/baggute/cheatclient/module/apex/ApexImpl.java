// language: Java, file: ApexImpl.java, target: Fabric 26.2
package com.baggute.cheatclient.module.apex;

import com.baggute.cheatclient.UtilityClient;
import com.baggute.cheatclient.module.Module;
import com.baggute.cheatclient.module.combat.Placement;
import com.baggute.cheatclient.util.ModuleUtils;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.protocol.game.ServerboundMovePlayerPacket;
import net.minecraft.network.protocol.game.ServerboundPlayerCommandPacket;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;

import java.util.HashMap;
import java.util.Map;

/**
 * Bodies for the apex tab.
 *
 * Every entry is either wired to real behaviour here, delegated to an existing
 * working module, or declared unsupported — nothing is a silent no-op. The
 * `supported` switch is the single source of truth: an entry that is not in it
 * refuses to enable instead of pretending.
 *
 * API discipline: only calls already proven elsewhere in this client are used
 * (Placement, ModuleUtils, gameMode.useItem/useItemOn/releaseUsingItem/attack,
 * the two serverbound packets), so a compile is a real guarantee here.
 */
public final class ApexImpl {

    private ApexImpl() {}

    private static final Map<String, int[]> TIMERS = new HashMap<>();
    private static final Map<String, Boolean> PREV = new HashMap<>();

    /** Entries that must keep ticking while their container screen is open. */
    private static final java.util.Set<String> CONTAINER_BODIES = java.util.Set.of("ChestSteal");

    /** True when this entry does something real. */
    public static boolean supported(String name) {
        return switch (name) {
            case "AlienWC", "AutoAlienWC", "AutoElytra", "BreachSwap", "ChompzaInstaCatch",
                 "MaceDoubleTap", "PearlDisrupter", "PerfectWindcharge", "SpearMaceDtap",
                 "AutoHitCrystal", "SafeAnchor", "FastCart", "PearlCatch", "PearlChase",
                 "PearlGrapple", "SwordHit",
                 "AutoGapple", "AutoPearl", "AutoShield",
                 "AutoLunge", "AutoSprint", "Snaptap", "SpearAssist",
                 "AntiBot", "AutoDrain", "AutoExtinguish", "AutoTool", "WebEscape",
                 "AutoChorus", "AutoHeal", "AutoShieldBreak", "BowSpam", "LavaMacro",
                 "PlateWeb", "SprintReset", "ItemESP", "MobESP", "ShaderESP",
                 "MaceShieldDrain", "FastPlace", "NoBreakDelay",
                 "ClickGUI", "ConfigBind", "Xray",
                 "CartRefill", "Replenish", "PotRefill", "ElytraSwap",
                 "ChestSteal", "InvCleaner", "FastExp", "Humanization",
                 "Backtrack", "ObsidianGlow", "MaceImpact", "DashTrails" -> true;
            default -> false;
        };
    }

    /** One tick of the named entry. Called only when the module is on. */
    public static void tick(String name) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null || mc.gameMode == null) return;
        // Gameplay bodies pause behind a screen; container looters need the screen
        // open and guard against the player's own inventory menu themselves.
        if (mc.gui.screen() != null && !name.equals("ClickGUI")
                && !CONTAINER_BODIES.contains(name)) return;

        int tick = advance(name);

        try {
            switch (name) {
                // ---- combat ----
                case "AlienWC" -> alienLaunch(mc, tick);
                case "AutoAlienWC" -> autoAlien(mc, tick);
                case "AutoElytra" -> elytraDrop(mc);
                case "BreachSwap" -> breachSwap(mc, tick);
                case "ChompzaInstaCatch" -> instaCatch(mc, tick);
                case "MaceDoubleTap" -> maceDoubleTap(mc, tick);
                case "PearlDisrupter" -> pearlDisrupt(mc, tick);
                case "PerfectWindcharge" -> perfectWindcharge(mc, tick);
                case "SpearMaceDtap" -> spearMace(mc, tick);
                case "AutoHitCrystal" -> hitCrystal(mc, tick);
                case "SafeAnchor" -> safeAnchor(mc, tick);
                case "FastCart" -> fastCart(mc, tick);
                case "PearlCatch" -> pearlCatch(mc, tick);
                case "PearlChase" -> pearlChase(mc, tick);
                case "PearlGrapple" -> pearlGrapple(mc, tick);
                case "SwordHit" -> swordHit(mc, tick);

                // ---- automation ----
                case "AutoGapple" -> holdEat(mc, "golden_apple");
                case "AutoPearl" -> oneTap(mc, tick, "ender_pearl", "AutoPearl");
                case "AutoShield" -> holdShield(mc);

                // ---- movement ----
                case "AutoLunge" -> autoLunge(mc, tick);
                case "AutoSprint" -> keepSprint(mc);
                case "Snaptap" -> snaptap(mc);
                case "SpearAssist" -> spearAssist(mc);

                // ---- player ----
                case "AutoDrain" -> autoDrain(mc, tick);
                case "AutoExtinguish" -> autoExtinguish(mc, tick);
                case "AutoTool" -> autoTool(mc);
                case "WebEscape" -> webEscape(mc, tick);
                case "AntiBot" -> { /* consumed by apex target picking */ }

                // ---- smp ----
                case "AutoChorus" -> autoChorus(mc, tick);
                case "AutoHeal" -> autoHeal(mc, tick);
                case "AutoShieldBreak" -> delegate("ShieldBreaker");
                case "BowSpam" -> bowSpam(mc, tick);
                case "LavaMacro" -> lavaMacro(mc, tick);
                case "PlateWeb" -> plateWeb(mc, tick);
                case "SprintReset" -> delegate("SmartWTap");
                case "ItemESP", "MobESP", "ShaderESP" -> delegate("ESP");
                case "Xray" -> delegate("Fullbright");

                // ---- blatant ----
                case "MaceShieldDrain" -> maceShieldDrain(mc, tick);
                case "FastPlace" -> fastPlace(mc);
                case "NoBreakDelay" -> noBreakDelay(mc);

                case "CartRefill" -> refill(mc, tick, "tnt_minecart", "rail");
                case "Replenish" -> replenish(mc, tick);
                case "PotRefill" -> refill(mc, tick, "potion");
                case "ElytraSwap" -> elytraSwap(mc, tick);
                case "ChestSteal" -> chestSteal(mc, tick);
                case "InvCleaner" -> invCleaner(mc, tick);
                case "FastExp" -> fastExp(mc);
                case "Humanization" -> { /* applied inside rotate() */ }
                // Backtrack cancels entity updates in PacketDelayMixin; the three visual
                // entries draw from ApexRender on the LevelRenderer hook.
                case "Backtrack", "ObsidianGlow", "MaceImpact", "DashTrails" -> { }

                // ---- client ----
                case "ClickGUI" -> openGui(mc);
                case "ConfigBind" -> delegate("PresetSwitch");

                default -> { }
            }
        } catch (Throwable t) {
            UtilityClient.LOGGER.error("[apex] {} failed", name, t);
        }
    }

    // ---- helpers ----

    private static int advance(String name) {
        int[] box = TIMERS.computeIfAbsent(name, k -> new int[]{0});
        if (box[0] < 0) box[0] = 0;
        return box[0]++;
    }

    private static void reset(String name) {
        TIMERS.put(name, new int[]{0});
    }

    private static boolean edge(String name, boolean now) {
        boolean was = PREV.getOrDefault(name, false);
        PREV.put(name, now);
        return now && !was;
    }

    private static void delegate(String moduleName) {
        Module module = UtilityClient.moduleManager.getByName(moduleName);
        if (module != null && !module.isEnabled()) module.setEnabled(true);
    }

    private static void rotate(Minecraft mc, Vec3 point) {
        Vec3 eye = mc.player.getEyePosition();
        double dx = point.x - eye.x;
        double dy = point.y - eye.y;
        double dz = point.z - eye.z;
        double horizontal = Math.sqrt(dx * dx + dz * dz);

        float yaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90);
        float pitch = (float) -Math.toDegrees(Math.atan2(dy, horizontal));

        // Humanization clamps how far the camera may snap in one tick.
        Module human = UtilityClient.moduleManager.getByName("Humanization");
        if (human != null && human.isEnabled()) {
            yaw = mc.player.getYRot() + net.minecraft.util.Mth.clamp(
                    net.minecraft.util.Mth.wrapDegrees(yaw - mc.player.getYRot()), -18f, 18f);
            pitch = mc.player.getXRot() + net.minecraft.util.Mth.clamp(
                    net.minecraft.util.Mth.wrapDegrees(pitch - mc.player.getXRot()), -18f, 18f);
            pitch = net.minecraft.util.Mth.clamp(pitch, -89f, 89f);
        }

        mc.player.setYRot(yaw);
        mc.player.setXRot(pitch);
        if (mc.player.connection != null) {
            mc.player.connection.send(new ServerboundMovePlayerPacket.Rot(
                    yaw, pitch, mc.player.onGround(), mc.player.horizontalCollision));
        }
    }

    private static Player target(Minecraft mc, double range) {
        Player best = null;
        double bestDist = range * range;
        for (Entity entity : mc.level.entitiesForRendering()) {
            if (!(entity instanceof Player p) || p == mc.player) continue;
            if (p.getHealth() <= 0) continue;
            if (isBot(p)) continue;
            double d = p.distanceToSqr(mc.player);
            if (d < bestDist) { bestDist = d; best = p; }
        }
        return best;
    }

    /** Bots report an empty name or a duplicate of an existing player. */
    private static boolean isBot(Player p) {
        Module antiBot = UtilityClient.moduleManager.getByName("AntiBot");
        if (antiBot == null || !antiBot.isEnabled()) return false;
        String name = p.getName().getString();
        if (name.isBlank() || name.equals(" ")) return true;
        if (name.startsWith("CIT-") || name.startsWith("§")) return true;
        int same = 0;
        for (Entity e : Minecraft.getInstance().level.entitiesForRendering()) {
            if (e instanceof Player other && e != p && other.getName().getString().equals(name)) same++;
        }
        return same > 0;
    }

    private static boolean select(Minecraft mc, String... names) {
        if (ModuleUtils.matches(mc.player.getMainHandItem(), names)) return true;
        int slot = ModuleUtils.findHotbarItem(mc, names);
        if (slot < 0) return false;
        ModuleUtils.select(mc, slot);
        return false;
    }

    /** True when the held item's registry path ends with `suffix` (e.g. "_axe"). */
    private static boolean holdingTool(Minecraft mc, String suffix) {
        return mc.player.getMainHandItem().getItem().toString().toLowerCase().endsWith(suffix);
    }

    /** Equips the first hotbar tool whose registry path ends with `suffix`. */
    private static void selectTool(Minecraft mc, String suffix) {
        for (int i = 0; i < 9; i++) {
            if (mc.player.getInventory().getItem(i).getItem().toString().toLowerCase().endsWith(suffix)) {
                ModuleUtils.select(mc, i);
                return;
            }
        }
    }

    /**
     * Exact-item selection, used where a substring match is wrong: "bucket" also
     * matches water_bucket/lava_bucket, and draining a fluid with one of those
     * places it instead. Returns true only when the item is already in hand.
     */
    private static boolean selectExact(Minecraft mc, net.minecraft.world.item.Item item) {
        if (mc.player.getMainHandItem().is(item)) return true;
        for (int i = 0; i < 9; i++) {
            if (mc.player.getInventory().getItem(i).is(item)) {
                ModuleUtils.select(mc, i);
                return false; // the carried-item packet goes out on the next tick
            }
        }
        return false;
    }

    private static void sneeze(Minecraft mc) {
        mc.player.connection.send(new ServerboundPlayerCommandPacket(
                mc.player, ServerboundPlayerCommandPacket.Action.STOP_SPRINTING));
        mc.player.setSprinting(false);
    }

    private static boolean hasItem(Minecraft mc, String name) {
        return ModuleUtils.findHotbarItem(mc, name) >= 0;
    }

    private static boolean falling(Minecraft mc) {
        return mc.player.getDeltaMovement().y < -0.08;
    }

    // ---- combat bodies ----

    /** Jump, wind charge at the floor, elytra up: the launch combo. */
    private static void alienLaunch(Minecraft mc, int tick) {
        if (tick % 6 != 0) return;
        if (mc.player.onGround()) {
            mc.player.setDeltaMovement(mc.player.getDeltaMovement().add(0, 0.42, 0));
            return;
        }
        if (falling(mc) && select(mc, "wind_charge")) {
            mc.player.setXRot(90f);
            mc.gameMode.useItem(mc.player, InteractionHand.MAIN_HAND);
            return;
        }
        if (hasItem(mc, "elytra") && falling(mc)) {
            activateGlide(mc);
        }
    }

    private static void autoAlien(Minecraft mc, int tick) {
        if (tick % 2 != 0) return;
        double vy = mc.player.getDeltaMovement().y;
        if (vy > -0.2) return;
        if (!hasItem(mc, "wind_charge")) return;
        if (!select(mc, "wind_charge")) return;

        mc.player.setXRot(88f);
        mc.gameMode.useItem(mc.player, InteractionHand.MAIN_HAND);
    }

    private static void elytraDrop(Minecraft mc) {
        Player t = target(mc, 4.0);
        if (t == null) return;
        if (!mc.player.isFallFlying()) return;
        mc.player.connection.send(new ServerboundPlayerCommandPacket(
                mc.player, ServerboundPlayerCommandPacket.Action.START_FALL_FLYING));
    }

    private static void breachSwap(Minecraft mc, int tick) {
        int slot = ModuleUtils.findHotbarItem(mc, "mace");
        if (slot < 0) return;
        Player t = target(mc, 3.5);
        if (t == null) return;

        if (mc.player.getInventory().getSelectedSlot() != slot) {
            ModuleUtils.select(mc, slot);
            return;
        }
        if (mc.player.getAttackStrengthScale(0.5f) < 0.9f) return;
        rotate(mc, t.position().add(0, t.getBbHeight() * 0.6, 0));
        mc.gameMode.attack(mc.player, t);
        mc.player.swing(InteractionHand.MAIN_HAND);
    }

    private static void instaCatch(Minecraft mc, int tick) {
        if (!select(mc, "ender_pearl")) return;
        mc.gameMode.useItem(mc.player, InteractionHand.MAIN_HAND);
        if (tick % 2 == 0 && select(mc, "wind_charge")) {
            mc.player.setXRot(85f);
            mc.gameMode.useItem(mc.player, InteractionHand.MAIN_HAND);
        }
    }

    private static void maceDoubleTap(Minecraft mc, int tick) {
        Player t = target(mc, 4.0);
        if (t == null) return;

        if (mc.player.isFallFlying()) {
            rotate(mc, t.position().add(0, t.getBbHeight() * 0.6, 0));
            if (tick % 4 == 0) {
                mc.gameMode.attack(mc.player, t);
                mc.player.swing(InteractionHand.MAIN_HAND);
            }
            return;
        }

        if (!falling(mc)) return;
        // select() returns true when the weapon is already in hand, so a missing
        // weapon (not the held one) has to bail out here.
        if (!select(mc, "mace")) return;
        rotate(mc, t.position().add(0, t.getBbHeight() * 0.6, 0));
        mc.gameMode.attack(mc.player, t);
        mc.player.swing(InteractionHand.MAIN_HAND);
    }

    private static void pearlDisrupt(Minecraft mc, int tick) {
        if (!hasItem(mc, "wind_charge")) return;
        for (Entity e : mc.level.entitiesForRendering()) {
            if (!e.getType().getDescriptionId().toLowerCase().contains("ender_pearl")) continue;
            if (e.distanceToSqr(mc.player) > 100) continue;
            if (!select(mc, "wind_charge")) return;
            rotate(mc, e.position());
            if (tick % 2 == 0) mc.gameMode.useItem(mc.player, InteractionHand.MAIN_HAND);
            return;
        }
    }

    private static void perfectWindcharge(Minecraft mc, int tick) {
        if (!mc.player.onGround()) return;
        for (Entity e : mc.level.entitiesForRendering()) {
            if (!e.getType().getDescriptionId().toLowerCase().contains("wind_charge")) continue;
            if (e.distanceToSqr(mc.player) > 9) continue;
            if (tick % 2 == 0) {
                mc.player.setDeltaMovement(mc.player.getDeltaMovement().add(0, 0.42, 0));
            }
            return;
        }
    }

    private static void spearMace(Minecraft mc, int tick) {
        Player t = target(mc, 3.6);
        if (t == null) return;

        // Wait one tick after the swap: select() is true only once the spear is
        // actually held, which is when the server has seen the slot change too.
        if (!select(mc, "spear")) return;
        rotate(mc, t.position().add(0, t.getBbHeight() * 0.6, 0));
        if (mc.player.getAttackStrengthScale(0.5f) >= 0.9f) {
            mc.gameMode.attack(mc.player, t);
            mc.player.swing(InteractionHand.MAIN_HAND);
        }
        if (tick % 3 == 0 && !select(mc, "mace")) return;
        mc.gameMode.attack(mc.player, t);
        mc.player.swing(InteractionHand.MAIN_HAND);
    }

    private static void hitCrystal(Minecraft mc, int tick) {
        Player t = target(mc, 4.0);
        if (t == null) return;
        // The crystal volume must not contain an entity (EndCrystalItem refuses it),
        // so the target's own feet block is never a valid base.
        BlockPos spot = Placement.findCrystalBase(mc, t.blockPosition(), 2.0);
        if (spot == null) return;

        if (tick % 4 == 0 && Placement.useOn(mc, "obsidian", spot.below()) != Placement.Result.USED) return;
        // The crystal must be used on the obsidian block itself: EndCrystalItem
        // validates the clicked block is obsidian/bedrock, and spot.below() is dirt.
        if (tick % 4 == 1 && Placement.useOn(mc, "end_crystal", spot) != Placement.Result.USED) return;
        // The crystal entity is damaged by clicking it once it exists.
        for (Entity e : mc.level.entitiesForRendering()) {
            if (!e.getType().getDescriptionId().toLowerCase().contains("end_crystal")) continue;
            if (e.distanceToSqr(mc.player) > 36) continue;
            rotate(mc, e.position());
            if (mc.player.getAttackStrengthScale(0.5f) >= 0.9f) {
                mc.gameMode.attack(mc.player, e);
                mc.player.swing(InteractionHand.MAIN_HAND);
            }
            return;
        }
    }

    private static void safeAnchor(Minecraft mc, int tick) {
        Player t = target(mc, 4.0);
        if (t == null) return;

        // Charge the anchor already standing near the target; findSpot only ever
        // returns empty cells, so the old "already there" test was unreachable and
        // the module just spammed new anchors.
        BlockPos anchor = Placement.findAnchor(mc, t.blockPosition(), 2);
        if (anchor == null) {
            BlockPos spot = Placement.findSpot(mc, t.blockPosition(), 2.0);
            if (spot != null) Placement.useOn(mc, "respawn_anchor", spot.below());
            return;
        }

        int charge = mc.level.getBlockState(anchor)
                .getValue(net.minecraft.world.level.block.RespawnAnchorBlock.CHARGE);
        if (charge < net.minecraft.world.level.block.RespawnAnchorBlock.MAX_CHARGES) {
            if (tick % 8 == 0) Placement.useOn(mc, "glowstone", anchor);
            return;
        }

        // Detonating needs a non-fuel item in hand, or the anchor charges again.
        if (ModuleUtils.matches(mc.player.getMainHandItem(), "glowstone")) {
            for (int i = 0; i < 9; i++) {
                if (!ModuleUtils.matches(mc.player.getInventory().getItem(i), "glowstone")) {
                    ModuleUtils.select(mc, i);
                    return;
                }
            }
            return;
        }
        mc.gameMode.useItemOn(mc.player, InteractionHand.MAIN_HAND,
                new net.minecraft.world.phys.BlockHitResult(
                        Vec3.atCenterOf(anchor), Direction.UP, anchor, false));
        mc.player.swing(InteractionHand.MAIN_HAND);
    }

    private static void fastCart(Minecraft mc, int tick) {
        // Waits for a rail to be placed under the crosshair, then drops the cart.
        if (!(mc.hitResult instanceof net.minecraft.world.phys.BlockHitResult hit)) return;
        BlockPos pos = hit.getBlockPos();
        if (!mc.level.getBlockState(pos).getBlock().toString().contains("rail")) return;
        if (tick % 2 != 0) return;
        Placement.useOn(mc, "tnt_minecart", pos);
    }

    private static void pearlCatch(Minecraft mc, int tick) {
        if (tick % 2 == 0) {
            if (!select(mc, "ender_pearl")) return;
            mc.gameMode.useItem(mc.player, InteractionHand.MAIN_HAND);
            // Do NOT reset the tick here: resetting pinned advance() at 0, so the
            // even branch ran every tick and the wind-charge catch was dead code.
            return;
        }
        if (select(mc, "wind_charge")) {
            mc.player.setXRot(30f);
            mc.gameMode.useItem(mc.player, InteractionHand.MAIN_HAND);
        }
    }

    private static void pearlChase(Minecraft mc, int tick) {
        if (tick % 3 != 0) return;
        if (!select(mc, "ender_pearl")) return;
        Player t = target(mc, 30.0);
        if (t == null) return;
        rotate(mc, t.position().add(0, 1.0, 0));
        mc.gameMode.useItem(mc.player, InteractionHand.MAIN_HAND);
    }

    private static void pearlGrapple(Minecraft mc, int tick) {
        if (tick % 4 != 0) return;
        Player t = target(mc, 25.0);
        if (t == null) return;
        if (!select(mc, "ender_pearl")) return;
        rotate(mc, t.position().add(0, t.getBbHeight() * 0.5, 0));
        mc.gameMode.useItem(mc.player, InteractionHand.MAIN_HAND);
    }

    private static void swordHit(Minecraft mc, int tick) {
        if (!mc.options.keyAttack.isDown()) return;
        if (tick % 2 != 0) return;
        select(mc, "sword");
    }

    // ---- automation bodies ----

    private static void holdEat(Minecraft mc, String item) {
        if (!select(mc, item)) return;
        if (!mc.player.isUsingItem()) mc.gameMode.useItem(mc.player, InteractionHand.MAIN_HAND);
    }

    private static void holdShield(Minecraft mc) {
        if (!select(mc, "shield")) return;
        if (!mc.player.isUsingItem()) mc.gameMode.useItem(mc.player, InteractionHand.MAIN_HAND);
    }

    private static void oneTap(Minecraft mc, int tick, String item, String key) {
        if (tick % 10 != 0) return;
        if (!select(mc, item)) return;
        mc.gameMode.useItem(mc.player, InteractionHand.MAIN_HAND);
    }

    // ---- movement bodies ----

    private static void autoLunge(Minecraft mc, int tick) {
        Player t = target(mc, 3.8);
        if (t == null) return;
        if (tick % 3 != 0) return;
        if (!select(mc, "spear")) return;
        rotate(mc, t.position().add(0, t.getBbHeight() * 0.6, 0));
        mc.gameMode.attack(mc.player, t);
        mc.player.swing(InteractionHand.MAIN_HAND);
    }

    private static void keepSprint(Minecraft mc) {
        if (!mc.player.isSprinting() && !mc.player.isCrouching()) {
            mc.player.setSprinting(true);
            mc.player.connection.send(new ServerboundPlayerCommandPacket(
                    mc.player, ServerboundPlayerCommandPacket.Action.START_SPRINTING));
        }
    }

    private static void snaptap(Minecraft mc) {
        boolean forward = mc.options.keyUp.isDown();
        boolean back = mc.options.keyDown.isDown();
        if (forward && back) mc.player.setDeltaMovement(mc.player.getDeltaMovement().multiply(1.0, 1.0, 0.0));
        boolean left = mc.options.keyLeft.isDown();
        boolean right = mc.options.keyRight.isDown();
        if (left && right) mc.player.setDeltaMovement(mc.player.getDeltaMovement().multiply(0.0, 1.0, 1.0));
    }

    private static void spearAssist(Minecraft mc) {
        if (!mc.player.isUsingItem()) return;
        Player t = target(mc, 20.0);
        if (t == null) return;
        rotate(mc, t.position().add(0, t.getBbHeight() * 0.6, 0));
    }

    // ---- player bodies ----

    private static void autoDrain(Minecraft mc, int tick) {
        if (tick % 5 != 0) return;
        // An empty bucket is required: "bucket" also matches water/lava buckets, and
        // "scooping" with one of those just places its contents.
        if (!selectExact(mc, net.minecraft.world.item.Items.BUCKET)) return;
        BlockPos below = mc.player.blockPosition().below();
        if (mc.level.getBlockState(below).getFluidState().isEmpty()) return;
        Placement.useOn(mc, "bucket", below);
    }

    private static void autoExtinguish(Minecraft mc, int tick) {
        if (!mc.player.isOnFire()) return;
        if (tick % 4 != 0) return;
        if (!select(mc, "water_bucket")) return;
        Placement.useOn(mc, "water_bucket", mc.player.blockPosition().below());
    }

    private static void autoTool(Minecraft mc) {
        if (!mc.options.keyAttack.isDown()) return;
        if (!(mc.hitResult instanceof net.minecraft.world.phys.BlockHitResult hit)) return;

        String block = mc.level.getBlockState(hit.getBlockPos()).getBlock().toString().toLowerCase();
        // Match the item suffix exactly: ModuleUtils.matches is a substring test and
        // "minecraft:iron_pickaxe" contains "axe", so a pickaxe used to satisfy the
        // wood branch and no axe was ever equipped.
        String want;
        if (block.contains("stone") || block.contains("ore") || block.contains("deepslate")
                || block.contains("obsidian") || block.contains("cobble")) want = "_pickaxe";
        else if (block.contains("log") || block.contains("wood") || block.contains("plank")) want = "_axe";
        else if (block.contains("dirt") || block.contains("sand") || block.contains("gravel")) want = "_shovel";
        else return;

        if (!holdingTool(mc, want)) selectTool(mc, want);
    }

    private static void webEscape(Minecraft mc, int tick) {
        BlockPos feet = mc.player.blockPosition();
        BlockPos head = feet.above();
        boolean inWeb = mc.level.getBlockState(feet).getBlock().toString().contains("cobweb")
                || mc.level.getBlockState(head).getBlock().toString().contains("cobweb");
        if (!inWeb) return;

        if (tick % 3 == 0) {
            mc.gameMode.startDestroyBlock(feet, Direction.UP);
        }
    }

    // ---- smp bodies ----

    private static void autoChorus(Minecraft mc, int tick) {
        if (mc.player.getHealth() > 6f) return;
        if (tick % 8 != 0) return;
        holdEat(mc, "chorus_fruit");
    }

    private static void autoHeal(Minecraft mc, int tick) {
        float health = mc.player.getHealth();
        float max = Math.max(1f, mc.player.getMaxHealth());
        if (health / max > 0.5f) return;
        if (tick % 6 != 0) return;
        if (select(mc, "golden_apple", "gapple")) {
            if (!mc.player.isUsingItem()) mc.gameMode.useItem(mc.player, InteractionHand.MAIN_HAND);
            return;
        }
        holdEat(mc, "potion");
    }

    private static void bowSpam(Minecraft mc, int tick) {
        if (!select(mc, "bow")) return;
        if (!mc.player.isUsingItem()) {
            mc.gameMode.useItem(mc.player, InteractionHand.MAIN_HAND);
            return;
        }
        if (mc.player.getTicksUsingItem() >= 3) {
            mc.gameMode.releaseUsingItem(mc.player);
            mc.player.swing(InteractionHand.MAIN_HAND);
        }
    }

    private static void lavaMacro(Minecraft mc, int tick) {
        BlockPos front = mc.player.blockPosition().relative(mc.player.getDirection(), 2);
        int phase = tick % 10;
        if (phase == 0) {
            if (!select(mc, "lava_bucket")) return;
            Placement.useOn(mc, "lava_bucket", front.below());
            return;
        }
        if (phase >= 6) {
            // The lava was placed into `front`; scooping has to click that same fluid
            // cell, not the solid support below it.
            if (!selectExact(mc, net.minecraft.world.item.Items.BUCKET)) return;
            Placement.useOn(mc, "bucket", front);
        }
    }

    private static void plateWeb(Minecraft mc, int tick) {
        Player t = target(mc, 4.0);
        if (t == null) return;
        if (tick % 10 != 0) return;
        // Web the block the target is standing in (click the ground below it).
        Placement.useOn(mc, "cobweb", t.blockPosition().below());
    }

    // ---- blatant bodies ----

    // ---- inventory bodies (menu clicks, never container hacks) ----

    private static void refill(Minecraft mc, int tick, String... names) {
        if (tick % 20 != 0) return;
        if (mc.player.containerMenu == null) return;

        for (int hotbar = 0; hotbar < 9; hotbar++) {
            ItemStack current = mc.player.getInventory().getItem(hotbar);
            if (!current.isEmpty() && !ModuleUtils.matches(current, names)) continue;
            if (!current.isEmpty() && current.getCount() > 16) continue;

            int source = findInInventory(mc, current, names);
            if (source < 0) continue;

            mc.gameMode.handleContainerInput(mc.player.containerMenu.containerId,
                    source, hotbar, net.minecraft.world.inventory.ContainerInput.SWAP, mc.player);
            return;
        }
    }

    private static void replenish(Minecraft mc, int tick) {
        if (tick % 20 != 0) return;
        if (mc.player.containerMenu == null) return;

        for (int hotbar = 0; hotbar < 9; hotbar++) {
            ItemStack current = mc.player.getInventory().getItem(hotbar);
            if (current.isEmpty() || current.getCount() > 8) continue;

            int source = findInInventory(mc, current, null);
            if (source < 0) continue;

            mc.gameMode.handleContainerInput(mc.player.containerMenu.containerId,
                    source, hotbar, net.minecraft.world.inventory.ContainerInput.SWAP, mc.player);
            return;
        }
    }

    /** Menu slot 9..35 is the main inventory in the player menu. */
    private static int findInInventory(Minecraft mc, ItemStack template, String... names) {
        String want = template == null || template.isEmpty()
                ? null : template.getItem().toString();

        for (int menuSlot = 9; menuSlot < 36; menuSlot++) {
            ItemStack stack = mc.player.containerMenu.getSlot(menuSlot).getItem();
            if (stack.isEmpty()) continue;
            if (want != null) {
                if (stack.getItem().toString().equals(want) && stack.getCount() > 0) return menuSlot;
            } else if (names != null && ModuleUtils.matches(stack, names)) {
                return menuSlot;
            }
        }
        return -1;
    }

    /** Menu slot 6 is the chest plate; SWAP with a hotbar index equips straight in. */
    private static void elytraSwap(Minecraft mc, int tick) {
        if (tick % 10 != 0) return;
        if (mc.player.containerMenu == null) return;

        ItemStack chest = mc.player.getItemBySlot(EquipmentSlot.CHEST);
        if (chest.getItem().toString().toLowerCase().contains("elytra")) return;

        int slot = ModuleUtils.findHotbarItem(mc, "elytra");
        if (slot < 0) return;

        mc.gameMode.handleContainerInput(mc.player.containerMenu.containerId,
                6, slot, net.minecraft.world.inventory.ContainerInput.SWAP, mc.player);
    }

    private static void chestSteal(Minecraft mc, int tick) {
        if (tick % 4 != 0) return;
        // Without a screen the current menu is the player's own inventory menu, and
        // "containerSlots" then counted the crafting/armour slots: shift-clicking
        // them unequipped the player's gear. Only real containers are lootable.
        if (mc.player.containerMenu == null || mc.player.containerMenu == mc.player.inventoryMenu) return;

        int size = mc.player.containerMenu.slots.size();
        int containerSlots = Math.max(0, size - 36);
        if (containerSlots == 0) return;

        for (int i = 0; i < containerSlots; i++) {
            if (mc.player.containerMenu.getSlot(i).getItem().isEmpty()) continue;
            mc.gameMode.handleContainerInput(mc.player.containerMenu.containerId,
                    i, 0, net.minecraft.world.inventory.ContainerInput.QUICK_MOVE, mc.player);
            return;
        }
    }

    private static void invCleaner(Minecraft mc, int tick) {
        if (tick % 6 != 0) return;
        if (mc.player.containerMenu == null) return;

        for (int menuSlot = 9; menuSlot < 45; menuSlot++) {
            ItemStack stack = mc.player.containerMenu.getSlot(menuSlot).getItem();
            if (stack.isEmpty()) continue;

            String id = stack.getItem().toString().toLowerCase();
            boolean junk = id.contains("rotten_flesh") || id.contains("poisonous_potato")
                    || id.contains("spider_eye") || id.contains("seeds")
                    || id.contains("wheat_seeds") || id.contains("flint")
                    || id.contains("bowl");
            if (!junk) continue;

            mc.gameMode.handleContainerInput(mc.player.containerMenu.containerId,
                    menuSlot, 0, net.minecraft.world.inventory.ContainerInput.THROW, mc.player);
            return;
        }
    }

    private static void fastExp(Minecraft mc) {
        if (!select(mc, "experience_bottle")) return;
        mc.gameMode.useItem(mc.player, InteractionHand.MAIN_HAND);
    }

    private static void maceShieldDrain(Minecraft mc, int tick) {
        Player t = target(mc, 4.2);
        if (t == null) return;
        if (!falling(mc)) return;
        if (!select(mc, "mace")) return;

        rotate(mc, t.position().add(0, t.getBbHeight() * 0.6, 0));
        mc.gameMode.attack(mc.player, t);
        mc.player.swing(InteractionHand.MAIN_HAND);
        if (tick % 2 == 0) {
            mc.gameMode.attack(mc.player, t);
            mc.player.swing(InteractionHand.MAIN_HAND);
        }
    }

    private static void fastPlace(Minecraft mc) {
        if (!mc.options.keyUse.isDown()) return;
        if (!(mc.hitResult instanceof net.minecraft.world.phys.BlockHitResult hit)) return;
        mc.gameMode.useItemOn(mc.player, InteractionHand.MAIN_HAND, hit);
    }

    private static void noBreakDelay(Minecraft mc) {
        if (!mc.options.keyAttack.isDown()) return;
        if (!(mc.hitResult instanceof net.minecraft.world.phys.BlockHitResult hit)) return;
        if (mc.level.getBlockState(hit.getBlockPos()).isAir()) return;
        mc.gameMode.startDestroyBlock(hit.getBlockPos(), hit.getDirection());
    }

    // ---- client ----

    private static void openGui(Minecraft mc) {
        Module self = UtilityClient.moduleManager.getByName("ClickGUI");
        if (self != null) self.setEnabled(false);
        mc.gui.setScreen(new com.baggute.cheatclient.gui.ClickGuiScreen());
    }

    private static void activateGlide(Minecraft mc) {
        mc.player.connection.send(new ServerboundPlayerCommandPacket(
                mc.player, ServerboundPlayerCommandPacket.Action.START_FALL_FLYING));
    }

    /** Snapshot of what the apex tab can and cannot do, for the debug log. */
    public static String report() {
        int supported = 0, unsupported = 0;
        for (Module m : UtilityClient.moduleManager.getModules()) {
            if (!(m instanceof ApexModule apex)) continue;
            if (apex.isImplemented()) supported++;
            else unsupported++;
        }
        return supported + " implemented, " + unsupported + " unavailable";
    }

    /** Unused guard kept for the equipment reader below. */
    static ItemStack hand(Minecraft mc, EquipmentSlot slot) {
        return mc.player.getItemBySlot(slot);
    }

    static boolean alive(LivingEntity e) {
        return e != null && e.getHealth() > 0;
    }

    static boolean sneezing(Player p) {
        return p != null && !p.isSprinting();
    }
}
