// language: Java, file: ArrayListModule.java, target: Fabric 26.2
package com.baggute.cheatclient.module.render;

import com.baggute.cheatclient.UtilityClient;
import com.baggute.cheatclient.module.Category;
import com.baggute.cheatclient.module.Module;
import com.baggute.cheatclient.settings.BoolSetting;
import com.baggute.cheatclient.settings.ColorSetting;
import com.baggute.cheatclient.settings.DoubleSetting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * The classic right-edge module list: every enabled module, sorted by width so the
 * edge stays a clean staircase, with an optional dimmed background bar.
 */
public class ArrayListModule extends Module {

    private static final double RAINBOW_STEP = 0.02;

    private final BoolSetting background = new BoolSetting("background", "Draw a background bar", true);
    private final BoolSetting rainbow = new BoolSetting("rainbow", "Cycle colors", false);
    private final ColorSetting textColor = new ColorSetting("textColor", "Text color", 0xFF00E5FF);
    private final ColorSetting bgColor = new ColorSetting("bgColor", "Background color", 0x90101010);
    private final DoubleSetting scale = new DoubleSetting("scale", "Scale", 1.0, 0.5, 2.0);
    private final BoolSetting lowercase = new BoolSetting("lowercase", "Lowercase names", false);

    private float hue = 0f;

    public ArrayListModule() {
        super("ArrayList", "Displays enabled modules down the right edge.", Category.RENDER);
        addSetting(background);
        addSetting(rainbow);
        addSetting(textColor);
        addSetting(bgColor);
        addSetting(scale);
        addSetting(lowercase);
    }

    @Override
    public void onRenderFrame(float partialTick) {
        if (!rainbow.get()) return;
        hue += (float) RAINBOW_STEP / 20f;
        if (hue > 1f) hue -= 1f;
    }

    public void renderList(GuiGraphicsExtractor g, Minecraft mc) {
        if (!isEnabled() || UtilityClient.moduleManager == null) return;

        List<Module> active = new ArrayList<>();
        for (Module m : UtilityClient.moduleManager.getModules()) {
            if (m.isEnabled() && m != this) active.add(m);
        }
        if (active.isEmpty()) return;

        boolean lower = lowercase.get();
        active.sort(Comparator.comparingInt((Module m) ->
                mc.font.width(lower ? m.getName().toLowerCase() : m.getName())).reversed());

        double s = scale.get();
        g.pose().pushMatrix();
        g.pose().scale((float) s, (float) s);

        int screenW = (int) (mc.getWindow().getGuiScaledWidth() / s);
        int y = 4;
        int i = 0;
        for (Module m : active) {
            String name = lower ? m.getName().toLowerCase() : m.getName();
            int w = mc.font.width(name);
            int color = rainbow.get()
                    ? (0xFF000000 | (java.awt.Color.HSBtoRGB((hue + i * 0.06f) % 1f, 0.55f, 1f) & 0xFFFFFF))
                    : textColor.get();
            if (background.get()) {
                g.fill(screenW - w - 6, y - 1, screenW, y + 9, bgColor.get());
            }
            g.text(mc.font, name, screenW - w - 3, y, color, true);
            y += 10;
            i++;
        }

        g.pose().popMatrix();
    }

    @Override
    protected void onEnable() {
        hue = 0f;
    }
}
