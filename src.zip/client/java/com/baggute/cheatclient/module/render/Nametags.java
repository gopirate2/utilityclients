// language: Java, file: Nametags.java, target: Fabric 26.2
package com.baggute.cheatclient.module.render;

import com.baggute.cheatclient.module.Category;
import com.baggute.cheatclient.module.Module;
import com.baggute.cheatclient.settings.BoolSetting;
import com.baggute.cheatclient.settings.DoubleSetting;
import com.baggute.cheatclient.settings.IntSetting;

/**
 * Feeds the nametags HUD widget: nearby players with health and distance, sorted
 * by range. Rendering lives in HudRenderer so this module owns only the filters.
 */
public class Nametags extends Module {

    private final DoubleSetting range;
    private final BoolSetting showHealth;
    private final BoolSetting showDistance;
    private final IntSetting maxEntries;

    public Nametags() {
        super("Nametags", "Lists nearby players with health and distance.", Category.RENDER);

        this.range = new DoubleSetting("range", "Scan radius in blocks", 64.0, 8.0, 256.0);
        this.showHealth = new BoolSetting("showHealth", "Show health", true);
        this.showDistance = new BoolSetting("showDistance", "Show distance", true);
        this.maxEntries = new IntSetting("maxEntries", "Rows to list", 6, 1, 16);

        addSetting(range);
        addSetting(showHealth);
        addSetting(showDistance);
        addSetting(maxEntries);
    }

    public double getRange() { return range.get(); }
    public boolean showHealth() { return showHealth.get(); }
    public boolean showDistance() { return showDistance.get(); }
    public int maxEntries() { return maxEntries.get(); }
}
