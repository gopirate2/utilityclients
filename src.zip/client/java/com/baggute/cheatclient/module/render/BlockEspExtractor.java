// language: Java, file: BlockEspExtractor.java, target: Fabric 26.2
package com.baggute.cheatclient.render;

import com.baggute.cheatclient.UtilityClient;
import com.baggute.cheatclient.module.render.BlockESP;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.gizmos.Gizmos;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.level.chunk.LevelChunkSection;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Set;

public final class BlockEspExtractor {

    private static final List<BlockPos> foundBlocks = new ArrayList<>();
    private static long lastScanMs = 0L;
    private static int lastChunkX = Integer.MIN_VALUE;
    private static int lastChunkZ = Integer.MIN_VALUE;
    private static int lastScanRadius = -1;
    private static String lastFilter = "";

    private BlockEspExtractor() {}

    public static void emitGizmos() {
        if (UtilityClient.moduleManager == null) return;

        BlockESP mod = (BlockESP) UtilityClient.moduleManager.getByName("BlockESP");
        if (mod == null || !mod.isEnabled()) return;

        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null) return;

        int radius = (int) mod.getRadius();
        BlockPos center = mc.player.blockPosition();
        int cx = center.getX() >> 4;
        int cz = center.getZ() >> 4;
        String filterKey = mod.getBlockFilter().toString();

        long now = System.currentTimeMillis();
        boolean needScan = radius != lastScanRadius
                || now - lastScanMs > 1000
                || cx != lastChunkX
                || cz != lastChunkZ
                || !filterKey.equals(lastFilter);
        if (needScan) {
            rescan(mc, center, radius, mod);

            // Sort by distance so maxShown favors the nearest blocks.
            foundBlocks.sort(Comparator.comparingDouble(p -> p.distSqr(center)));

            lastScanMs = now;
            lastChunkX = cx;
            lastChunkZ = cz;
            lastScanRadius = radius;
            lastFilter = filterKey;
        }

        int color = mod.getColor();
        boolean simple = mod.isSimpleRender();
        int maxShown = mod.getMaxShown();
        int shown = 0;
        double radiusSq = (double) radius * radius;

        for (BlockPos pos : foundBlocks) {
            if (shown >= maxShown) break;
            if (pos.distSqr(center) > radiusSq) continue;
            Vec3 min = new Vec3(pos.getX(), pos.getY(), pos.getZ());
            Vec3 max = new Vec3(pos.getX() + 1, pos.getY() + 1, pos.getZ() + 1);
            if (simple) drawSimpleBox(min, max, color);
            else drawBoxEdges(min, max, color);
            shown++;
        }
    }

    private static void rescan(Minecraft mc, BlockPos center, int radius, BlockESP mod) {
        foundBlocks.clear();
        Set<Block> targets = mod.getBlockSet();
        if (targets.isEmpty()) return;

        int minChunkX = (center.getX() - radius) >> 4;
        int maxChunkX = (center.getX() + radius) >> 4;
        int minChunkZ = (center.getZ() - radius) >> 4;
        int maxChunkZ = (center.getZ() + radius) >> 4;

        int minY = Math.max(mc.level.getMinY(), center.getY() - radius);
        int maxY = Math.min(mc.level.getMaxY(), center.getY() + radius);
        if (maxY - minY <= 0) return;

        boolean usePalette = mod.isFastScan();

        for (int chunkX = minChunkX; chunkX <= maxChunkX; chunkX++) {
            for (int chunkZ = minChunkZ; chunkZ <= maxChunkZ; chunkZ++) {
                LevelChunk chunk = mc.level.getChunkSource().getChunk(chunkX, chunkZ, false);
                if (chunk == null) continue;
                LevelChunkSection[] sections = chunk.getSections();
                int minSection = Math.max(0, (minY >> 4) - chunk.getMinSectionY());
                int maxSection = Math.min(sections.length - 1, (maxY >> 4) - chunk.getMinSectionY());

                for (int si = minSection; si <= maxSection; si++) {
                    LevelChunkSection section = sections[si];
                    if (section == null || section.hasOnlyAir()) continue;

                    if (usePalette && !section.maybeHas(state -> targets.contains(state.getBlock()))) {
                        continue;
                    }

                    int baseY = (chunk.getMinSectionY() + si) << 4;
                    for (int x = 0; x < 16; x++) {
                        for (int y = 0; y < 16; y++) {
                            int wy = baseY + y;
                            if (wy < minY || wy > maxY) continue;
                            for (int z = 0; z < 16; z++) {
                                BlockState state = section.getBlockState(x, y, z);
                                if (state.isAir()) continue;
                                if (!targets.contains(state.getBlock())) continue;

                                int wx = (chunkX << 4) + x;
                                int wz = (chunkZ << 4) + z;
                                if (Math.abs(wx - center.getX()) > radius) continue;
                                if (Math.abs(wz - center.getZ()) > radius) continue;

                                foundBlocks.add(new BlockPos(wx, wy, wz));
                            }
                        }
                    }
                }
            }
        }
    }

    private static void drawBoxEdges(Vec3 min, Vec3 max, int color) {
        double pad = 0.005;
        double x0 = min.x + pad, y0 = min.y + pad, z0 = min.z + pad;
        double x1 = max.x - pad, y1 = max.y - pad, z1 = max.z - pad;

        line(x0, y0, z0, x1, y0, z0, color);
        line(x1, y0, z0, x1, y0, z1, color);
        line(x1, y0, z1, x0, y0, z1, color);
        line(x0, y0, z1, x0, y0, z0, color);
        line(x0, y1, z0, x1, y1, z0, color);
        line(x1, y1, z0, x1, y1, z1, color);
        line(x1, y1, z1, x0, y1, z1, color);
        line(x0, y1, z1, x0, y1, z0, color);
        line(x0, y0, z0, x0, y1, z0, color);
        line(x1, y0, z0, x1, y1, z0, color);
        line(x1, y0, z1, x1, y1, z1, color);
        line(x0, y0, z1, x0, y1, z1, color);
    }

    private static void drawSimpleBox(Vec3 min, Vec3 max, int color) {
        double pad = 0.005;
        double x0 = min.x + pad, y0 = min.y + pad, z0 = min.z + pad;
        double x1 = max.x - pad, y1 = max.y - pad, z1 = max.z - pad;

        line(x0, y0, z0, x1, y0, z1, color);
        line(x1, y0, z0, x0, y0, z1, color);
        line(x0, y1, z0, x1, y1, z1, color);
        line(x1, y1, z0, x0, y1, z1, color);
        line(x0, y0, z0, x0, y1, z0, color);
        line(x1, y0, z0, x1, y1, z0, color);
    }

    private static void line(double x1, double y1, double z1,
                             double x2, double y2, double z2, int color) {
        Gizmos.line(new Vec3(x1, y1, z1), new Vec3(x2, y2, z2), color, 1.5F)
                .setAlwaysOnTop();
    }
}