// language: Java, file: Fullbright.java, target: Fabric 26.2
package com.baggute.cheatclient.module.render;

import com.baggute.cheatclient.UtilityClient;
import com.baggute.cheatclient.module.Category;
import com.baggute.cheatclient.module.Module;
import com.baggute.cheatclient.settings.DoubleSetting;
import net.minecraft.client.Minecraft;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;

public class Fullbright extends Module {

    private final DoubleSetting level;

    private Field valueField = null;
    private Object previousValue = null;
    private double appliedLevel = -1;

    public Fullbright() {
        super("Fullbright", "Brightens the world so you can see in the dark.", Category.RENDER);
        this.level = new DoubleSetting("level", "Brightness level", 16.0, 1.0, 20.0);
        addSetting(level);
    }

    /**
     * Finds the writable (non-final) numeric field on OptionInstance.
     * The field is named "value" in vanilla but we search so we survive renames.
     */
    private static Field findWritableValueField(Object optionInstance) {
        // Try the known name first.
        try {
            Field f = optionInstance.getClass().getDeclaredField("value");
            f.setAccessible(true);
            if (!Modifier.isFinal(f.getModifiers())) return f;
        } catch (NoSuchFieldException ignored) {}

        // Fallback: any non-final, non-static field holding a Number.
        for (Field f : optionInstance.getClass().getDeclaredFields()) {
            if (Modifier.isStatic(f.getModifiers())) continue;
            if (Modifier.isFinal(f.getModifiers())) continue;
            f.setAccessible(true);
            try {
                Object v = f.get(optionInstance);
                if (v instanceof Number) return f;
            } catch (IllegalAccessException ignored) {}
        }
        return null;
    }

    @Override
    public void onTick() {
        if (valueField == null) return;
        if (appliedLevel == level.get()) return;
        try {
            valueField.set(Minecraft.getInstance().options.gamma(), level.get());
            appliedLevel = level.get();
        } catch (Throwable t) {
            UtilityClient.LOGGER.warn("[Fullbright] failed to update level: {}", t.toString());
        }
    }

    @Override
    protected void onEnable() {
        try {
            Minecraft mc = Minecraft.getInstance();
            Object gamma = mc.options.gamma();
            UtilityClient.LOGGER.info("[Fullbright] option class: {}",
                    gamma.getClass().getCanonicalName());
            valueField = findWritableValueField(gamma);
            if (valueField == null) {
                UtilityClient.LOGGER.warn("[Fullbright] no writable value field found");
                return;
            }
            UtilityClient.LOGGER.info("[Fullbright] using field: {}",
                    valueField.getName());
            previousValue = valueField.get(gamma);
            valueField.set(gamma, level.get());
            appliedLevel = level.get();
            Object check = valueField.get(gamma);
            UtilityClient.LOGGER.info("[Fullbright] gamma {} -> {} (readback={})",
                    previousValue, level.get(), check);
        } catch (Throwable t) {
            UtilityClient.LOGGER.warn("[Fullbright] failed: {}", t.toString());
        }
    }

    @Override
    protected void onDisable() {
        try {
            if (previousValue != null && valueField != null) {
                Minecraft mc = Minecraft.getInstance();
                valueField.set(mc.options.gamma(), previousValue);
                previousValue = null;
                valueField = null;
                appliedLevel = -1;
                UtilityClient.LOGGER.info("[Fullbright] restored");
            }
        } catch (Throwable t) {
            UtilityClient.LOGGER.warn("[Fullbright] restore failed: {}", t.toString());
        }
    }
}