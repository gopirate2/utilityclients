package com.baggute.cheatclient.module.misc;

import com.baggute.cheatclient.UtilityClient;
import com.baggute.cheatclient.module.Category;
import com.baggute.cheatclient.module.Module;
import kaptainwutax.seedcrackerX.SeedCracker;
import kaptainwutax.seedcrackerX.config.Config;

/** UtilityClient's Misc-tab control for the embedded official SeedCrackerX system. */
public final class SeedCrackerX extends Module {
    public SeedCrackerX() {
        super("SeedCrackerX", "Official SeedCrackerX structure seed cracker.", Category.MISC);
    }

    @Override
    protected void onEnable() {
        Config.get().active = true;
        Config.save();
        UtilityClient.LOGGER.info("[SeedCrackerX] enabled from UtilityClient Misc tab");
    }

    @Override
    protected void onDisable() {
        Config.get().active = false;
        Config.save();
        if (SeedCracker.get() != null) SeedCracker.get().reset();
        UtilityClient.LOGGER.info("[SeedCrackerX] disabled and data reset");
    }

    @Override
    public void onTick() {
        // Keep commands/config changes and the UtilityClient toggle synchronized.
        if (Config.get().active != isEnabled()) {
            setEnabled(Config.get().active);
        }
    }
}
