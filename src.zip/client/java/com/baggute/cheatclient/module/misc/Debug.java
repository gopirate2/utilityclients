// language: Java, file: Debug.java, target: Fabric 26.2
package com.baggute.cheatclient.module.misc;

import com.baggute.cheatclient.module.Category;
import com.baggute.cheatclient.module.Module;
import com.baggute.cheatclient.settings.BoolSetting;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Stage board for the automation modules. Each module reports its current phase
 * plus the counters that decide the next transition, so a cycle that stalls is
 * visible instead of inferred.
 *
 * Reports are dropped automatically once a module stops updating, so a disabled
 * module never leaves a stale line on screen.
 */
public class Debug extends Module {

    private static final long STALE_MS = 1500L;
    private static final Map<String, Entry> ENTRIES = new LinkedHashMap<>();

    private final BoolSetting enabledOverlay;

    private record Entry(String text, long stamp) {}

    public Debug() {
        super("Debug", "Shows each automation module's live stage and counters.", Category.MISC);
        this.enabledOverlay = new BoolSetting("overlay", "Draw the stage board on screen", true);
        addSetting(enabledOverlay);
    }

    public boolean isOverlayOn() {
        return isEnabled() && enabledOverlay.get();
    }

    /** Called by automation modules every tick. Cheap: one map write. */
    public static void stage(String module, String text) {
        ENTRIES.put(module, new Entry(text, System.currentTimeMillis()));
    }

    /** Live lines, oldest report first, with stale entries filtered out. */
    public static List<String> snapshot() {
        long now = System.currentTimeMillis();
        List<String> out = new ArrayList<>();
        ENTRIES.entrySet().removeIf(e -> now - e.getValue().stamp() > STALE_MS);
        for (Map.Entry<String, Entry> e : ENTRIES.entrySet()) {
            out.add(e.getKey() + ": " + e.getValue().text());
        }
        return out;
    }

    @Override
    protected void onEnable() {
        ENTRIES.clear();

        // Pure-logic checks over the math that has bitten us before. JUnit is not in
        // the offline cache, so the run reports through the log instead.
        List<String> failures = com.baggute.cheatclient.util.SelfTests.run();
        if (failures.isEmpty()) {
            com.baggute.cheatclient.UtilityClient.LOGGER.info("[SelfTests] all checks passed");
            Notifications.push("selftests: ok", true);
        } else {
            for (String failure : failures) {
                com.baggute.cheatclient.UtilityClient.LOGGER.error("[SelfTests] {}", failure);
            }
            Notifications.push("selftests: " + failures.size() + " failed", false);
        }
    }

    @Override
    protected void onDisable() {
        ENTRIES.clear();
    }
}
