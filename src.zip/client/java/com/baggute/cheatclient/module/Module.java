// language: Java, file: Module.java, target: Fabric 26.2
package com.baggute.cheatclient.module;

import com.baggute.cheatclient.module.misc.Notifications;
import com.baggute.cheatclient.settings.Setting;
import com.mojang.blaze3d.vertex.PoseStack;

import java.util.ArrayList;
import java.util.List;

public abstract class Module {

    private final String name;
    private final String description;
    private final Category category;
    private boolean enabled;
    private final List<Setting> settings = new ArrayList<>();

    protected Module(String name, String description, Category category) {
        this.name = name;
        this.description = description;
        this.category = category;
    }

    public String getName() { return name; }
    public String getDescription() { return description; }
    public Category getCategory() { return category; }
    public boolean isEnabled() { return enabled; }
    public List<Setting> getSettings() { return settings; }

    /** Append a setting to the end of the list. */
    public void addSetting(Setting s) { settings.add(s); }

    /** Insert a setting at a specific index. Used for pinning keybind at the top. */
    public void insertSetting(int index, Setting s) {
        if (index < 0) index = 0;
        if (index > settings.size()) index = settings.size();
        settings.add(index, s);
    }

    public void toggle() {
        setEnabled(!enabled);
    }

    public void setEnabled(boolean state) {
        if (this.enabled == state) return;
        this.enabled = state;
        if (state) onEnable();
        else onDisable();
        Notifications.push(name, state);
    }

    /**
     * Held binds: the module is active only while the key is down, so the state
     * follows the key silently — no toast spam on every tap.
     */
    public void setEnabledHeld(boolean state) {
        if (this.enabled == state) return;
        this.enabled = state;
        if (state) onEnable();
        else onDisable();
    }

    // ---- hooks ----

    protected void onEnable() {}
    protected void onDisable() {}

    /** Runs once after the saved config has been applied to this module. */
    public void onConfigLoaded() {}

    public void onTick() {}

    public void onKey(int keyCode, int action) {}

    /** Receives configured secondary action keys without toggling the module. */
    public void onRawKey(int keyCode, int action) {}

    public void onRender3D(PoseStack poseStack, float partialTick) {}

    public void onRenderFrame(float partialTick) {}
}
