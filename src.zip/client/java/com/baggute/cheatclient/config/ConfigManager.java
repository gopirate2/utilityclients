// language: Java, file: ConfigManager.java, target: Fabric 26.2
package com.baggute.cheatclient.config;

import com.baggute.cheatclient.UtilityClient;
import com.baggute.cheatclient.module.Module;
import com.baggute.cheatclient.module.ModuleManager;
import com.baggute.cheatclient.module.misc.Notifications;
import com.baggute.cheatclient.settings.Setting;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.io.IOException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public final class ConfigManager {
    private final ModuleManager moduleManager;
    private final Path path = root().resolve("utilityclient.json");
    private final Gson gson = new GsonBuilder().setPrettyPrinting().create();

    public ConfigManager(ModuleManager moduleManager) {
        this.moduleManager = moduleManager;
    }

    /**
     * Where settings live: the hidden folder in {@link Storage}, not the instance's
     * config directory.
     *
     * <p>The game's config folder is the first place anyone looks after a
     * screenshare, and a file named after the client there is a confession. Stealth
     * mode used to move the file to a temp directory instead; that location died on
     * the next reboot, so both modes now share one persistent, unobtrusive path.
     */
    private static Path root() {
        return Storage.root();
    }

    private static Path presetDir() {
        return root().resolve("utilityclient").resolve("presets");
    }

    public void save() {
        writeTo(path);
    }

    public void load() {
        readFrom(path);
    }

    /** Preset names on disk, sorted, without the .json suffix. */
    public static List<String> listPresets() {
        List<String> out = new ArrayList<>();
        Path dir = presetDir();
        if (!Files.isDirectory(dir)) return out;
        try (DirectoryStream<Path> stream = Files.newDirectoryStream(dir, "*.json")) {
            for (Path p : stream) {
                String file = p.getFileName().toString();
                out.add(file.substring(0, file.length() - 5));
            }
        } catch (IOException exception) {
            UtilityClient.LOGGER.error("Failed to list presets", exception);
        }
        Collections.sort(out);
        return out;
    }

    public boolean savePreset(String name) {
        String safe = sanitize(name);
        if (safe.isEmpty()) return false;
        Path target = presetDir().resolve(safe + ".json");
        try {
            Files.createDirectories(target.getParent());
        } catch (IOException exception) {
            UtilityClient.LOGGER.error("Failed to create preset directory", exception);
            return false;
        }
        return writeTo(target);
    }

    public boolean loadPreset(String name) {
        String safe = sanitize(name);
        if (safe.isEmpty()) return false;
        Path target = presetDir().resolve(safe + ".json");
        if (!Files.exists(target)) return false;
        return readFrom(target);
    }

    public boolean deletePreset(String name) {
        String safe = sanitize(name);
        if (safe.isEmpty()) return false;
        try {
            return Files.deleteIfExists(presetDir().resolve(safe + ".json"));
        } catch (IOException exception) {
            UtilityClient.LOGGER.error("Failed to delete preset {}", safe, exception);
            return false;
        }
    }

    /** "12 on" from the preset's own metadata, or "" when it has none. */
    public static String describePreset(String name) {
        String safe = sanitize(name);
        if (safe.isEmpty()) return "";
        Path file = presetDir().resolve(safe + ".json");
        if (!Files.exists(file)) return "";
        try {
            JsonElement parsed = JsonParser.parseString(Files.readString(file));
            if (!parsed.isJsonObject()) return "";
            JsonObject meta = parsed.getAsJsonObject().getAsJsonObject("__meta");
            if (meta == null || !meta.has("enabled")) return "";
            return meta.get("enabled").getAsInt() + " on";
        } catch (Exception exception) {
            return "";
        }
    }

    /** Strips anything that could escape the preset directory. */
    private static String sanitize(String name) {
        if (name == null) return "";
        return name.trim().replaceAll("[^a-zA-Z0-9 _-]", "").replace(' ', '_');
    }

    private boolean writeTo(Path target) {
        try {
            Files.createDirectories(target.getParent());
            JsonObject root = new JsonObject();
            JsonObject modulesObject = new JsonObject();
            int enabledCount = 0;
            for (Module module : moduleManager.getModules()) {
                JsonObject moduleObject = new JsonObject();
                moduleObject.addProperty("enabled", module.isEnabled());
                if (module.isEnabled()) enabledCount++;
                JsonObject settingsObject = new JsonObject();
                for (Setting setting : module.getSettings()) {
                    settingsObject.add(setting.getName(), setting.toJson());
                }
                moduleObject.add("settings", settingsObject);
                modulesObject.add(module.getName(), moduleObject);
            }
            root.add("modules", modulesObject);

            JsonObject meta = new JsonObject();
            meta.addProperty("enabled", enabledCount);
            meta.addProperty("saved", System.currentTimeMillis());
            root.add("__meta", meta);

            Files.writeString(target, gson.toJson(root));
            return true;
        } catch (IOException exception) {
            UtilityClient.LOGGER.error("Failed to save config to {}", target, exception);
            return false;
        }
    }

    private boolean readFrom(Path source) {
        if (!Files.exists(source)) return false;
        // Applying a config toggles dozens of modules at once; the banner queue
        // would be nothing but startup noise.
        Notifications.setMuted(true);
        try {
            JsonElement parsed = JsonParser.parseString(Files.readString(source));
            if (!parsed.isJsonObject()) return false;
            JsonObject modulesObject = parsed.getAsJsonObject().getAsJsonObject("modules");
            if (modulesObject == null) return false;
            for (Module module : moduleManager.getModules()) {
                JsonElement moduleElement = modulesObject.get(module.getName());
                if (moduleElement == null || !moduleElement.isJsonObject()) continue;
                // One malformed module entry must not abort loading every other one.
                try {
                    JsonObject moduleObject = moduleElement.getAsJsonObject();
                    // Settings first: onEnable() reads them, so applying "enabled"
                    // before the settings would enable with default values.
                    JsonObject settingsObject = moduleObject.getAsJsonObject("settings");
                    if (settingsObject != null) {
                        for (Setting setting : module.getSettings()) {
                            JsonElement settingElement = settingsObject.get(setting.getName());
                            if (settingElement != null) {
                                setting.fromJson(settingElement);
                            }
                        }
                    }
                    if (moduleObject.has("enabled")) {
                        module.setEnabled(moduleObject.get("enabled").getAsBoolean());
                    }
                    module.onConfigLoaded();
                } catch (Exception exception) {
                    UtilityClient.LOGGER.warn("Failed to load config for module {}", module.getName(), exception);
                }
            }
            return true;
        } catch (Exception exception) {
            UtilityClient.LOGGER.error("Failed to load config from {}", source, exception);
            return false;
        } finally {
            Notifications.setMuted(false);
        }
    }
}
