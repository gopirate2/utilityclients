package com.baggute.cheatclient.mixin.client;

import com.baggute.cheatclient.UtilityClient;
import com.baggute.cheatclient.module.player.MouseTweaks;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.world.inventory.ContainerInput;
import net.minecraft.world.inventory.Slot;
import org.lwjgl.glfw.GLFW;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(AbstractContainerScreen.class)
public abstract class ContainerMouseTweaksMixin {
    @Shadow protected Slot hoveredSlot;
    @Shadow protected abstract void slotClicked(Slot slot, int slotId, int button, ContainerInput input);

    private int utilityclient$lastSlot = Integer.MIN_VALUE;
    private int utilityclient$button = -1;
    private boolean utilityclient$active;

    @Inject(method = "mouseClicked", at = @At("HEAD"), cancellable = true)
    private void utilityclient$mouseClicked(MouseButtonEvent event, boolean doubleClick, CallbackInfoReturnable<Boolean> cir) {
        if (!enabledAndShift(event) || hoveredSlot == null || (event.button() != 0 && event.button() != 1)) return;
        utilityclient$active = true;
        utilityclient$button = event.button();
        utilityclient$lastSlot = hoveredSlot.index;
        slotClicked(hoveredSlot, hoveredSlot.index, event.button(), event.button() == 0 ? ContainerInput.QUICK_MOVE : ContainerInput.PICKUP);
        cir.setReturnValue(true);
    }

    @Inject(method = "mouseDragged", at = @At("HEAD"), cancellable = true)
    private void utilityclient$mouseDragged(MouseButtonEvent event, double dragX, double dragY, CallbackInfoReturnable<Boolean> cir) {
        MouseTweaks tweaks = getTweaks();
        if (tweaks == null || !tweaks.isEnabled() || !utilityclient$active || event.button() != utilityclient$button || hoveredSlot == null) return;
        if (hoveredSlot.index != utilityclient$lastSlot && isShiftDown(event)) {
            utilityclient$lastSlot = hoveredSlot.index;
            slotClicked(hoveredSlot, hoveredSlot.index, event.button(), event.button() == 0 ? ContainerInput.QUICK_MOVE : ContainerInput.PICKUP);
        }
        cir.setReturnValue(true);
    }

    @Inject(method = "mouseReleased", at = @At("HEAD"))
    private void utilityclient$mouseReleased(MouseButtonEvent event, CallbackInfoReturnable<Boolean> cir) {
        utilityclient$active = false;
        utilityclient$button = -1;
        utilityclient$lastSlot = Integer.MIN_VALUE;
    }

    private boolean enabledAndShift(MouseButtonEvent event) {
        MouseTweaks tweaks = getTweaks();
        return tweaks != null && tweaks.isEnabled() && isShiftDown(event);
    }

    private MouseTweaks getTweaks() {
        return UtilityClient.moduleManager == null ? null : (MouseTweaks) UtilityClient.moduleManager.getByName("MouseTweaks");
    }

    private static boolean isShiftDown(MouseButtonEvent event) {
        return (event.modifiers() & GLFW.GLFW_MOD_SHIFT) != 0;
    }
}
