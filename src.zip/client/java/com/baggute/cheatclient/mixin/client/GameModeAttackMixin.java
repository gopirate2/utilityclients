// language: Java, file: GameModeAttackMixin.java, target: Fabric 26.2
package com.baggute.cheatclient.mixin.client;

import com.baggute.cheatclient.module.combat.AntiMiss;
import net.minecraft.client.multiplayer.MultiPlayerGameMode;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Lets AntiMiss drop useless attack packets without touching the input mapping. */
@Mixin(MultiPlayerGameMode.class)
public class GameModeAttackMixin {

    @Inject(method = "attack", at = @At("HEAD"), cancellable = true)
    private void utilityclient$antiMiss(Player player, Entity target, CallbackInfo ci) {
        if (AntiMiss.shouldBlock(player, target)) ci.cancel();
    }
}
