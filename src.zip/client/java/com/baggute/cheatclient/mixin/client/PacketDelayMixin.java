// language: Java, file: PacketDelayMixin.java, target: Fabric 26.2
package com.baggute.cheatclient.mixin.client;

import com.baggute.cheatclient.UtilityClient;
import net.minecraft.client.multiplayer.ClientPacketListener;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Backtrack. Entity position updates are dropped while the module is on, which
 * leaves every tracked hitbox at its last acknowledged spot — the delay that makes
 * a past position reachable.
 *
 * Deliberately callback-only: no packet type in the signature, so a mapping change
 * cannot turn this into a launch crash.
 */
@Mixin(ClientPacketListener.class)
public class PacketDelayMixin {

    @Inject(method = "handleMoveEntity", at = @At("HEAD"), cancellable = true)
    private void utilityclient$onMoveEntity(CallbackInfo ci) {
        if (UtilityClient.moduleManager == null) return;

        var module = UtilityClient.moduleManager.getByName("Backtrack");
        if (module != null && module.isEnabled()) ci.cancel();
    }
}
