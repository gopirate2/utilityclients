// language: Java, file: KeyboardMixin.java, target: Fabric 26.2
package com.baggute.cheatclient.mixin.client;

import com.baggute.cheatclient.UtilityClient;
import com.baggute.cheatclient.module.render.Freecam;
import net.minecraft.client.Minecraft;
import net.minecraft.client.KeyboardHandler;
import net.minecraft.client.input.KeyEvent;
import org.lwjgl.glfw.GLFW;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(KeyboardHandler.class)
public class KeyboardMixin {

    @Inject(method = "keyPress", at = @At("HEAD"), cancellable = true)
    private void utilityclient$onKeyPress(long window, int action, KeyEvent event, CallbackInfo ci) {
        if (UtilityClient.moduleManager == null) return;

        Minecraft mc = Minecraft.getInstance();
        int key = event.key();

        // The panic switch has to work with a screen open (chat, inventory, GUI):
        // consume it before the gameplay-key guard below.
        if (UtilityClient.moduleManager.onGlobalKey(key, action)) {
            ci.cancel();
            return;
        }

        // Never let gameplay keybinds leak into chat, the ClickGui, config screens,
        // inventories, pause menus, or text-entry widgets.
        if (mc.gui.screen() != null || mc.isPaused()) return;

        // Freecam intercepts movement keys entirely.
        Freecam fc = (Freecam) UtilityClient.moduleManager.getByName("Freecam");
        if (fc != null && fc.isEnabled()) {
            boolean handled = false;
            if (key == GLFW.GLFW_KEY_W)      { fc.setForward(action != GLFW.GLFW_RELEASE); handled = true; }
            else if (key == GLFW.GLFW_KEY_S) { fc.setBackward(action != GLFW.GLFW_RELEASE); handled = true; }
            else if (key == GLFW.GLFW_KEY_A) { fc.setLeft(action != GLFW.GLFW_RELEASE); handled = true; }
            else if (key == GLFW.GLFW_KEY_D) { fc.setRight(action != GLFW.GLFW_RELEASE); handled = true; }
            else if (key == GLFW.GLFW_KEY_SPACE) { fc.setUp(action != GLFW.GLFW_RELEASE); handled = true; }
            else if (key == GLFW.GLFW_KEY_LEFT_SHIFT) { fc.setDown(action != GLFW.GLFW_RELEASE); handled = true; }

            if (handled) {
                ci.cancel(); // vanilla never sees the key
                return;
            }
        }

        // Every action goes through: hold-to-act modules need PRESS *and* RELEASE.
        // ModuleManager only toggles on PRESS; secondary binds see all actions.
        UtilityClient.moduleManager.onKey(key, action);
    }
}
