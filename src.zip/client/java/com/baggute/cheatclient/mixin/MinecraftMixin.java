package com.baggute.cheatclient.mixin;

import com.baggute.cheatclient.UtilityClient;
import com.baggute.cheatclient.event.events.TickEvent;
import net.minecraft.client.Minecraft;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Minecraft.class)
public final class MinecraftMixin {
    @Inject(method = "tick", at = @At("HEAD"))
    private void utilityclient$tick(CallbackInfo ci) {
        if (UtilityClient.eventBus != null) {
            UtilityClient.eventBus.post(new TickEvent());
        }
    }
}