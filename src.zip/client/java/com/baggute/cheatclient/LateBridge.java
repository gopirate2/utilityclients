// language: Java, file: LateBridge.java, target: Fabric 26.2
package com.baggute.cheatclient;

import com.baggute.cheatclient.module.Module;
import com.baggute.cheatclient.module.render.Freecam;
import com.baggute.cheatclient.render.ApexRender;
import com.baggute.cheatclient.render.BlockEspExtractor;
import com.baggute.cheatclient.render.EspExtractor;
import com.baggute.cheatclient.render.HudRenderer;
import com.baggute.cheatclient.render.IndicatorExtractor;
import com.baggute.cheatclient.render.StorageEspExtractor;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.renderer.state.level.LevelRenderState;
import org.lwjgl.glfw.GLFW;

/**
 * The mixin entry points, callable from bytecode the injector inserts at runtime.
 *
 * <p>When the client is loaded into a game that is already running, its mixins
 * cannot apply: Fabric already read {@code Hud}, {@code LevelRenderer},
 * {@code KeyboardHandler} and {@code Minecraft}. The injector rewrites those four
 * methods instead and calls the matching method here, which is why this bridge
 * exists at all and why its method names and descriptors are part of a contract
 * with {@code BridgePatcher}.
 *
 * <p>Every method swallows its own failures. This runs inside the game's render
 * loop: a throw here would be a black screen, not a log line.
 */
public final class LateBridge {

    private LateBridge() {
    }

    /** HUD: {@code Hud#extractRenderState}, tail. */
    public static void onHudRender(Object graphics) {
        if (!(graphics instanceof GuiGraphicsExtractor extractor)) return;
        if (UtilityClient.moduleManager == null) return;
        try {
            HudRenderer.render(extractor);
        } catch (Throwable failure) {
            debug("hud", failure);
        }
    }

    /** World: {@code LevelRenderer#submitFeatures}, head. */
    public static void onSubmitFeatures(Object state) {
        if (!(state instanceof LevelRenderState renderState)) return;
        if (UtilityClient.moduleManager == null) return;
        try {
            EspExtractor.emitGizmos(renderState);
        } catch (Throwable failure) {
            debug("esp", failure);
        }
        try {
            BlockEspExtractor.emitGizmos();
        } catch (Throwable failure) {
            debug("blockesp", failure);
        }
        try {
            StorageEspExtractor.emitGizmos();
        } catch (Throwable failure) {
            debug("storageesp", failure);
        }
        try {
            IndicatorExtractor.emit(renderState);
        } catch (Throwable failure) {
            debug("indicators", failure);
        }
        try {
            ApexRender.emit(renderState);
        } catch (Throwable failure) {
            debug("apex", failure);
        }
    }

    /** Frame: {@code Minecraft#renderFrame}, head. */
    public static void onRenderFrame() {
        if (UtilityClient.moduleManager == null) return;
        try {
            Minecraft mc = Minecraft.getInstance();
            if (mc == null) return;
            float partialTick = mc.getDeltaTracker().getGameTimeDeltaPartialTick(false);
            UtilityClient.moduleManager.onRenderFrame(partialTick);
        } catch (Throwable failure) {
            debug("frame", failure);
        }
    }

    /**
     * Keys: {@code KeyboardHandler#keyPress}, head.
     *
     * <p>The mixin cancels the vanilla event to swallow keys; bytecode insertion
     * cannot cancel, so a bind also reaches the game. Acceptable for the GUI keys
     * and module toggles this drives.
     *
     * @param event the {@link KeyEvent}; typed as Object because the patch site
     *              passes its own reference without a cast
     * @param action GLFW press/release/repeat
     */
    public static void onKeyPress(Object event, int action) {
        if (!(event instanceof KeyEvent keyEvent)) return;
        if (UtilityClient.moduleManager == null) return;

        try {
            int key = keyEvent.key();
            if (UtilityClient.moduleManager.onGlobalKey(key, action)) return;

            Minecraft mc = Minecraft.getInstance();
            if (mc == null || mc.gui.screen() != null || mc.isPaused()) return;

            Module freecam = UtilityClient.moduleManager.getByName("Freecam");
            if (freecam instanceof Freecam fc && fc.isEnabled()) {
                boolean down = action != GLFW.GLFW_RELEASE;
                switch (key) {
                    case GLFW.GLFW_KEY_W -> fc.setForward(down);
                    case GLFW.GLFW_KEY_S -> fc.setBackward(down);
                    case GLFW.GLFW_KEY_A -> fc.setLeft(down);
                    case GLFW.GLFW_KEY_D -> fc.setRight(down);
                    case GLFW.GLFW_KEY_SPACE -> fc.setUp(down);
                    case GLFW.GLFW_KEY_LEFT_SHIFT -> fc.setDown(down);
                    default -> { }
                }
            }

            UtilityClient.moduleManager.onKey(key, action);
        } catch (Throwable failure) {
            debug("keys", failure);
        }
    }

    private static void debug(String where, Throwable failure) {
        if (!Boolean.getBoolean("utilityclient.debug")) return;
        UtilityClient.LOGGER.warn("[LateBridge] {} failed: {}", where, failure.toString());
    }
}
